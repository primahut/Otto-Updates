// Discord: Webhooks einrichten, testen, Code teilen, Bug melden
const dapi = () => window.pywebview.api;

function dcMsg(r, el = "dc-msg") {
  const m = $(el);
  m.style.display = r && r.msg ? "block" : "none";
  m.className = "mic " + (r && r.ok ? "on" : "err");
  m.textContent = r ? r.msg : "";
}

async function dcLoad() {
  const s = await dapi().discord_settings();
  document.querySelectorAll("[data-dc]").forEach((el) => {
    const v = s[el.dataset.dc];
    if (el.type === "checkbox") el.checked = !!v; else el.value = v || "";
  });
}
document.querySelector('[data-page="settings"]').addEventListener("click", dcLoad);
document.querySelectorAll("[data-dc]").forEach((el) => el.addEventListener("change", () =>
  dapi().discord_save({ [el.dataset.dc]: el.type === "checkbox" ? el.checked : el.value })));
document.querySelectorAll("[data-dctest]").forEach((b) => b.addEventListener("click", async () => {
  dcMsg({ ok: true, msg: "Sende Test …" });
  dcMsg(await dapi().discord_test(b.dataset.dctest));
}));
$("dc-import").addEventListener("click", async () => { dcMsg(await dapi().discord_import($("dc-code").value)); dcLoad(); });
$("dc-export").addEventListener("click", async () => {
  const code = await dapi().discord_code();
  try { await navigator.clipboard.writeText(code); dcMsg({ ok: true, msg: "Code kopiert – schick ihn deinen Freunden." }); }
  catch { $("dc-code").value = code; dcMsg({ ok: true, msg: "Code steht im Feld oben – markieren und kopieren." }); }
});

// Bug melden (von überall über das Menü)
$("bugnav").addEventListener("click", () => {
  $("bugmodal").classList.add("open"); dcMsg(null, "bug-msg"); $("bug-title").focus();
});
$("bug-cancel").addEventListener("click", () => $("bugmodal").classList.remove("open"));
$("bug-send").addEventListener("click", async () => {
  const title = $("bug-title").value.trim(), text = $("bug-text").value.trim();
  if (!title && !text) return dcMsg({ ok: false, msg: "Bitte kurz beschreiben, was passiert ist." }, "bug-msg");
  dcMsg({ ok: true, msg: "Sende …" }, "bug-msg");
  const r = await dapi().discord_bug(title, text);
  dcMsg(r.ok ? { ok: true, msg: "Danke! Der Bug ist in Discord gemeldet." } : r, "bug-msg");
  if (r.ok) { $("bug-title").value = ""; $("bug-text").value = ""; setTimeout(() => $("bugmodal").classList.remove("open"), 1500); }
});
