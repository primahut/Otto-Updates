// Analyse: Runde vs. Referenz – Zeitverlust-Karte, Kurvenbericht, Vergleichs-Diagramme
const A = { file: null, res: null, sel: null, range: null, hover: null };
const COL = { a: "#ff2d95", b: "#00e5ff", gain: "#39ff88", loss: "#ff3b5c", delta: "#c9a8ff", grid: "#1a2030", muted: "#66728a" };

document.querySelector('[data-page="analyse"]').addEventListener("click", aLoadSessions);
$("a-session").addEventListener("change", (e) => aRun(e.target.value));
$("a-lap").addEventListener("change", () => aRun(A.file, +$("a-lap").value, +$("a-ref").value));
$("a-ref").addEventListener("change", () => aRun(A.file, +$("a-lap").value, +$("a-ref").value));
$("a-reset").addEventListener("click", () => { A.sel = null; A.range = null; aRenderReport(); aDraw(); });

// ---------------- Einfach / Profi ----------------
A.mode = (() => { try { return localStorage.getItem("otto.mode") || "simple"; } catch { return "simple"; } })();
function aSetMode(mode) {
  A.mode = mode;
  try { localStorage.setItem("otto.mode", mode); } catch {}
  document.querySelectorAll("#a-mode button").forEach((b) => b.classList.toggle("on", b.dataset.mode === mode));
  const has = !!A.res;
  $("a-simple").style.display = has && mode === "simple" ? "block" : "none";
  $("a-grid").style.display = has && mode === "pro" ? "grid" : "none";
  if (has) mode === "simple" ? aRenderSimple() : aDraw();
}
document.querySelectorAll("#a-mode button").forEach((b) => b.addEventListener("click", () => aSetMode(b.dataset.mode)));

const TIP = {
  brake: "Wo du anfängst zu bremsen – verglichen mit der Referenz.",
  min: "Die langsamste Geschwindigkeit in der Kurve (deine / Referenz). Höher ist meist besser.",
  exit: "Geschwindigkeit ca. 120 m nach dem langsamsten Punkt – wie gut du aus der Kurve beschleunigst.",
};

function aRenderSimple() {
  const r = A.res, c = r.coach, same = r.lap.lap === r.ref.lap;
  const gap = c.gap_ms, pot = c.potential_ms;
  const head = same
    ? `<p>Das ist deine <b>Bestrunde</b>. Wähle oben bei „Runde“ eine andere Runde, um zu sehen, was dort schiefging.</p>`
    : gap > 0
      ? `<p>Diese Runde war <b>${(gap / 1000).toFixed(2)} s langsamer</b> als deine Referenz. Hier sind die drei Stellen, an denen am meisten Zeit liegen geblieben ist.</p>`
      : `<p>Diese Runde war <b>${(-gap / 1000).toFixed(2)} s schneller</b> als die Referenz – stark! Trotzdem gibt es Stellen zum Verbessern.</p>`;
  const potTxt = pot > 50 ? `<p>Wenn du deine besten Kurven in einer Runde zusammenbringst, ist <b>${fmt(r.theoretical_ms)}</b> drin – <b>${(pot / 1000).toFixed(2)} s</b> schneller als deine Bestzeit.</p>` : "";

  const tasks = c.top.length ? c.top.map((t, i) => `
    <div class="card s-task">
      <div class="s-num">${i + 1}</div>
      <div>
        <div class="where">${t.label}${t.nick ? " · " + t.nick : ""} · bei ${Math.round(t.start)} m</div>
        <h3>${t.title} <small>+${(t.loss_ms / 1000).toFixed(2)} s</small></h3>
        <p>${t.text}</p>
        <span class="more show3d" data-c="${t.name}">▶ In 3D zeigen</span>
        <span class="more" data-c="${t.name}">Diagramme →</span>
      </div>
      <canvas class="s-mini" data-c="${t.name}"></canvas>
    </div>`).join("")
    : `<div class="card s-task"><div class="s-num" style="border-color:var(--green);color:var(--green)">✓</div><div><h3>Keine großen Fehler</h3><p>In keiner Kurve verlierst du mehr als 0,05 s. Sauber gefahren!</p></div></div>`;

  const good = c.good.length ? `<ul>${c.good.map((g) => `<li>${g.label} <b style="float:right">−${(g.gain_ms / 1000).toFixed(2)} s</b></li>`).join("")}</ul>` : `<p class="muted">Noch keine Kurve, in der du schneller als die Referenz warst.</p>`;
  const style = c.style.length ? `<div class="card s-style"><div class="card-title">Dein Fahrstil</div><ul>${c.style.map((s) => `<li><b>${s.title}</b><span>${s.text}</span></li>`).join("")}</ul></div>` : "";

  $("a-simple").innerHTML = `
    <div class="card s-hero"><div class="big ${gap > 0 ? "neg" : "pos"}">${same ? "★" : ms(gap)}</div><div>${head}${potTxt}</div></div>
    <div class="s-cols">
      <div>${same ? "" : tasks}</div>
      <div class="s-side">
        <div class="card s-good"><div class="card-title">Das machst du schon gut</div>${good}</div>
        ${style}
      </div>
    </div>`;
  $("a-simple").querySelectorAll("canvas.s-mini").forEach((cv) => aDrawMini(cv, r.corners.find((k) => k.name === cv.dataset.c)));
  $("a-simple").querySelectorAll(".show3d").forEach((el) => el.addEventListener("click", () =>
    window.otto3d.open(A.file, r.lap.lap, r.ref.lap, el.dataset.c)));
  $("a-simple").querySelectorAll(".more:not(.show3d)").forEach((el) => el.addEventListener("click", () => {
    const k = r.corners.find((x) => x.name === el.dataset.c);
    A.sel = k.name; A.range = [Math.max(0, k.start - 80), k.end + 40];
    aSetMode("pro"); aRenderReport();
  }));
}

// Mini-Karte: ganze Strecke grau, die Kurve rot hervorgehoben
function aDrawMini(cv, c) {
  const [ctx, w, h] = fitCanvas(cv), B = A.res.B, n = B.x.length;
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (let k = 0; k < n; k++) { minX = Math.min(minX, B.x[k]); maxX = Math.max(maxX, B.x[k]); minZ = Math.min(minZ, B.z[k]); maxZ = Math.max(maxZ, B.z[k]); }
  const pad = 12, sc = Math.min((w - 2 * pad) / (maxX - minX || 1), (h - 2 * pad) / (maxZ - minZ || 1));
  const ox = (w - (maxX - minX) * sc) / 2, oz = (h - (maxZ - minZ) * sc) / 2;
  const P = (k) => [ox + (B.x[k] - minX) * sc, h - (oz + (B.z[k] - minZ) * sc)];
  ctx.lineCap = ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(140,155,180,.35)"; ctx.lineWidth = 3;
  ctx.beginPath(); for (let k = 0; k < n; k++) { const [x, y] = P(k); k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke();
  ctx.strokeStyle = COL.loss; ctx.lineWidth = 5; ctx.shadowColor = COL.loss; ctx.shadowBlur = 10;
  ctx.beginPath();
  B.dist.forEach((d, k) => { if (d >= c.start && d <= c.end) { const [x, y] = P(k); d - 8 < c.start ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } });
  ctx.stroke(); ctx.shadowBlur = 0;
  const [sx, sy] = P(0); ctx.fillStyle = "#fff"; ctx.fillRect(sx - 1.5, sy - 6, 3, 12);
}

// Kurzform für die Karte: „T16–18“ -> „T16“, „Bus Stop 2“ -> „BS2“
const short = (l) => /^T\d/.test(l) ? l.split("–")[0] : l.split(" ").map((w) => /^\d/.test(w) ? w : w[0]).join("").toUpperCase();

const ms = (v, sign = true) => (v == null ? "—" : (sign && v > 0 ? "+" : "") + (v / 1000).toFixed(3));

async function aLoadSessions() {
  const list = await window.pywebview.api.sessions();
  const sel = $("a-session");
  sel.innerHTML = list.map((s) => `<option value="${s.file}">${s.date} · ${s.info}</option>`).join("");
  if (list.length && !A.file) aRun(list[0].file);
  else { if (A.file) sel.value = A.file; aDraw(); }
}

// von anderen Seiten aus eine Session in der Analyse öffnen
async function openAnalyse(file) {
  document.querySelector('[data-page="analyse"]').click();
  await aRun(file);
  $("a-session").value = file;
}

async function aRun(file, lap = null, ref = null) {
  A.file = file; A.sel = null; A.range = null;
  const res = await window.pywebview.api.analyse(file, lap, ref);
  const empty = !!res.error;
  $("a-empty").style.display = empty ? "block" : "none";
  if (empty) {
    A.res = null; aSetMode(A.mode); $("a-empty").textContent = res.error + " Fahr ein paar saubere Runden – Otto zeichnet automatisch auf."; return; }

  // Standard: wenn nichts gewählt, letzte volle Runde gegen Bestzeit
  if (lap == null) {
    const full = res.laps.filter((l) => l.full);
    const other = full.filter((l) => l.lap !== res.ref.lap);
    if (other.length) return aRun(file, other[other.length - 1].lap, res.ref.lap);
  }
  A.res = res;
  $("a-lap").innerHTML = res.laps.map((l) => `<option value="${l.lap}">R${l.lap} · ${fmt(l.time_ms)}${!l.full ? " (unvollst.)" : l.severe ? " ⚠ Ausritt" : ""}</option>`).join("");
  $("a-ref").innerHTML = res.laps.filter((l) => l.full).map((l) => `<option value="${l.lap}">R${l.lap} · ${fmt(l.time_ms)}${l.time_ms === res.best_ms ? " ★" : ""}</option>`).join("");
  $("a-lap").value = res.lap.lap; $("a-ref").value = res.ref.lap;

  $("a-title").textContent = $("a-session").selectedOptions[0]?.textContent.split(" · ").slice(1).join(" · ") || "Analyse";
  $("a-laptime").textContent = fmt(res.lap.time_ms);
  $("a-reftime").textContent = fmt(res.ref.time_ms);
  const diff = res.lap.time_ms - res.ref.time_ms;
  $("a-diff").textContent = ms(diff);
  $("a-diff").className = diff > 0 ? "neg" : diff < 0 ? "pos" : "";
  $("a-theo").textContent = fmt(res.theoretical_ms);
  $("a-pot").textContent = res.theoretical_ms ? `${ms(res.theoretical_ms - res.best_ms)} zur Bestzeit` : "";
  aRenderReport();
  aSetMode(A.mode);
}

// ---------------- Kurvenbericht ----------------
function aRenderReport() {
  const res = A.res; if (!res) return;
  const sorted = [...res.corners].sort((x, y) => y.loss_ms - x.loss_ms);
  const maxAbs = Math.max(100, ...sorted.map((c) => Math.abs(c.loss_ms)));
  const same = res.lap.lap === res.ref.lap;
  $("a-corners").innerHTML = (same ? `<div class="muted small" style="margin-bottom:10px">Runde und Referenz sind gleich – wähle oben eine andere Runde zum Vergleichen.</div>` : "") +
    sorted.map((c) => {
      const loss = c.loss_ms, w = (Math.abs(loss) / maxAbs) * 50;
      const bar = loss > 0 ? `<i style="left:50%;width:${w}%;background:${COL.loss}"></i>` : `<i style="right:50%;width:${w}%;background:${COL.gain}"></i>`;
      const bp = c.lap.brake_m != null && c.ref.brake_m != null ? c.ref.brake_m - c.lap.brake_m : null;
      return `<div class="corner ${A.sel === c.name ? "sel" : ""}" data-c="${c.name}">
        <div class="c-head"><span class="c-name" data-rename="${c.name}" title="Klicken zum Umbenennen">${c.label}</span><div class="c-bar">${bar}</div>
          <span class="c-loss ${loss > 20 ? "neg" : loss < -20 ? "pos" : ""}">${ms(loss)}</span></div>
        <div class="c-stats">
          <div><span data-tip="${TIP.brake}">Bremspunkt</span><b>${bp == null ? "—" : Math.abs(bp) < 4 ? "gleich" : bp > 0 ? Math.round(bp) + " m früher" : Math.round(-bp) + " m später"}</b></div>
          <div><span data-tip="${TIP.min}">Min-Speed</span><b>${Math.round(c.lap.min_speed)} <span class="muted">/ ${Math.round(c.ref.min_speed)}</span></b></div>
          <div><span data-tip="${TIP.exit}">Ausgang</span><b>${Math.round(c.lap.exit_speed)} <span class="muted">/ ${Math.round(c.ref.exit_speed)}</span></b></div>
        </div>
        ${c.tips.length ? `<div class="c-tips">${c.tips.map((t) => `<span class="tip">${t}</span>`).join("")}</div>` : ""}
      </div>`;
    }).join("");
  // Kurvenname anklicken = umbenennen (gilt für alle Sessions auf dieser Strecke)
  $("a-corners").querySelectorAll("[data-rename]").forEach((el) => el.addEventListener("click", async (e) => {
    e.stopPropagation();
    const c = A.res.corners.find((k) => k.name === el.dataset.rename);
    const name = prompt(`Offizieller Name für diese Kurve (bei ${Math.round(c.apex)} m), z. B. „T11“ oder „Bus Stop“.\nLeer lassen = Ottos eigene Nummer.`, c.official ? c.label : "");
    if (name === null) return;
    await window.pywebview.api.rename_corner(A.res.track, c.apex, name, "");
    aRun(A.file, A.res.lap.lap, A.res.ref.lap);
  }));
  $("a-corners").querySelectorAll(".corner").forEach((el) => el.addEventListener("click", () => {
    const c = A.res.corners.find((k) => k.name === el.dataset.c);
    A.sel = c.name; A.range = [Math.max(0, c.start - 80), c.end + 40];
    aRenderReport(); aDraw();
  }));
}

// ---------------- Zeichnen ----------------
function aDraw() { if (A.res) { aDrawMap(); aDrawCharts(); } }

function aDrawMap() {
  const [ctx, w, h] = fitCanvas($("a-mapc"));
  ctx.clearRect(0, 0, w, h);
  const B = A.res.B, n = B.x.length, delta = A.res.delta;
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (let k = 0; k < n; k++) { minX = Math.min(minX, B.x[k]); maxX = Math.max(maxX, B.x[k]); minZ = Math.min(minZ, B.z[k]); maxZ = Math.max(maxZ, B.z[k]); }
  const pad = 36, sc = Math.min((w - 2 * pad) / (maxX - minX || 1), (h - 2 * pad) / (maxZ - minZ || 1));
  const ox = (w - (maxX - minX) * sc) / 2, oz = (h - (maxZ - minZ) * sc) / 2;
  const P = (x, z) => [ox + (x - minX) * sc, h - (oz + (z - minZ) * sc)];

  ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.lineWidth = 16; ctx.strokeStyle = "rgba(255,255,255,.04)";
  ctx.beginPath(); for (let k = 0; k < n; k++) { const [px, py] = P(B.x[k], B.z[k]); k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke();

  // Zeitgewinn/-verlust pro Abschnitt (Steigung des Deltas über ~40 m)
  const win = 5;
  for (let k = 1; k < n; k++) {
    const a = Math.max(0, k - win), b = Math.min(n - 1, k + win);
    const slope = (delta[b] - delta[a]) / ((b - a) * 8);      // ms pro Meter
    const f = Math.min(1, Math.abs(slope) / 0.6);
    const [ax, ay] = P(B.x[k - 1], B.z[k - 1]), [bx, by] = P(B.x[k], B.z[k]);
    ctx.strokeStyle = f < 0.08 ? "rgba(140,155,180,.35)" : slope > 0 ? `rgba(255,59,92,${0.35 + f * 0.65})` : `rgba(57,255,136,${0.35 + f * 0.65})`;
    ctx.lineWidth = 3 + f * 4;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
  }
  // Start/Ziel
  const [sx, sy] = P(B.x[0], B.z[0]);
  ctx.fillStyle = "#fff"; ctx.fillRect(sx - 2, sy - 9, 4, 18);

  // Kurven-Labels
  ctx.font = "700 11px JetBrains Mono, monospace"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  for (const c of A.res.corners) {
    const [px, py] = P(c.x, c.z), sel = A.sel === c.name;
    const bad = c.loss_ms > 50, good = c.loss_ms < -50;
    ctx.fillStyle = sel ? COL.a : "#0b0f17";
    ctx.strokeStyle = sel ? COL.a : bad ? COL.loss : good ? COL.gain : "#3a4458";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(px, py, 13, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = sel ? "#05060a" : "#e8eef8"; ctx.fillText(short(c.label), px, py + 0.5);
  }
  // Hover-Position aus den Diagrammen
  if (A.hover != null) {
    const k = A.hover, [px, py] = P(B.x[k], B.z[k]);
    ctx.shadowColor = "#fff"; ctx.shadowBlur = 14; ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(px, py, 6, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
  }
}

function aDrawCharts() {
  const cv = $("a-chartc"), [ctx, w, h] = fitCanvas(cv);
  ctx.clearRect(0, 0, w, h);
  const r = A.res, a = r.A, b = r.B, dist = b.dist, n = dist.length;
  const [d0, d1] = A.range || [0, dist[n - 1]];
  const i0 = Math.max(0, dist.findIndex((d) => d >= d0)), i1 = (() => { let k = n - 1; while (k > 0 && dist[k] > d1) k--; return k; })();
  $("a-range").textContent = A.sel ? `${A.sel} · ${Math.round(d0)}–${Math.round(d1)} m` : `Ganze Runde · ${r.track_len} m`;
  const L = 44, X = (d) => L + ((d - d0) / (d1 - d0 || 1)) * (w - L - 8);

  const panes = [["Δ s", 0.22], ["km/h", 0.33], ["Pedal", 0.25], ["Lenk.", 0.2]];
  let y = 0; const P = [];
  for (const [label, f] of panes) { P.push({ label, y, h: h * f - 6 }); y += h * f; }

  ctx.font = "10px JetBrains Mono, monospace"; ctx.textBaseline = "middle";
  for (const p of P) {
    ctx.fillStyle = "rgba(255,255,255,.02)"; ctx.fillRect(L, p.y, w - L - 8, p.h);
    ctx.fillStyle = COL.muted; ctx.textAlign = "right"; ctx.fillText(p.label, L - 6, p.y + p.h / 2);
  }
  // Kurven-Markierungen
  for (const c of r.corners) {
    if (c.apex < d0 || c.apex > d1) continue;
    ctx.strokeStyle = A.sel === c.name ? "rgba(255,45,149,.45)" : "rgba(255,255,255,.07)";
    ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(X(c.apex), 0); ctx.lineTo(X(c.apex), h); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = COL.muted; ctx.textAlign = "center"; ctx.fillText(c.label, X(c.apex), P[1].y + 8);
  }

  const line = (p, arr, lo, hi, color, width = 1.6, fill = false) => {
    ctx.beginPath();
    for (let k = i0; k <= i1; k++) {
      const yy = p.y + p.h - ((arr[k] - lo) / (hi - lo || 1)) * p.h;
      k === i0 ? ctx.moveTo(X(dist[k]), yy) : ctx.lineTo(X(dist[k]), yy);
    }
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
  };

  // Delta (mit Null-Linie und Füllung). Beim Zoom auf eine Kurve: Verlust ab Kurvenbeginn
  const base = A.range ? r.delta[i0] : 0;
  const dv = r.delta.map((v) => v - base);
  const dl = dv.slice(i0, i1 + 1), dAbs = Math.max(200, ...dl.map(Math.abs));
  const p0 = P[0], zeroY = p0.y + p0.h / 2;
  ctx.strokeStyle = COL.grid; ctx.beginPath(); ctx.moveTo(L, zeroY); ctx.lineTo(w - 8, zeroY); ctx.stroke();
  for (let k = i0 + 1; k <= i1; k++) {
    const yy = zeroY - (dv[k] / dAbs) * (p0.h / 2);
    ctx.fillStyle = dv[k] > 0 ? "rgba(255,59,92,.22)" : "rgba(57,255,136,.22)";
    ctx.fillRect(X(dist[k - 1]), Math.min(zeroY, yy), X(dist[k]) - X(dist[k - 1]) + 0.5, Math.abs(yy - zeroY));
  }
  line(p0, dv, -dAbs, dAbs, COL.delta, 1.8);

  const vmax = Math.max(...a.speed_kmh.slice(i0, i1 + 1), ...b.speed_kmh.slice(i0, i1 + 1)) + 5;
  const vmin = Math.max(0, Math.min(...a.speed_kmh.slice(i0, i1 + 1), ...b.speed_kmh.slice(i0, i1 + 1)) - 5);
  line(P[1], b.speed_kmh, vmin, vmax, COL.b, 1.6);
  line(P[1], a.speed_kmh, vmin, vmax, COL.a, 1.6);

  line(P[2], b.throttle, 0, 1.05, "rgba(0,229,255,.8)", 1.3);
  line(P[2], a.throttle, 0, 1.05, "rgba(255,45,149,.9)", 1.3);
  line(P[2], b.brake, 0, 1.05, "rgba(0,229,255,.45)", 1.3);
  line(P[2], a.brake, 0, 1.05, "rgba(255,45,149,.5)", 1.3);

  const sAbs = Math.max(0.1, ...a.steering.slice(i0, i1 + 1).map(Math.abs), ...b.steering.slice(i0, i1 + 1).map(Math.abs));
  line(P[3], b.steering, -sAbs, sAbs, COL.b, 1.3);
  line(P[3], a.steering, -sAbs, sAbs, COL.a, 1.3);

  // Fadenkreuz + Werte
  if (A.hover != null && A.hover >= i0 && A.hover <= i1) {
    const k = A.hover, x = X(dist[k]);
    ctx.strokeStyle = "rgba(255,255,255,.5)"; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    const txt = `${Math.round(dist[k])} m   Δ ${ms(r.delta[k])}   ${Math.round(a.speed_kmh[k])} / ${Math.round(b.speed_kmh[k])} km/h`;
    ctx.font = "600 11px JetBrains Mono, monospace";
    const tw = ctx.measureText(txt).width + 16, tx = Math.min(w - tw - 8, x + 10);
    ctx.fillStyle = "rgba(5,6,10,.9)"; ctx.fillRect(tx, 4, tw, 22);
    ctx.strokeStyle = "#252d40"; ctx.strokeRect(tx, 4, tw, 22);
    ctx.fillStyle = "#e8eef8"; ctx.textAlign = "left"; ctx.fillText(txt, tx + 8, 15);
  }
  A._X = { L, d0, d1, w, i0, i1 };
}

$("a-chartc").addEventListener("mousemove", (e) => {
  if (!A.res || !A._X) return;
  const { L, d0, d1, w } = A._X, rect = e.target.getBoundingClientRect();
  const d = d0 + ((e.clientX - rect.left - L) / (w - L - 8)) * (d1 - d0);
  const dist = A.res.B.dist; let k = 0;
  while (k < dist.length - 1 && dist[k] < d) k++;
  A.hover = k; aDraw();
});
$("a-chartc").addEventListener("mouseleave", () => { A.hover = null; aDraw(); });
window.addEventListener("resize", aDraw);
