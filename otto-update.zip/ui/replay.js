// Replay: gespeicherte Runde abspielen, optional mit Vergleichsrunde (nutzt fmt/fitCanvas aus app.js)
const R = { file: null, lap: null, d: null, ref: null, corners: [], t: 0, playing: false, rate: 1, last: 0, cache: {} };
const api = () => window.pywebview.api;

document.querySelector('[data-page="replay"]').addEventListener("click", loadSessions);
$("r-session").addEventListener("change", (e) => loadLaps(e.target.value));
$("r-ref").addEventListener("change", (e) => { R.refChosen = true; loadRef(e.target.value); });
$("r-play").addEventListener("click", togglePlay);
$("r-rate").addEventListener("change", (e) => (R.rate = parseFloat(e.target.value)));
$("r-seek").addEventListener("input", (e) => { if (R.d) R.t = (e.target.value / 1000) * R.d.time_ms; });
$("r-chartc").addEventListener("click", (e) => {
  if (!R.d) return;
  const r = e.target.getBoundingClientRect();
  R.t = timeAtPos(R.d, (e.clientX - r.left) / r.width);       // Diagramm = Strecke -> Zeit an dieser Stelle
});
window.addEventListener("keydown", (e) => {
  if (!$("page-replay").classList.contains("active") || !R.d || e.target.tagName === "SELECT") return;
  if (e.code === "Space") { togglePlay(); e.preventDefault(); }
  if (e.code === "ArrowRight") R.t = Math.min(R.d.time_ms, R.t + 1000);
  if (e.code === "ArrowLeft") R.t = Math.max(0, R.t - 1000);
});
function togglePlay() {
  if (!R.d) return;
  if (!R.playing && R.t >= R.d.time_ms) R.t = 0;                 // am Ende: von vorn
  R.playing = !R.playing; R.last = performance.now();
}

// ---------------------------------------------------------------- Laden
async function loadSessions() {
  const list = await api().sessions();
  const sel = $("r-session"), prev = sel.value;
  sel.innerHTML = list.map((s) => `<option value="${s.file}">${s.date} · ${s.game} · ${s.info} (${s.size_kb} KB)</option>`).join("")
    || "<option>Noch keine Aufnahmen</option>";
  if (!list.length) return;
  sel.value = list.some((s) => s.file === prev) ? prev : list[0].file;
  if (sel.value !== R.file) loadLaps(sel.value);
}

async function loadLaps(file) {
  R.file = file; R.ref = null; R.corners = []; R.refChosen = false;
  const laps = await api().laps(file);
  R.laps = laps;
  $("r-laps").innerHTML = laps.map((l) =>
    `<tr data-lap="${l.lap}" class="${l.best ? "best" : ""} ${l.full ? "" : "invalid"}"><td>Runde ${l.lap}${!l.full ? " (unvollst.)" : l.severe ? " ⚠ Ausritt" : l.offs ? " ⚠" : ""}</td><td>${fmt(l.time_ms)}</td></tr>`).join("")
    || `<tr><td class="muted">Keine Runden</td></tr>`;
  $("r-laps").querySelectorAll("tr[data-lap]").forEach((tr) => tr.addEventListener("click", () => loadLap(+tr.dataset.lap)));
  $("r-ref").innerHTML = `<option value="">— keine —</option>` + laps.filter((l) => l.full)
    .map((l) => `<option value="${l.lap}">Runde ${l.lap} · ${fmt(l.time_ms)}${l.best ? " ★" : ""}</option>`).join("");
  const best = laps.find((l) => l.best) || laps[0];
  if (best) await loadLap(best.lap);
}

async function loadLap(lap) {
  R.d = prep(await api().lap(R.file, lap));
  R.lap = lap; R.t = 0; R.playing = false; R.cache = {};
  $("r-laps").querySelectorAll("tr").forEach((tr) => tr.classList.toggle("sel", +tr.dataset.lap === lap));
  $("r-title").textContent = `Runde ${lap} · ${fmt(R.d.time_ms)}`;
  // Standard-Vergleich: die Bestrunde (wenn das nicht schon die gewählte Runde ist)
  const best = (R.laps || []).find((l) => l.best);
  const want = R.refChosen ? $("r-ref").value : (best && best.lap !== lap ? String(best.lap) : "");
  $("r-ref").value = want;
  await loadRef(want);
  // Kurvennamen für die Karte (aus der Analyse)
  try {
    const a = await api().analyse(R.file, lap, null);
    R.corners = (a.corners || []).map((c) => ({ x: c.x, z: c.z, label: c.label }));
  } catch { R.corners = []; }
  R.cache = {};
}

async function loadRef(lap) {
  R.ref = lap ? prep(await api().lap(R.file, +lap)) : null;
  $("r-dbox").style.display = R.ref ? "" : "none";
  R.cache = {};
}

// Streckenposition aufbereiten: am Rundenanfang hängt LMU kurz bei ~100 % -> als 0 werten; nur vorwärts
function prep(d) {
  if (!d) return d;
  const n = d.t.length, pos = new Array(n);
  let last = 0;
  for (let k = 0; k < n; k++) {
    let p = d.lap_pos[k];
    if (p < 0) p = k / n;                                         // Spiele ohne Streckenposition
    if (d.lap_time_ms[k] < 5000 && p > 0.9) p = 0;
    last = Math.max(last, p);
    pos[k] = last;
  }
  d.pos = pos;
  d.t0 = d.lap_time_ms[0];
  d.maxV = Math.max(...d.speed_kmh);
  return d;
}
function idxAtTime(d, t) {
  const a = d.lap_time_ms, t0 = d.t0; let lo = 0, hi = a.length - 1;
  while (lo < hi) { const m = (lo + hi + 1) >> 1; a[m] - t0 <= t ? (lo = m) : (hi = m - 1); }
  return lo;
}
function idxAtPos(d, p) {
  const a = d.pos; let lo = 0, hi = a.length - 1;
  while (lo < hi) { const m = (lo + hi + 1) >> 1; a[m] <= p ? (lo = m) : (hi = m - 1); }
  return lo;
}
const timeAtPos = (d, p) => d.lap_time_ms[idxAtPos(d, p)] - d.t0;

function speedColor(v, max) {
  const f = Math.max(0, Math.min(1, v / max));          // langsam = pink, schnell = cyan
  return `hsl(${320 - f * 135},100%,${55 + f * 5}%)`;
}

// ---------------------------------------------------------------- Zeichnen (Strecke/Diagramm nur einmal, dann nur Cursor)
function layer(key, canvas, draw) {
  const r = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  const id = `${key}:${Math.round(r.width)}x${Math.round(r.height)}`;
  if (!R.cache[key] || R.cache[key].id !== id) {
    const off = document.createElement("canvas");
    off.width = Math.max(1, Math.round(r.width * dpr)); off.height = Math.max(1, Math.round(r.height * dpr));
    const ctx = off.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const extra = draw(ctx, r.width, r.height);
    R.cache[key] = { id, off, extra };
  }
  return R.cache[key];
}

function mapLayer(canvas) {
  return layer("map", canvas, (ctx, w, h) => {
    const d = R.d, xs = d.x, zs = d.z, n = xs.length;
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (let k = 0; k < n; k++) { minX = Math.min(minX, xs[k]); maxX = Math.max(maxX, xs[k]); minZ = Math.min(minZ, zs[k]); maxZ = Math.max(maxZ, zs[k]); }
    const pad = 34, sc = Math.min((w - 2 * pad) / (maxX - minX || 1), (h - 2 * pad) / (maxZ - minZ || 1));
    const ox = (w - (maxX - minX) * sc) / 2, oz = (h - (maxZ - minZ) * sc) / 2;
    const P = (x, z) => [ox + (x - minX) * sc, h - (oz + (z - minZ) * sc)];
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.lineWidth = 11; ctx.strokeStyle = "rgba(0,229,255,.07)";
    ctx.beginPath(); for (let k = 0; k < n; k++) { const [px, py] = P(xs[k], zs[k]); k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke();
    ctx.lineWidth = 3.2;
    for (let k = 1; k < n; k++) {
      const [ax, ay] = P(xs[k - 1], zs[k - 1]), [bx, by] = P(xs[k], zs[k]);
      ctx.strokeStyle = speedColor(d.speed_kmh[k], d.maxV);
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
    }
    // Start/Ziel + Kurvennamen
    const [sx, sy] = P(xs[0], zs[0]);
    ctx.fillStyle = "#fff"; ctx.fillRect(sx - 2, sy - 8, 4, 16);
    ctx.font = "700 10px JetBrains Mono, monospace"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    for (const c of R.corners) {
      const [px, py] = P(c.x, c.z), t = c.label.replace("Kurve ", "K");
      const tw = ctx.measureText(t).width + 10;
      ctx.fillStyle = "rgba(5,6,10,.8)"; ctx.strokeStyle = "#3a4458"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(px - tw / 2, py - 17, tw, 14, 4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#c9d3e3"; ctx.fillText(t, px, py - 10);
    }
    return { P };
  });
}

function chartLayer(canvas) {
  return layer("chart", canvas, (ctx, w, h) => {
    const d = R.d, ref = R.ref, maxV = Math.max(d.maxV, ref ? ref.maxV : 0);
    ctx.strokeStyle = "#1c2230"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();
    const line = (src, get, color, dashed) => {
      ctx.beginPath();
      for (let k = 0; k < src.t.length; k += 2) { const x = src.pos[k] * w, y = h - 4 - get(src, k) * (h - 8); k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
      ctx.setLineDash(dashed ? [4, 4] : []); ctx.strokeStyle = color; ctx.lineWidth = dashed ? 1.2 : 1.6; ctx.stroke(); ctx.setLineDash([]);
    };
    const series = [[(s, k) => s.brake[k], "#ff3b5c", "rgba(255,59,92,.55)"], [(s, k) => s.throttle[k], "#39ff88", "rgba(57,255,136,.5)"],
      [(s, k) => 0.5 - s.steering[k] / 2, "#ffd23f", "rgba(255,210,63,.45)"], [(s, k) => s.speed_kmh[k] / maxV, "#00e5ff", "rgba(255,45,149,.75)"]];
    if (ref) for (const [get, , rc] of series) line(ref, get, rc, true);
    for (const [get, c] of series) line(d, get, c, false);
    // Kurven-Markierungen (Position aus der Karte)
    return {};
  });
}

function updateReplay(now) {
  // Seite nicht sichtbar -> nur 2x pro Sekunde nachschauen statt 60x (spart CPU)
  if (document.hidden || !$("page-replay").classList.contains("active")) {
    R.last = performance.now();
    return setTimeout(() => requestAnimationFrame(updateReplay), 500);
  }
  requestAnimationFrame(updateReplay);
  if (!R.d) return;
  if (R.playing) {
    R.t += (now - R.last) * R.rate;
    if (R.t >= R.d.time_ms) { R.t = R.d.time_ms; R.playing = false; }
  }
  R.last = now;
  const d = R.d, i = idxAtTime(d, R.t), p = d.pos[i];
  $("r-play").textContent = R.playing ? "❚❚" : "▶";
  $("r-seek").value = (R.t / (d.time_ms || 1)) * 1000;
  $("r-time").textContent = fmt(R.t);
  $("r-speed").textContent = Math.round(d.speed_kmh[i]);
  const g = d.gear[i]; $("r-gear").textContent = g < 0 ? "R" : g === 0 ? "N" : g;
  $("r-thr").style.height = d.throttle[i] * 100 + "%";
  $("r-brk").style.height = d.brake[i] * 100 + "%";
  $("r-wheel").style.transform = `rotate(${steerDeg(d.steering[i], d.steer_range[i])}deg)`;
  $("r-steer").textContent = fmtSteer(d.steering[i], d.steer_range[i]);

  // Karte: Hintergrund aus dem Zwischenspeicher, darauf Auto (+ Vergleichs-Punkt)
  const mc = $("r-mapc"), [mctx, mw, mh] = fitCanvas(mc), ml = mapLayer(mc), P = ml.extra.P;
  mctx.clearRect(0, 0, mw, mh); mctx.drawImage(ml.off, 0, 0, mw, mh);
  let j = null;
  if (R.ref) {
    j = idxAtPos(R.ref, p);
    const [gx, gy] = P(R.ref.x[j], R.ref.z[j]);
    mctx.fillStyle = "#ff2d95"; mctx.shadowColor = "#ff2d95"; mctx.shadowBlur = 12;
    mctx.beginPath(); mctx.arc(gx, gy, 5.5, 0, Math.PI * 2); mctx.fill(); mctx.shadowBlur = 0;
    const delta = R.t - (R.ref.lap_time_ms[j] - R.ref.t0);
    $("r-delta").textContent = (delta > 0 ? "+" : delta < 0 ? "−" : "±") + Math.abs(delta / 1000).toFixed(2);
    $("r-delta").className = delta <= 0 ? "pos" : "neg";
  }
  const [px, py] = P(d.x[i], d.z[i]), [qx, qy] = P(d.x[Math.min(d.x.length - 1, i + 3)], d.z[Math.min(d.x.length - 1, i + 3)]);
  mctx.save(); mctx.translate(px, py); mctx.rotate(Math.atan2(qy - py, qx - px) || 0);
  mctx.shadowColor = "#fff"; mctx.shadowBlur = 14; mctx.fillStyle = "#fff";
  mctx.beginPath(); mctx.moveTo(11, 0); mctx.lineTo(-7, 7); mctx.lineTo(-3, 0); mctx.lineTo(-7, -7); mctx.closePath(); mctx.fill();
  mctx.restore();

  // Diagramm: Hintergrund + Cursor
  const cc = $("r-chartc"), [cctx, cw, ch] = fitCanvas(cc), cl = chartLayer(cc);
  cctx.clearRect(0, 0, cw, ch); cctx.drawImage(cl.off, 0, 0, cw, ch);
  const cx = p * cw;
  cctx.strokeStyle = "#ff2d95"; cctx.lineWidth = 2; cctx.shadowColor = "#ff2d95"; cctx.shadowBlur = 8;
  cctx.beginPath(); cctx.moveTo(cx, 0); cctx.lineTo(cx, ch); cctx.stroke(); cctx.shadowBlur = 0;
}
requestAnimationFrame(updateReplay);
