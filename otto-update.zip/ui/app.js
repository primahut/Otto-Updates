const $ = (id) => document.getElementById(id);
const HISTORY = 450; // ~15 s bei 30 Hz
const hist = [];
let track = [];

// --- Navigation ---
document.querySelectorAll(".nav[data-page]").forEach((a) => a.addEventListener("click", () => {
  document.querySelectorAll(".nav").forEach((n) => n.classList.toggle("active", n === a));
  document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === "page-" + a.dataset.page));
}));

$("recbtn").addEventListener("click", () => window.pywebview.api.toggle_record());
$("ovlbtn").addEventListener("click", () => window.pywebview.api.toggle_overlay());
$("ovl-toggle").addEventListener("click", () => window.pywebview.api.toggle_overlay());
$("ovl-size").addEventListener("change", () => setTimeout(() => window.pywebview.api.overlay_resize(), 150));

// Einstellungen: Reiter (letzter Reiter wird gemerkt)
function showTab(name) {
  document.querySelectorAll("#set-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === name));
  document.querySelectorAll(".tabpane").forEach((p) => p.classList.toggle("on", p.dataset.pane === name));
  try { localStorage.setItem("otto.tab", name); } catch {}
}
document.querySelectorAll("#set-tabs button").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));
try { const t = localStorage.getItem("otto.tab"); if (t) showTab(t); } catch {}

// Erste Schritte (Live-Seite ohne Spiel)
$("w-sim").addEventListener("click", () => { $("source").value = "sim"; $("source").dispatchEvent(new Event("change")); });
$("w-settings").addEventListener("click", () => { showTab("coach"); document.querySelector('[data-page="settings"]').click(); });
document.querySelectorAll("[data-voice]").forEach((el) => el.addEventListener("change", () =>
  window.pywebview.api.set_voice(el.dataset.voice, el.type === "checkbox" ? el.checked : el.type === "range" ? +el.value : el.value.trim())));
// Stimmen-Liste einmal laden
async function loadVoices(lang) {
  const vs = await window.pywebview.api.voices(lang);
  const opt = (v) => `<option value="${v.id}">${v.name} · ${v.gender}</option>`;
  const nat = vs.filter((v) => v.neural), win = vs.filter((v) => !v.neural);
  const cur = $("voice-sel").value;
  $("voice-sel").innerHTML = `<option value="">Standard</option>` +
    (nat.length ? `<optgroup label="Natürlich klingend (offline, empfohlen)">${nat.map(opt).join("")}</optgroup>` : "") +
    `<optgroup label="Windows-Stimmen">${win.map(opt).join("")}</optgroup>`;
  if (cur) $("voice-sel").value = cur;
  VOICES_DL = vs.filter((v) => v.neural && !v.installed).map((v) => v.id);
}
let VOICES_DL = [];
window.addEventListener("pywebviewready", () => loadVoices());
$("lang-sel").addEventListener("change", (e) => loadVoices(e.target.value));
$("learn-btn").addEventListener("click", () => window.pywebview.api.learn_button());
document.querySelectorAll("#coach-modes input").forEach((r) => r.addEventListener("change", () => window.pywebview.api.set_voice("coach_mode", r.value)));

// Aufräumen: Kandidaten anzeigen, nur Angehaktes wandert in den Papierkorb
async function loadCleanup() {
  const list = await window.pywebview.api.cleanup_list(+$("keep-days").value);
  $("clean-list").innerHTML = list.length ? list.map((c) => `<tr>
      <td><input type="checkbox" data-file="${c.file}" ${c.auto ? "checked" : ""}></td>
      <td>${c.date || "—"} · ${c.info}</td><td>${c.reason} · ${c.size_kb} KB</td></tr>`).join("")
    : `<tr><td class="muted">Nichts aufzuräumen 👍</td></tr>`;
  $("clean-btn").style.display = list.length ? "" : "none";
}
document.querySelector('[data-page="settings"]').addEventListener("click", loadCleanup);

// Version & Updates
function updMsg(r) {
  if (!r || !r.msg) return;
  $("upd-msg").style.display = "block";
  $("upd-msg").className = "mic " + (r.ok ? "on" : "err");
  $("upd-msg").textContent = r.msg + (r.notes ? " – " + r.notes : "");
  if (r.ok && r.version) $("upd-restart").style.display = "";
}
document.querySelector('[data-page="settings"]').addEventListener("click", async () => {
  const v = await window.pywebview.api.version_info();
  $("upd-ver").textContent = "Otto " + v.version;
  $("upd-where").textContent = v.installed ? `Deine Daten: ${v.data}` : "Entwickler-Version (Updates nur in der Otto.exe)";
});
$("upd-file").addEventListener("click", async () => updMsg(await window.pywebview.api.install_update_file()));
$("upd-online").addEventListener("click", async () => {
  const v = await window.pywebview.api.version_info();
  $("upd-msg").style.display = "block"; $("upd-msg").className = "mic"; $("upd-msg").textContent = "🔄 Suche online nach Updates …";
  updMsg(await window.pywebview.api.check_update());
});
$("upd-restart").addEventListener("click", () => {
  $("upd-msg").style.display = "block";
  $("upd-msg").textContent = "Otto schließt sich und startet in etwa 8 Sekunden mit der neuen Version neu …";
  setTimeout(() => window.pywebview.api.restart(), 600);
});
$("keep-days").addEventListener("change", loadCleanup);
$("clean-btn").addEventListener("click", async () => {
  const files = [...document.querySelectorAll("#clean-list input:checked")].map((i) => i.dataset.file);
  if (!files.length || !confirm(`${files.length} Session(s) in den Papierkorb verschieben?`)) return;
  await window.pywebview.api.cleanup_run(files);
  loadCleanup();
});
document.querySelectorAll("[data-test]").forEach((b) => b.addEventListener("click", () => window.pywebview.api.voice_test(b.dataset.test)));
$("autorec").addEventListener("change", (e) => window.pywebview.api.set_auto_record(e.target.checked));

$("source").addEventListener("change", (e) => {
  hist.length = 0; track = [];
  window.pywebview.api.set_source(e.target.value);
});

// --- Helfer ---
function fmt(ms) {
  if (ms == null) return "—";
  const s = ms / 1000;
  return `${Math.floor(s / 60)}:${(s % 60).toFixed(3).padStart(6, "0")}`;
}
// Lenkung: Grad am Lenkrad, wenn der Lenkbereich bekannt ist, sonst Prozent
function steerDeg(steering, range) { return range ? (steering * range) / 2 : steering * 90; }
function fmtSteer(steering, range) {
  if (!range) return `${Math.round(steering * 100)} %`;
  const d = Math.round((steering * range) / 2);
  return `${d > 0 ? "+" : ""}${d}°`;
}
function fitCanvas(c) {
  const r = c.getBoundingClientRect(), d = window.devicePixelRatio || 1;
  if (c.width !== Math.round(r.width * d) || c.height !== Math.round(r.height * d)) {
    c.width = Math.round(r.width * d); c.height = Math.round(r.height * d);
  }
  const ctx = c.getContext("2d"); ctx.setTransform(d, 0, 0, d, 0, 0);
  return [ctx, r.width, r.height];
}

// --- Streckenkarte ---
function drawMap(s) {
  const [ctx, w, h] = fitCanvas($("map"));
  ctx.clearRect(0, 0, w, h);
  if (track.length < 2) {
    ctx.fillStyle = "#6b778c"; ctx.font = "13px Segoe UI"; ctx.textAlign = "center";
    ctx.fillText("Strecke wird während der ersten Runde aufgezeichnet …", w / 2, h / 2);
    return;
  }
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (const [x, z] of track) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z); }
  const pad = 30, sc = Math.min((w - 2 * pad) / (maxX - minX || 1), (h - 2 * pad) / (maxZ - minZ || 1));
  const ox = (w - (maxX - minX) * sc) / 2, oz = (h - (maxZ - minZ) * sc) / 2;
  const P = (x, z) => [ox + (x - minX) * sc, h - (oz + (z - minZ) * sc)];

  ctx.lineJoin = ctx.lineCap = "round";
  for (const [width, alpha] of [[14, 0.08], [7, 0.18], [2.5, 1]]) {
    ctx.beginPath();
    track.forEach(([x, z], i) => { const [px, py] = P(x, z); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
    ctx.strokeStyle = `rgba(0,229,255,${alpha})`; ctx.lineWidth = width; ctx.stroke();
  }
  if (s) {
    const [px, py] = P(s.x, s.z);
    ctx.shadowColor = "#ff2d95"; ctx.shadowBlur = 18;
    ctx.fillStyle = "#ff2d95"; ctx.beginPath(); ctx.arc(px, py, 7, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
  }
}

// --- Verlaufs-Chart ---
function drawChart() {
  const [ctx, w, h] = fitCanvas($("chart"));
  ctx.clearRect(0, 0, w, h);
  if (hist.length < 2) return;
  const maxSpeed = Math.max(200, ...hist.map((s) => s.speed_kmh));
  const line = (get, color, max) => {
    ctx.beginPath();
    hist.forEach((s, i) => {
      const x = (i / (HISTORY - 1)) * w, y = h - 4 - (get(s) / max) * (h - 8);
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    });
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.shadowColor = color; ctx.shadowBlur = 8; ctx.stroke(); ctx.shadowBlur = 0;
  };
  line((s) => s.throttle, "#39ff88", 1);
  line((s) => s.brake, "#ff3b5c", 1);
  line((s) => s.speed_kmh, "#00e5ff", maxSpeed);
}

// --- Haupt-Update ---
let lastLapCount = -1, lastDeltaDraw = 0;
async function tick() {
  const st = await window.pywebview.api.state();
  const s = st.sample;
  $("conn").className = "conn " + (st.connected ? "on" : "off");
  // ohne Spiel: Erste-Schritte statt leerer Anzeigen (sobald einmal gefahren wurde, bleibt die Live-Ansicht)
  const showWelcome = !st.connected && !(st.laps && st.laps.length);
  $("welcome").classList.toggle("on", showWelcome);
  $("live-grid").style.display = showWelcome ? "none" : "";
  $("conn").querySelector("span").textContent = st.connected ? `verbunden · ${st.game}` : "nicht verbunden";
  $("game").textContent = st.connected ? st.game : (st.source === "sim" ? "Simulator startet …" : "Warte auf Spiel (LMU, AC, ACC) …");
  $("info").textContent = st.info || "—";
  // Aufnahme: an + Datei offen = läuft; an ohne Spiel = wartet (gelb); aus = grau
  const rb = $("recbtn");
  rb.className = "recbtn " + (st.recording ? "on" : st.rec_on ? "armed" : "");
  rb.querySelector("span").textContent = st.recording ? "Aufnahme läuft – stoppen" : st.rec_on ? "Wartet auf Fahrt – stoppen" : "Aufnahme starten";
  if (document.activeElement !== $("autorec")) $("autorec").checked = st.auto_record;

  // Coach / Sprache
  if (st.coach_msg) { $("coachmsg").textContent = "🗣 " + st.coach_msg; $("coachmsg").className = ""; }
  $("heard").textContent = st.listening ? `🎤 hört zu${st.heard ? " · zuletzt: „" + st.heard + "“" : " – sag „Otto, Hilfe“"}` : "";
  document.querySelectorAll("[data-voice]").forEach((el) => {
    if (document.activeElement === el) return;
    const v = st.voice[el.dataset.voice];
    if (el.type === "checkbox") el.checked = v; else el.value = v;
  });
  $("vol-val").textContent = st.voice.volume + " %" + (st.voice.volume > 100 ? " (verstärkt)" : "");
  $("gain-val").textContent = (+st.voice.mic_gain).toFixed(2).replace(".", ",") + "×";
  $("sens-val").textContent = ["", "sehr streng", "streng", "streng", "mittel", "mittel", "großzügig", "großzügig", "sehr großzügig", "sehr großzügig", "maximal"][st.voice.mic_sens] || st.voice.mic_sens;
  // natürliche Stimme: Download-Fortschritt, danach Liste auffrischen
  const dl = st.voice_dl || {}, wantDl = VOICES_DL.includes(st.voice.voice);
  $("voice-dl").textContent = dl.error ? "⚠ " + dl.error + " – bis dahin spricht die Windows-Stimme."
    : dl.model ? `⬇ Stimme wird einmalig geladen … ${dl.pct} % (bis dahin spricht die Windows-Stimme)`
    : st.voice_natural ? "✓ Natürliche Stimme aktiv – läuft offline auf deinem PC." : "";
  if (wantDl && !dl.model && st.voice_natural) loadVoices();
  $("vibe-box").style.opacity = st.voice_natural ? 1 : 0.5;
  const rt = st.rates || {};
  $("ovl-rate").textContent = st.connected ? `Messung: Spieldaten ${rt.data_hz}/s` + (rt.drop_pct ? ` (verworfen ${rt.drop_pct} %)` : "") +
    (rt.overlay_fps != null ? ` · Overlay zeigt ${rt.overlay_fps}/s an` : " · Overlay geschlossen") + " – normal: Daten ~30/s, Overlay ~13/s" : "";
  if (st.ai && st.ai.t !== $("ai-status").dataset.t) {
    $("ai-status").dataset.t = st.ai.t;
    $("ai-status").textContent = st.ai.error ? "⚠ " + st.ai.error
      : `✓ ${st.ai.t} · Antwort in ${((st.ai.ms || 0) / 1000).toFixed(1)} s: „${st.ai.answer}“`;
  }
  // Zusammen fahren: Fahrerliste zum Auswählen + Live-Info zum Kumpel
  const dl2 = (st.drivers || []).join("|");
  if (dl2 !== $("driver-list").dataset.sig) {
    $("driver-list").dataset.sig = dl2;
    $("driver-list").innerHTML = (st.drivers || []).map((n) => `<option value="${n.replace(/"/g, "&quot;")}">`).join("");
  }
  const fr = st.friend;
  $("friend-live").textContent = !st.voice.friend_name ? "" : !st.connected ? "Wird erkannt, sobald ihr auf demselben Server seid."
    : !fr ? `„${st.voice.friend_name}“ ist gerade nicht auf dem Server.`
    : `✓ ${fr.name} · P${fr.place}` + (fr.in_pits ? " · in der Box" : "") +
      (fr.gap_s != null ? ` · ${fr.gap_s > 0 ? "+" : "−"}${Math.abs(fr.gap_s).toFixed(1)} s` : fr.track_m != null ? ` · ${Math.abs(fr.track_m)} m ${fr.track_m > 0 ? "vor" : "hinter"} dir` : "") +
      (fr.best ? ` · Bestzeit ${fmt(fr.best * 1000)}` : "");
  $("ovl-val").textContent = Math.round(st.voice.overlay_opacity * 100) + " %";
  document.querySelectorAll('#coach-modes input').forEach((r) => (r.checked = r.value === st.voice.coach_mode));
  const paceTxt = st.voice.coach_mode !== "lehrer" ? "" : st.pace_events
    ? `Vorlage: ${st.pace_source} · ${st.pace_events} Kommandos pro Runde`
    : "Vorlage: noch keine – fahr eine saubere Runde, dann geht's ab der nächsten Runde los.";
  $("pace-info").textContent = paceTxt;
  if (st.voice.coach_mode === "lehrer" && st.connected) { $("coachmsg").textContent = "🎧 Fahrlehrer · " + (st.pace_events ? st.pace_source : "wartet auf eine saubere Runde"); $("coachmsg").className = ""; }
  const pb = st.voice.ptt_button;
  $("learn-btn").textContent = st.learning_button ? "… jetzt Knopf am Lenkrad drücken" : pb ? `✓ ${pb.name} (ändern)` : "Knopf zuweisen";
  $("rate-val").textContent = (+st.voice.rate).toFixed(2).replace(".", ",") + "×";
  $("only-tipps-box")?.classList.toggle("on", st.voice.coach_mode === "tipps");
  document.querySelectorAll(".cmds td:first-child, .cmds td:nth-child(4)").forEach((td) => {   // Befehle mit eigenem Assistenten-Namen
    td.textContent = td.textContent.replace(/„[^,„]+,/g,`„${st.voice.assistant_name || "Otto"},`);
  });
  const mic = $("mic-status");
  mic.className = "mic " + (st.voice_error ? "err" : st.listening ? "on" : "");
  // Mikrofon-Pegel + Hinweise von Windows (zu leise, Rauschen …) + was zuletzt gehört wurde
  if (st.listening && st.mic) {
    const bars = Math.round(Math.min(100, st.mic.level) / 10);
    $("mic-level").innerHTML = (st.mic.device ? `🎙 Mikrofon: <b>${st.mic.device.replace(/</g, "&lt;")}</b> · ` : "") + `Pegel <span class="lvl">${"▮".repeat(bars)}<i>${"▮".repeat(10 - bars)}</i></span>` +
      (st.mic.note ? ` <b class="warn">⚠ ${st.mic.note}</b>` : bars === 0 ? " <span class='muted'>(sag mal was – bewegt sich der Balken nicht, hört Otto das falsche Mikrofon)</span>" : "") +
      (st.mic.heard.length ? `<div class="heard-list">${st.mic.heard.map((h) => `<div>${h.replace(/</g, "&lt;")}</div>`).join("")}</div>` : "");
  } else $("mic-level").innerHTML = "";
  mic.textContent = st.voice_error || (st.listening ? `🎤 Mikrofon aktiv${st.heard ? " · zuletzt verstanden: „" + st.heard + "“" : ""}` : "Sprachbefehle sind aus.");

  if (s) {
    $("lap").textContent = s.lap;
    $("laptime").textContent = fmt(s.lap_time_ms);
    $("speed").textContent = Math.round(s.speed_kmh);
    $("gear").textContent = s.gear < 0 ? "R" : s.gear === 0 ? "N" : s.gear;
    $("rpmbar").style.width = Math.min(100, (s.rpm / 9000) * 100) + "%";
    $("thr").style.height = s.throttle * 100 + "%";
    $("brk").style.height = s.brake * 100 + "%";
    $("lapprog").style.width = Math.max(0, s.lap_pos) * 100 + "%";
    const deg = steerDeg(s.steering, s.steer_range);
    $("wheel").style.transform = `rotate(${deg}deg)`;
    $("steer").textContent = fmtSteer(s.steering, s.steer_range);
    hist.push(s); if (hist.length > HISTORY) hist.shift();
  }
  $("best").textContent = fmt(st.best_ms);

  const d = st.delta_ms, el = $("delta");
  if (Date.now() - lastDeltaDraw > 200 || d == null) {   // max. 5x pro Sekunde neu -> lesbar
    lastDeltaDraw = Date.now();
    el.textContent = d == null ? "—" : (d > 0 ? "+" : "") + (d / 1000).toFixed(2);
  }
  el.className = "delta " + (d == null ? "" : d <= 0 ? "faster" : "slower");

  if (st.laps.length !== lastLapCount) {
    lastLapCount = st.laps.length;
    $("laptable").innerHTML = st.laps.slice().reverse()
      .map((l) => `<tr class="${l.time_ms === st.best_ms ? "best" : ""}"><td>Runde ${l.lap}${l.full ? "" : ' <span class="muted">(unvollst.)</span>'}</td><td>${fmt(l.time_ms)}</td></tr>`).join("")
      || `<tr><td class="muted">Noch keine vollständige Runde</td><td></td></tr>`;
  }
  // Zeichnen nur, wenn die Live-Seite sichtbar ist und neue Daten da sind
  if (liveVisible() && s && s !== lastDrawn) { drawMap(s); drawChart(); lastDrawn = s; }
  LAST_CONNECTED = st.connected;
}

let trackTimer = 0, lastDrawn = null, LAST_CONNECTED = false;
const liveVisible = () => !document.hidden && $("page-live").classList.contains("active");
async function loop() {
  try {
    await tick();
    if (++trackTimer % 15 === 0 && liveVisible() && document.hasFocus()) track = (await window.pywebview.api.track()).track;
  } catch (e) { console.error(e); }
  // Takt: 30x/s nur beim Fahren mit sichtbarer Live-Seite – sonst deutlich seltener (spart CPU)
  // Spiel im Vordergrund (Hauptfenster ohne Fokus): nur 4x/s – das Overlay ist dann die Anzeige
  const ms = document.hidden ? 1000 : !LAST_CONNECTED ? 500 : !document.hasFocus() ? 250 : liveVisible() ? 33 : 250;
  setTimeout(loop, ms);
}
window.addEventListener("pywebviewready", loop);

// Entwickler-Version: LMU-Simulator als Datenquelle anbieten
window.addEventListener("pywebviewready", async () => {
  try {
    if (await window.pywebview.api.dev_mode()) {
      const o = document.createElement("option");
      o.value = "devsim"; o.textContent = "🧪 LMU-Simulator (Entwickler)";
      $("source").appendChild(o);
    }
  } catch (e) { /* ältere Version */ }
});
$("source").addEventListener("change", (e) => { if (e.target.value === "devsim") window.pywebview.api.devsim_open(); });

// Beim Start: gibt es online ein neues Update? -> Hinweis oben
window.addEventListener("pywebviewready", () => setTimeout(async () => {
  try {
    const u = await window.pywebview.api.check_update_quiet();
    if (u && u.ok && u.latest === false) {
      $("upd-banner").innerHTML = `✨ Neues Update ${u.version} verfügbar${u.notes ? " – " + u.notes : ""} · <button class="ghost" id="upd-now">Jetzt installieren</button>`;
      $("upd-banner").style.display = "block";
      $("upd-now").addEventListener("click", async () => {
        $("upd-banner").textContent = "🔄 Lade Update …";
        const r = await window.pywebview.api.check_update();
        if (r.ok && r.version) { $("upd-banner").textContent = "✓ Update geladen – Otto startet in ~8 s neu …"; setTimeout(() => window.pywebview.api.restart(), 800); }
        else $("upd-banner").textContent = "⚠ " + r.msg;
      });
    }
  } catch (e) { console.error(e); }
}, 6000));

// KI-Engineer: Schlüssel speichern/testen (der Schlüssel selbst wird nie angezeigt)
async function aiInfo() {
  const i = await window.pywebview.api.engineer_info();
  $("ai-key").placeholder = i.key ? `gespeichert (${i.key})` : "AIza…";
  return i;
}
window.addEventListener("pywebviewready", aiInfo);
$("ai-save").addEventListener("click", async () => {
  const k = $("ai-key").value.trim();
  if (!k) return;
  await window.pywebview.api.engineer_save_key(k);
  $("ai-key").value = "";
  await aiInfo();
  $("ai-status").textContent = "✓ Gespeichert – jetzt „Funkcheck testen“.";
});
$("ai-del").addEventListener("click", async () => { await window.pywebview.api.engineer_save_key(""); await aiInfo(); $("ai-status").textContent = "Schlüssel gelöscht."; });
$("ai-test").addEventListener("click", () => { $("ai-status").textContent = "📻 frage den Engineer …"; window.pywebview.api.engineer_test(); });

$("mic-settings").addEventListener("click", () => window.pywebview.api.open_mic_settings());
// Mikrofone zur Auswahl + Mikro-Test (zeigt, in welchem Mikro deine Stimme ankommt)
window.addEventListener("pywebviewready", async () => {
  try {
    const devs = await window.pywebview.api.mic_devices();
    $("mic-dev").innerHTML = `<option value="">Windows-Standard</option>` + devs.map((d) => `<option value="${d.replace(/"/g, "&quot;")}">${d}</option>`).join("");
  } catch (e) { console.error(e); }
});
$("mic-probe").addEventListener("click", async () => {
  $("probe-out").textContent = "🎙 Jetzt sprechen …";
  const res = await window.pywebview.api.mic_probe();
  const best = res.reduce((a, b) => (b.level > a.level ? b : a), { level: -1 });
  $("probe-out").innerHTML = res.map((r) => `<div>${r.level < 0 ? "✖" : "▮".repeat(Math.round(r.level / 10)) || "·"} <b>${r.name}</b> ${r.level < 0 ? "(nicht nutzbar)" : r.level}</div>`).join("") +
    (best.level > 25 ? `<div>👉 Deine Stimme kommt bei <b>${best.name}</b> an – oben als Mikrofon wählen.</div>` : "<div class='warn'>⚠ In keinem Mikro kam deine Stimme an – Headset angesteckt / stummgeschaltet?</div>");
});

// „Was ist neu?“ – nach einem Update einmal beim Start, sonst über Einstellungen › System
function showNews(entries, ver) {
  $("news-ver").textContent = "Version " + ver;
  $("news-body").innerHTML = entries.map((e) =>
    `<h4>${e.title}<small>${e.version}</small></h4><ul>${e.items.map((i) => `<li>${i}</li>`).join("")}</ul>`).join("");
  $("newsmodal").classList.add("open");
}
window.addEventListener("pywebviewready", async () => {
  try {
    const n = await window.pywebview.api.whats_new();
    if (n && n.show) setTimeout(() => showNews(n.entries, n.version), 600);
  } catch (e) { console.error(e); }
});
$("news-close").addEventListener("click", () => { $("newsmodal").classList.remove("open"); window.pywebview.api.whats_new_seen(); });
$("news-open").addEventListener("click", async () => { const n = await window.pywebview.api.whats_new(); showNews(n.all, n.version); });
