// 3D-Replay: Neon-Strecke mit Curbs, Autos von außen, Verfolgerkamera, Gas/Bremse/Lenkung
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";

const $ = (id) => document.getElementById(id);
const api = () => window.pywebview.api;
const V = { file: null, data: null, t: 0, playing: false, rate: 1, last: 0, cam: "chase", follow: "me",
  showLine: false, showCars: true, origin: null };
const CLASS_COL = { Hyper: 0xff8a3d, LMP2: 0x3d8bff, GT3: 0x39ff88, LMGT3: 0x39ff88, GTE: 0x39ff88 };

// ---------------------------------------------------------------- Szene
const canvas = $("v-canvas");
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
} catch (e) {
  $("v-empty").style.display = "block";
  $("v-empty").textContent = "3D konnte nicht starten (WebGL/Grafiktreiber): " + e.message;
  throw e;
}
renderer.setPixelRatio(Math.max(1.5, Math.min(2, window.devicePixelRatio)));   // schärfer, auch auf 1080p
renderer.toneMapping = THREE.ACESFilmicToneMapping;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x020306);
scene.fog = new THREE.FogExp2(0x020306, 0.0018);
const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 6000);
camera.position.set(0, 80, 80);
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.enabled = false;

scene.add(new THREE.HemisphereLight(0x6f8bb0, 0x05070a, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 1.8);
sun.position.set(-60, 140, 50);
scene.add(sun);
const rim = new THREE.DirectionalLight(0x00e5ff, 0.6);
rim.position.set(80, 40, -80);
scene.add(rim);
const grid = new THREE.GridHelper(6000, 300, 0x0d2530, 0x081218);
grid.material.transparent = true; grid.material.opacity = 0.45;
scene.add(grid);

// Nachbearbeitung schaltet die normale Kantenglättung aus -> eigenes Multisample-Ziel (MSAA)
const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(1, 1, { samples: 4, type: THREE.HalfFloatType }));
composer.addPass(new RenderPass(scene, camera));
composer.addPass(new UnrealBloomPass(new THREE.Vector2(1, 1), 0.32, 0.25, 0.4));   // dezentes Leuchten
composer.addPass(new OutputPass());

const trackGroup = new THREE.Group();
const carsGroup = new THREE.Group();
scene.add(trackGroup, carsGroup);
let lineObj = null;
let others = [];   // [{data, obj}]

// ---------------------------------------------------------------- Koordinaten
// Spiel (x, y, z) -> Welt (x, y, -z), um die Streckenmitte zentriert (Genauigkeit)
const W = (x, y, z) => new THREE.Vector3(x - V.origin.x, y - V.origin.y, -(z - V.origin.z));

function ribbon(points, color, opts = {}) {
  const g = new THREE.BufferGeometry(), p = [], ix = [];
  points.forEach(([a, b], i) => {
    p.push(a.x, a.y, a.z, b.x, b.y, b.z);
    if (i < points.length - 1) { const k = i * 2; ix.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
  });
  g.setAttribute("position", new THREE.Float32BufferAttribute(p, 3)); g.setIndex(ix);
  return new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide, ...opts }));
}

// ---------------------------------------------------------------- Strecke
function buildTrack(tr, curbs, offs) {
  trackGroup.clear();
  const n = tr.x.length, C = [], N = [];
  for (let i = 0; i < n; i++) {
    C.push([tr.x[i], tr.y[i], tr.z[i]]);
    const a = Math.max(0, i - 2), b = Math.min(n - 1, i + 2);
    const dx = tr.x[b] - tr.x[a], dz = tr.z[b] - tr.z[a], l = Math.hypot(dx, dz) || 1;
    N.push([-dz / l, dx / l]);                     // "linke" Normale im Spiel-Koordinatensystem
  }
  // Punkt quer zur Strecke; Höhe folgt der Querneigung (Daytona-Steilkurven)
  const edge = (i, side, off = 0, lift = 0) => {
    const h = (tr.half[i] + off) * side;
    return W(C[i][0] + N[i][0] * h, C[i][1] + tr.bank[i] * h + lift, C[i][2] + N[i][1] * h);
  };
  V.edge = edge; V.N = N;
  const strip = (side, o0, o1, lift) => Array.from({ length: n }, (_, i) => [edge(i, side, o0, lift), edge(i, side, o1, lift)]);

  // Fahrbahn (mit leichtem Glanz)
  const road = ribbon(Array.from({ length: n }, (_, i) => [edge(i, 1), edge(i, -1)]), 0);
  road.material = new THREE.MeshStandardMaterial({ color: 0x1a2232, emissive: 0x0c121c, roughness: 0.7, metalness: 0.2, side: THREE.DoubleSide });
  road.geometry.computeVertexNormals();
  trackGroup.add(road);
  for (const side of [1, -1]) {
    trackGroup.add(ribbon(strip(side, -0.55, -0.35, 0.03), 0xc8d4e4, { transparent: true, opacity: 0.55 }));  // weiße Linie
    trackGroup.add(ribbon(strip(side, 1.5, 1.75, 0.04), 0x00b8d4));                                          // Neon-Rand außen
    // Böschung: Steilkurven bekommen eine sichtbare Wand nach unten
    const wall = Array.from({ length: n }, (_, i) => { const t = edge(i, side, 1.75, 0.04); return [t, new THREE.Vector3(t.x, Math.min(t.y, -V.origin.y + C[i][1] - 0.5), t.z)]; });
    trackGroup.add(ribbon(wall, 0x06090f, { transparent: true, opacity: 0.9 }));
  }

  // Curbs: rot/weiße Streifen (2 m) direkt an der Kante
  const red = [], white = [];
  for (const c of curbs) {
    for (let i = c.from; i < c.to && i < n - 1; i++) {
      const i0 = edge(i, c.side, -0.3, 0.06), i1 = edge(i + 1, c.side, -0.3, 0.06);
      const o0 = edge(i, c.side, 1.3, 0.06), o1 = edge(i + 1, c.side, 1.3, 0.06);
      for (let s = 0; s < 2; s++) {
        const a = i0.clone().lerp(i1, s / 2), b = i0.clone().lerp(i1, (s + 1) / 2);
        const d = o0.clone().lerp(o1, s / 2), e = o0.clone().lerp(o1, (s + 1) / 2);
        const arr = (i * 2 + s) % 2 ? white : red;
        for (const v of [a, d, b, d, e, b]) arr.push(v.x, v.y, v.z);
      }
    }
  }
  for (const [arr, col] of [[red, 0xd8264a], [white, 0xb8c6d6]]) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(arr, 3));
    trackGroup.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide, transparent: true, opacity: 0.75 })));
  }

  // Start/Ziel als Schachbrett-Linie
  const s0 = edge(0, 1, 0, 0.07), s1 = edge(0, -1, 0, 0.07);
  trackGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([s0, s1]), new THREE.LineBasicMaterial({ color: 0xffffff })));

  // Ausritte: rot pulsierende Ringe
  for (const o of offs) {
    const p = W(o.x, nearestY(tr, o.x, o.z) + 0.1, o.z);
    const ring = new THREE.Mesh(new THREE.RingGeometry(3.5, 4.2, 40), new THREE.MeshBasicMaterial({
      color: o.severe ? 0xff3b5c : 0xffa53d, side: THREE.DoubleSide, transparent: true, opacity: 0.9 }));
    ring.rotation.x = -Math.PI / 2; ring.position.copy(p); ring.userData.pulse = true;
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 14, 8), new THREE.MeshBasicMaterial({
      color: o.severe ? 0xff3b5c : 0xffa53d, transparent: true, opacity: 0.6 }));
    beam.position.copy(p).add(new THREE.Vector3(0, 7, 0));
    trackGroup.add(ring, beam);
  }
}
function nearestY(tr, x, z) {
  let best = Infinity, y = 0;
  for (let i = 0; i < tr.x.length; i += 2) { const d = (tr.x[i] - x) ** 2 + (tr.z[i] - z) ** 2; if (d < best) { best = d; y = tr.y[i]; } }
  return y;
}

// Spur neben der Strecke: wo das Auto über den Rand hinaus war, leuchtet seine Spur rot
function buildOffPath(lap) {
  const segs = [];
  let cur = null;
  for (let i = 0; i < lap.x.length; i++) {
    const e = Math.abs(lap.track_edge[i]), over = e > 2 ? Math.abs(lap.path_lateral[i]) - e : 0;
    if (over > 1) { (cur ??= (segs.push([]), segs[segs.length - 1])).push(i); } else cur = null;
  }
  for (const seg of segs) {
    if (seg.length < 2) continue;
    const pts = seg.map((i, k) => {
      const j = seg[Math.min(seg.length - 1, k + 1)], h = seg[Math.max(0, k - 1)];
      const p = W(lap.x[i], lap.y[i] - 0.25, lap.z[i]), q = W(lap.x[j], lap.y[j], lap.z[j]).sub(W(lap.x[h], lap.y[h], lap.z[h]));
      const nx = -q.z, nz = q.x, l = Math.hypot(nx, nz) || 1;
      return [p.clone().add(new THREE.Vector3(nx / l * 1.1, 0, nz / l * 1.1)), p.clone().add(new THREE.Vector3(-nx / l * 1.1, 0, -nz / l * 1.1))];
    });
    trackGroup.add(ribbon(pts, 0xff3b5c, { transparent: true, opacity: 0.75 }));
  }
}

// Gefahrene Linie: grün = Gas, rot = Bremse
function buildLine(lap) {
  if (lineObj) scene.remove(lineObj);
  const pts = [], cols = [], c = new THREE.Color();
  for (let i = 0; i < lap.x.length; i += 2) {
    const p = W(lap.x[i], lap.y[i] + 0.12, lap.z[i]);
    pts.push(p.x, p.y, p.z);
    if (lap.brake[i] > 0.1) c.set(0xff3b5c); else if (lap.throttle[i] > 0.9) c.set(0x39ff88); else c.set(0xffd23f);
    cols.push(c.r, c.g, c.b);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(cols, 3));
  lineObj = new THREE.Line(g, new THREE.LineBasicMaterial({ vertexColors: true }));
  lineObj.visible = V.showLine;
  scene.add(lineObj);
}

// ---------------------------------------------------------------- Auto (nur außen)
const shadowTex = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const g = c.getContext("2d"), r = g.createRadialGradient(64, 64, 10, 64, 64, 64);
  r.addColorStop(0, "rgba(0,0,0,0.85)"); r.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = r; g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
})();

function labelSprite(text, color) {
  const c = document.createElement("canvas"); c.width = 128; c.height = 48;
  const g = c.getContext("2d");
  g.fillStyle = "rgba(5,6,10,.75)"; g.beginPath(); g.roundRect(4, 4, 120, 40, 10); g.fill();
  g.strokeStyle = color; g.lineWidth = 3; g.stroke();
  g.fillStyle = "#e8eef8"; g.font = "bold 24px JetBrains Mono, monospace"; g.textAlign = "center"; g.textBaseline = "middle";
  g.fillText(text, 64, 25);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
  s.scale.set(3.2, 1.2, 1); s.position.set(0, 2.6, 0);
  return s;
}

// style: "me" | "ghost" | "other"
function makeCar(edgeColor, style) {
  const car = new THREE.Group();
  const ghost = style === "ghost", other = style === "other";
  const bodyMat = ghost
    ? new THREE.MeshBasicMaterial({ color: edgeColor, transparent: true, opacity: 0.05, depthWrite: false })
    : new THREE.MeshStandardMaterial({ color: other ? 0x1a1f2a : 0x0d1626, metalness: 0.75, roughness: 0.3 });
  const edgeMat = new THREE.LineBasicMaterial({ color: edgeColor, transparent: true, opacity: ghost ? 0.4 : other ? 0.5 : 0.9 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x04060a, metalness: 0.9, roughness: 0.05, transparent: true, opacity: ghost ? 0.05 : 0.85 });
  const part = (pts, width, z = 0, mat = bodyMat, edges = true) => {
    const s = new THREE.Shape(); s.moveTo(...pts[0]); pts.slice(1).forEach((p) => s.lineTo(...p));
    const g = new THREE.ExtrudeGeometry(s, { depth: width, bevelEnabled: true, bevelSize: 0.04, bevelThickness: 0.04, bevelSegments: 2, curveSegments: 6 });
    g.translate(0, 0, z - width / 2);
    car.add(new THREE.Mesh(g, mat));
    if (edges) car.add(new THREE.LineSegments(new THREE.EdgesGeometry(g, 28), edgeMat));
  };
  const arch = (cx, len, h) => { const pts = []; for (let k = 0; k <= 10; k++) { const a = Math.PI * k / 10; pts.push([cx + Math.cos(a) * len, 0.42 + Math.sin(a) * h]); } return pts; };

  // Monocoque / Unterboden mit Splitter und Diffusor (vorne = +x)
  part([[2.55, 0.1], [2.6, 0.2], [2.2, 0.36], [1.5, 0.52], [0.6, 0.56], [-1.2, 0.6], [-2.2, 0.72], [-2.45, 0.62], [-2.5, 0.25], [-2.3, 0.1]], 1.25);
  // Seitenkästen
  for (const z of [0.72, -0.72]) part([[0.9, 0.12], [0.9, 0.42], [0.2, 0.55], [-1.6, 0.6], [-2.2, 0.55], [-2.2, 0.12]], 0.42, z);
  // Kotflügel über den Rädern
  for (const z of [0.82, -0.82]) {
    part([...arch(1.55, 0.62, 0.42), [0.9, 0.42], [0.9, 0.3], [2.25, 0.3]], 0.38, z);
    part([...arch(-1.5, 0.62, 0.46), [-2.2, 0.42], [-2.2, 0.3], [-0.85, 0.3]], 0.4, z);
  }
  // Cockpit-Kuppel + Scheibe + Finne
  part([[1.15, 0.56], [0.45, 1.02], [-0.55, 1.1], [-1.1, 0.88], [-1.5, 0.62]], 0.98);
  part([[1.05, 0.62], [0.47, 0.98], [0.25, 1.02], [0.75, 0.62]], 0.9, 0, glassMat, false);
  part([[-0.6, 1.05], [-2.3, 1.18], [-2.3, 0.75], [-1.3, 0.72]], 0.05);
  // Heckflügel mit Endplatten und Schwanenhals-Halterung
  const wing = new THREE.BoxGeometry(0.42, 0.05, 1.95); wing.translate(-2.3, 1.22, 0);
  car.add(new THREE.Mesh(wing, bodyMat), new THREE.LineSegments(new THREE.EdgesGeometry(wing), edgeMat));
  for (const z of [-0.99, 0.99]) {
    const ep = new THREE.BoxGeometry(0.62, 0.38, 0.03); ep.translate(-2.28, 1.1, z);
    car.add(new THREE.Mesh(ep, bodyMat), new THREE.LineSegments(new THREE.EdgesGeometry(ep), edgeMat));
  }
  for (const z of [-0.35, 0.35]) { const st = new THREE.BoxGeometry(0.12, 0.42, 0.03); st.translate(-2.15, 1.0, z); car.add(new THREE.Mesh(st, bodyMat)); }
  // Licht: Scheinwerfer-Streifen und durchgehendes Rücklicht (leuchten dank Bloom)
  if (!ghost) {
    const head = new THREE.MeshBasicMaterial({ color: 0xf2f7ff });
    for (const z of [0.62, -0.62]) { const h = new THREE.BoxGeometry(0.05, 0.04, 0.32); h.translate(2.18, 0.42, z); car.add(new THREE.Mesh(h, head)); }
    const tail = new THREE.BoxGeometry(0.04, 0.035, 1.8); tail.translate(-2.47, 0.66, 0);
    car.userData.tail = new THREE.MeshBasicMaterial({ color: 0x801020 });
    car.add(new THREE.Mesh(tail, car.userData.tail));
  }
  // Räder: Reifen + Felge, vorne lenkbar
  const tyre = new THREE.CylinderGeometry(0.36, 0.36, 0.3, 28); tyre.rotateX(Math.PI / 2);
  const rimG = new THREE.CylinderGeometry(0.24, 0.24, 0.31, 12); rimG.rotateX(Math.PI / 2);
  const tyreMat = ghost ? bodyMat : new THREE.MeshStandardMaterial({ color: 0x050608, roughness: 0.9 });
  const rimMat = ghost ? bodyMat : new THREE.MeshStandardMaterial({ color: 0x2a3140, metalness: 0.9, roughness: 0.3 });
  car.userData.front = [];
  for (const [x, z, front] of [[1.55, 0.86, 1], [1.55, -0.86, 1], [-1.5, 0.86, 0], [-1.5, -0.86, 0]]) {
    const pivot = new THREE.Group(); pivot.position.set(x, 0.36, z);
    pivot.add(new THREE.Mesh(tyre, tyreMat), new THREE.Mesh(rimG, rimMat), new THREE.LineSegments(new THREE.EdgesGeometry(rimG, 30), edgeMat));
    car.add(pivot);
    if (front) car.userData.front.push(pivot);
  }
  // weicher Schatten
  if (!ghost) {
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(6.2, 3.2), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.y = 0.03; car.add(sh);
  }
  car.rotation.order = "YZX";
  return car;
}
const car = makeCar(0x00e5ff, "me");
const ghostCar = makeCar(0xff2d95, "ghost");
scene.add(car, ghostCar);
ghostCar.visible = false;

// ---------------------------------------------------------------- Abspielen
function idxAt(arr, t, t0 = arr[0]) {
  let lo = 0, hi = arr.length - 1;
  while (lo < hi) { const m = (lo + hi + 1) >> 1; arr[m] - t0 <= t ? (lo = m) : (hi = m - 1); }
  return lo;
}
function pose(src, i, f, look = 4) {
  const j = Math.min(src.x.length - 1, i + 1);
  const p = W(src.x[i] + f * (src.x[j] - src.x[i]), src.y[i] + f * (src.y[j] - src.y[i]), src.z[i] + f * (src.z[j] - src.z[i]));
  const k = Math.min(src.x.length - 1, i + look), b = Math.max(0, i - look);
  const dir = W(src.x[k], src.y[k], src.z[k]).sub(W(src.x[b], src.y[b], src.z[b]));
  const horiz = Math.hypot(dir.x, dir.z) || 1;
  return { i, p, yaw: Math.atan2(-dir.z, dir.x), pitch: Math.atan2(dir.y, horiz), dir: new THREE.Vector3(dir.x / horiz, 0, dir.z / horiz) };
}
function lapPose(lap, t) {
  const i = idxAt(lap.lap_time_ms, t), j = Math.min(lap.x.length - 1, i + 1), t0 = lap.lap_time_ms[0];
  const ti = lap.lap_time_ms[i] - t0, tj = lap.lap_time_ms[j] - t0;
  return pose(lap, i, tj > ti ? Math.min(1, (t - ti) / (tj - ti)) : 0);
}
// Querneigung an einer Streckenstelle -> Rollwinkel des Autos (Steilkurven)
function rollAt(distM, ps) {
  const tr = V.data.track, n = tr.bank.length;
  const i = Math.max(0, Math.min(n - 1, Math.round(distM / V.data.step_m)));
  const nx = V.N[i][0], nz = -V.N[i][1];              // Streckennormale in Weltkoordinaten
  const side = Math.sign(nx * -ps.dir.z + nz * ps.dir.x) || 1;   // zeigt die linke Autoseite dorthin?
  return -Math.atan(tr.bank[i]) * side;
}
function setPose(obj, ps, steering = 0, roll = 0) {
  obj.position.copy(ps.p);
  obj.rotation.set(roll, ps.yaw, ps.pitch);
  for (const w of obj.userData.front || []) w.rotation.y = -steering * 0.42;   // ~24° Radeinschlag
}
// Catmull-Rom: weiche Kurve durch die (nur 5x/s gemessenen) Positionen anderer Autos
function catmull(a, b, c, d, f) {
  const f2 = f * f, f3 = f2 * f;
  return 0.5 * (2 * b + (-a + c) * f + (2 * a - 5 * b + 4 * c - d) * f2 + (-a + 3 * b - 3 * c + d) * f3);
}
const smooth = (rate, dt) => 1 - Math.exp(-rate * dt);   // bildratenunabhängiges Nachziehen

// Andere Autos: Zeitbasis = Aufnahme-Zeit t (Hauptdatei und Auto-Datei teilen sie)
function buildOthers(list) {
  carsGroup.clear();
  others = list.map((d) => {
    const col = CLASS_COL[d.cls] ?? 0x9aa6b8;
    const obj = makeCar(col, "other");
    const num = (d.car.match(/#(\d+)/) || [])[1];
    if (num) obj.add(labelSprite("#" + num, "#" + col.toString(16).padStart(6, "0")));
    carsGroup.add(obj);
    return { d, obj, num: num || d.id };
  });
  $("v-follow").innerHTML = `<option value="me">Du</option>` + others
    .map((o, k) => ({ o, k })).sort((a, b) => (+a.o.num) - (+b.o.num))
    .map(({ o, k }) => `<option value="${k}">#${o.num} · ${o.d.car.replace(/\s*#.*$/, "")}</option>`).join("");
  $("v-follow").value = "me"; V.follow = "me";
  $("v-follow").style.display = others.length ? "" : "none";
}
function otherPose(o, tRec) {
  const d = o.d;
  if (tRec < d.t[0] || tRec > d.t[d.t.length - 1]) return null;
  const n = d.t.length, i = idxAt(d.t, tRec, 0), j = Math.min(n - 1, i + 1);
  const h = Math.max(0, i - 1), k = Math.min(n - 1, j + 1);
  const f = d.t[j] > d.t[i] ? Math.min(1, (tRec - d.t[i]) / (d.t[j] - d.t[i])) : 0;
  const at = (ff) => W(catmull(d.x[h], d.x[i], d.x[j], d.x[k], ff), catmull(d.y[h], d.y[i], d.y[j], d.y[k], ff), catmull(d.z[h], d.z[i], d.z[j], d.z[k], ff));
  const p = at(f), q = at(Math.min(1.2, f + 0.15)), r = at(Math.max(-0.2, f - 0.15));
  const dir = q.sub(r), horiz = Math.hypot(dir.x, dir.z) || 1;
  return { p, yaw: Math.atan2(-dir.z, dir.x), pitch: Math.atan2(dir.y, horiz), dir: new THREE.Vector3(dir.x / horiz, 0, dir.z / horiz),
    speed: d.speed_kmh[i] + f * (d.speed_kmh[j] - d.speed_kmh[i]), dist: d.lap_dist[i] + f * (d.lap_dist[j] - d.lap_dist[i]) };
}

function updateHud(lap, i, follow) {
  $("v-lt").textContent = fmt(V.t);
  const me = !follow;
  $("v-hud").classList.toggle("other", !me);
  $("v-speed").textContent = Math.round(me ? lap.speed_kmh[i] : follow.speed);
  if (me) {
    const g = lap.gear[i]; $("v-gear").textContent = g < 0 ? "R" : g === 0 ? "N" : g;
    $("v-thr").style.height = lap.throttle[i] * 100 + "%";
    $("v-brk").style.height = lap.brake[i] * 100 + "%";
    $("v-wheel").style.transform = `rotate(${steerDeg(lap.steering[i], lap.steer_range[i])}deg)`;
    $("v-steer").textContent = fmtSteer(lap.steering[i], lap.steer_range[i]);
  } else {
    $("v-gear").textContent = "#" + follow.num;
  }
  $("v-seek").value = (V.t / lap.time_ms) * 1000;
  $("v-play").textContent = V.playing ? "❚❚" : "▶";
}

// Abstand zum Geist: Zeit, zu der der Geist an deiner aktuellen Position war
function ghostGap(ps) {
  const gh = V.data.ghost; if (!gh) return null;
  let best = Infinity, bi = 0;
  const scan = (a, b) => { for (let k = a; k < b; k++) { const q = W(gh.x[k], gh.y[k], gh.z[k]); const d = q.distanceToSquared(ps.p); if (d < best) { best = d; bi = k; } } };
  scan(Math.max(0, (V._gi || 0) - 200), Math.min(gh.x.length, (V._gi || 0) + 400));
  if (best > 400) { best = Infinity; scan(0, gh.x.length); }
  V._gi = bi;
  return V.t - (gh.lap_time_ms[bi] - gh.lap_time_ms[0]);
}

const tmp = new THREE.Vector3();
function frame(now) {
  // 3D nur rendern, wenn die Seite sichtbar ist – sonst 2x pro Sekunde nachschauen (spart CPU/GPU)
  if (document.hidden || !$("page-view3d").classList.contains("active") || !V.data) {
    V.last = performance.now();
    return setTimeout(() => requestAnimationFrame(frame), 500);
  }
  requestAnimationFrame(frame);
  resize();
  const lap = V.data.lap;
  const dt = Math.min(0.1, (now - V.last) / 1000);
  if (V.playing) {
    V.t += dt * 1000 * V.rate;
    if (V.stopAt != null && V.t >= V.stopAt) { V.t = V.stopAt; V.playing = false; V.stopAt = null; }
    if (V.t >= lap.time_ms) { V.t = lap.time_ms; V.playing = false; }
  }
  V.last = now;
  const L = V.data.track_len;
  const ps = lapPose(lap, V.t);
  setPose(car, ps, lap.steering[ps.i], rollAt(lap.lap_pos[ps.i] * L, ps));
  if (car.userData.tail) car.userData.tail.color.set(lap.brake[ps.i] > 0.1 ? 0xff2040 : 0x801020);   // Bremslicht
  if (V.data.ghost && ghostCar.visible) {
    const gh = V.data.ghost, gp = lapPose(gh, Math.min(V.t, gh.time_ms));
    setPose(ghostCar, gp, gh.steering[gp.i], rollAt(gh.lap_pos[gp.i] * L, gp));
  }
  // andere Autos
  const tRec = lap.t[ps.i];
  let followPose = null;
  others.forEach((o, k) => {
    const op = V.showCars ? otherPose(o, tRec) : null;
    o.obj.visible = !!op;
    if (op) {
      setPose(o.obj, op, 0, op.dist > 0 && op.dist < L ? rollAt(op.dist, op) : 0);
      if (String(k) === V.follow) followPose = { ...op, num: o.num };
    }
    const label = o.obj.children.find((c) => c.isSprite);
    if (label) label.visible = String(k) !== V.follow;   // verfolgtes Auto ohne Schild
  });
  for (const m of trackGroup.children) if (m.userData.pulse) m.material.opacity = 0.55 + 0.4 * Math.sin(now / 250);

  updateHud(lap, ps.i, followPose);
  const gap = followPose ? null : ghostGap(ps);
  $("v-gap").textContent = gap == null ? "" : `${gap > 0 ? "+" : ""}${(gap / 1000).toFixed(2)} s zum Geist`;
  $("v-gap").className = "v-gap " + (gap == null ? "" : gap > 0 ? "neg" : "pos");

  // Kamera
  const tgt = followPose || ps;
  V.look ??= tgt.p.clone();
  // Kamera kippt in Steilkurven teilweise mit (wie eine TV-Verfolgerkamera)
  const tgtObj = followPose ? others[+V.follow].obj : car;
  const upWant = V.cam === "chase" ? new THREE.Vector3(0, 1, 0).applyQuaternion(tgtObj.quaternion).lerp(tmp.set(0, 1, 0), 0.35).normalize() : tmp.set(0, 1, 0);
  camera.up.lerp(upWant, smooth(5, dt)).normalize();
  if (V.cam === "chase") {
    camera.position.lerp(tgt.p.clone().addScaledVector(tgt.dir, -12).add(tmp.set(0, 5.2, 0)), smooth(7, dt));
    V.look.lerp(tgt.p.clone().addScaledVector(tgt.dir, 8).add(tmp.set(0, 0.8, 0)), smooth(12, dt));
    camera.lookAt(V.look);
  } else if (V.cam === "heli") {
    camera.position.lerp(tgt.p.clone().add(tmp.set(0, 140, 0.1)), smooth(5, dt));
    V.look.lerp(tgt.p, smooth(10, dt));
    camera.lookAt(V.look);
  } else if (V.cam === "lesson") {
    // Lehrmodus: schräg von der Seite über der Kurve, Auto im Blick
    V.look.lerp(tgt.p, smooth(6, dt));
    camera.position.lerp(V.lessonCam, smooth(3, dt));
    camera.lookAt(V.look);
  } else {
    controls.target.lerp(tgt.p, smooth(10, dt));
    controls.update();
  }
  composer.render();
}
requestAnimationFrame(frame);

function resize() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (!w || !h) return;
  if (canvas.width !== Math.floor(w * renderer.getPixelRatio()) || canvas.height !== Math.floor(h * renderer.getPixelRatio())) {
    renderer.setSize(w, h, false);
    composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(w, h);
    camera.aspect = w / h; camera.updateProjectionMatrix();
  }
}

// ---------------------------------------------------------------- Kurven-Lehrmodus
const lessonGroup = new THREE.Group();
scene.add(lessonGroup);

function textSprite(text, color, w = 3.4) {
  const c = document.createElement("canvas"); c.width = 512; c.height = 96;
  const g = c.getContext("2d");
  g.fillStyle = "rgba(5,6,10,.85)"; g.beginPath(); g.roundRect(4, 4, 504, 88, 16); g.fill();
  g.strokeStyle = color; g.lineWidth = 5; g.stroke();
  g.fillStyle = "#fff"; g.font = "bold 40px Titillium Web, Segoe UI, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
  g.fillText(text, 256, 50);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
  s.scale.set(w * 2.6, w * 0.5, 1);
  return s;
}

// Querlinie über die Fahrbahn + Schild daneben
function marker(distM, color, label, height) {
  const tr = V.data.track, n = tr.x.length;
  const i = Math.max(0, Math.min(n - 2, Math.round(distM / V.data.step_m)));
  const a0 = V.edge(i, 1, 0.2, 0.09), b0 = V.edge(i, -1, 0.2, 0.09);
  const a1 = a0.clone().lerp(V.edge(i + 1, 1, 0.2, 0.09), 0.25), b1 = b0.clone().lerp(V.edge(i + 1, -1, 0.2, 0.09), 0.25);
  lessonGroup.add(ribbon([[a0, b0], [a1, b1]], color));
  const s = textSprite(label, "#" + color.toString(16).padStart(6, "0"));
  s.position.copy(a0.clone().lerp(b0, 0.5)).add(new THREE.Vector3(0, height, 0));
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, height, 6), new THREE.MeshBasicMaterial({ color }));
  pole.position.copy(a0.clone().lerp(b0, 0.5)).add(new THREE.Vector3(0, height / 2, 0));
  lessonGroup.add(s, pole);
}

// Dauerhafte Lernhilfen: Kurvenschilder + Brems-/Gaspunkte der Vorlage als Linien auf dem Asphalt
const guideGroup = new THREE.Group();
scene.add(guideGroup);
V.showLabels = true; V.showBrakes = true;

function buildGuides() {
  guideGroup.clear();
  const L = V.data && V.data.lesson;
  if (!L) return;
  const tr = V.data.track, n = tr.x.length;
  const across = (distM, color, opacity) => {
    const i = Math.max(0, Math.min(n - 2, Math.round(distM / V.data.step_m)));
    const a0 = V.edge(i, 1, 0.1, 0.07), b0 = V.edge(i, -1, 0.1, 0.07);
    const a1 = a0.clone().lerp(V.edge(i + 1, 1, 0.1, 0.07), 0.18), b1 = b0.clone().lerp(V.edge(i + 1, -1, 0.1, 0.07), 0.18);
    guideGroup.add(ribbon([[a0, b0], [a1, b1]], color, { transparent: true, opacity }));
  };
  for (const c of L.corners) {
    if (V.showBrakes) {
      if (c.ref.brake_m != null) across(c.ref.brake_m, 0xff3b5c, 0.85);
      if (c.ref.throttle_m != null) across(c.ref.throttle_m, 0x39ff88, 0.7);
    }
    if (V.showLabels) {
      const i = Math.max(0, Math.min(n - 1, Math.round(c.apex / V.data.step_m)));
      const s = textSprite(c.label, "#3a4458", 1.6);
      s.position.copy(W(tr.x[i], tr.y[i] + 7, tr.z[i]));
      s.material.depthTest = true;
      guideGroup.add(s);
    }
  }
}

function renderLessonList() {
  const L = V.data.lesson, el = $("v-lessons");
  const list = [...L.corners].sort((a, b) => b.loss_ms - a.loss_ms);
  el.innerHTML = list.map((c) => `<div class="v-lc ${c.loss_ms > 50 ? "bad" : c.loss_ms < -50 ? "good" : ""} ${V.lesson === c.name ? "sel" : ""}" data-c="${c.name}">
      <b>${c.label}</b><span>${c.loss_ms > 0 ? "+" : ""}${(c.loss_ms / 1000).toFixed(2)} s</span>
      ${c.title ? `<small>${c.title}</small>` : ""}</div>`).join("");
  el.querySelectorAll(".v-lc").forEach((d) => d.addEventListener("click", () => teach(d.dataset.c)));
}

async function teach(name) {
  const ref = V.data.lesson.ref_lap;
  if (!V.data.ghost || V.data.ghost.lap !== ref) await load(V.file, V.data.lap.lap, ref);
  const c = V.data.lesson.corners.find((k) => k.name === name); if (!c) return;
  V.lesson = name;
  lessonGroup.clear();
  const me = c.lap, gh = c.ref;
  if (me.brake_m != null) marker(me.brake_m, 0x00e5ff, "DU bremst", 4.2);
  if (gh.brake_m != null) marker(gh.brake_m, 0xff2d95, "GEIST bremst", 6.4);
  if (me.throttle_m != null) marker(me.throttle_m, 0x39ff88, "DU Vollgas", 4.2);
  if (gh.throttle_m != null) marker(gh.throttle_m, 0x9dffc6, "GEIST Vollgas", 6.4);
  marker(me.apex_m, 0xffd23f, `langsamste Stelle: ${Math.round(me.min_speed)} / ${Math.round(gh.min_speed)} km/h`, 9);

  // Kamera: schräg über der Kurvenaußenseite
  const tr = V.data.track, n = tr.x.length, a = Math.max(8, Math.min(n - 9, Math.round(c.apex / V.data.step_m)));
  const cr = (tr.x[a] - tr.x[a - 8]) * (tr.z[a + 8] - tr.z[a]) - (tr.z[a] - tr.z[a - 8]) * (tr.x[a + 8] - tr.x[a]);
  // zwischen Anbremspunkt und Scheitel, außen neben der Strecke, nicht zu hoch
  const bpIdx = Math.round(Math.min(me.brake_m ?? c.apex, gh.brake_m ?? c.apex) / V.data.step_m);
  const m = Math.max(0, Math.min(n - 1, Math.round((bpIdx + a) / 2)));
  V.lessonCam = V.edge(m, cr > 0 ? -1 : 1, 26, 16);
  V.cam = "lesson"; controls.enabled = false;
  document.querySelectorAll("#v-cam button").forEach((x) => x.classList.remove("on"));

  // Zeitlupe vom Anbremsen bis kurz nach dem Kurvenausgang
  const lap = V.data.lap, Ltr = V.data.track_len, t0 = lap.lap_time_ms[0];
  const timeAt = (m) => { const k = lap.lap_pos.findIndex((p) => p * Ltr >= m); return k < 0 ? lap.time_ms : lap.lap_time_ms[k] - t0; };
  const from = Math.max(0, Math.min(c.start, me.brake_m ?? c.start, gh.brake_m ?? c.start) - 120);
  V.lessonRange = [timeAt(from), timeAt(c.end + 80)];
  V.t = V.lessonRange[0]; V.stopAt = V.lessonRange[1]; V.rate = 0.5; V.playing = true;
  $("v-rate").value = "0.5";

  $("v-teach").style.display = "block";
  $("v-teach-title").textContent = `${c.label}${c.nick ? " (" + c.nick + ")" : ""} · ${c.loss_ms > 0 ? "+" : ""}${(c.loss_ms / 1000).toFixed(2)} s`;
  $("v-teach-what").textContent = c.title || (c.loss_ms < -50 ? "Hier warst du schneller als der Geist 👍" : "Kaum Unterschied");
  $("v-teach-text").textContent = c.text || "";
  const bp = me.brake_m != null && gh.brake_m != null ? Math.round(gh.brake_m - me.brake_m) : null;
  $("v-teach-facts").innerHTML = `
    <div><span>Bremspunkt</span><b>${bp == null ? "—" : Math.abs(bp) < 4 ? "gleich" : bp > 0 ? bp + " m früher als Geist" : -bp + " m später als Geist"}</b></div>
    <div><span>Langsamste Stelle</span><b>${Math.round(me.min_speed)} <em>/ ${Math.round(gh.min_speed)} km/h</em></b></div>
    <div><span>Ausgang</span><b>${Math.round(me.exit_speed)} <em>/ ${Math.round(gh.exit_speed)} km/h</em></b></div>`;
  renderLessonList();
}

function endLesson() {
  V.lesson = null; V.stopAt = null; lessonGroup.clear();
  $("v-teach").style.display = "none";
  V.cam = "chase";
  document.querySelectorAll("#v-cam button").forEach((x) => x.classList.toggle("on", x.dataset.cam === "chase"));
  if (V.data) renderLessonList();
}
$("v-teach-again").addEventListener("click", () => { if (V.lessonRange) { V.t = V.lessonRange[0]; V.stopAt = V.lessonRange[1]; V.playing = true; } });
$("v-teach-close").addEventListener("click", endLesson);
window.otto3d = { debug: () => ({ camera, controls, V, car }), open: async (file, lap, ref, corner) => {
  V.file = file;                      // damit die Seite nicht erst die neueste Session lädt
  document.querySelector('[data-page="view3d"]').click();
  await load(file, lap, ref);
  if (corner) await teach(corner);
} };

// ---------------------------------------------------------------- Laden / Bedienung
const lapLabel = (l, best) => `R${l.lap} · ${fmt(l.time_ms)}${!l.full ? " (unvollst.)" : l.severe ? " ⚠ Ausritt" : l.offs ? " ⚠" : ""}${l.lap === best ? " ★" : ""}`;

async function loadSessions() {
  const list = (await api().sessions()).filter((s) => s.game !== "Simulator");
  $("v-session").innerHTML = list.map((s) => `<option value="${s.file}">${s.date} · ${s.info}</option>`).join("");
  if (!list.length) return showEmpty("Noch keine Aufnahmen.");
  if (!V.file || !list.some((s) => s.file === V.file)) await load(list[0].file);
  else $("v-session").value = V.file;
}

function showEmpty(msg) {
  $("v-empty").textContent = msg; $("v-empty").style.display = msg ? "block" : "none";
}

async function load(file, lap = null, ghost = null) {
  V.file = file;
  const d = await api().view3d(file, lap, ghost);
  if (d.error) { V.data = null; return showEmpty(d.error); }
  showEmpty("");
  V.data = d; V.t = 0; V.playing = false; V._gi = 0;
  const tr = d.track;
  V.origin = { x: tr.x.reduce((a, b) => a + b) / tr.x.length, y: Math.min(...tr.y), z: tr.z.reduce((a, b) => a + b) / tr.z.length };
  buildTrack(tr, d.curbs, d.offs);
  buildOffPath(d.lap);
  buildLine(d.lap);
  lessonGroup.clear(); V.lesson = null; V.stopAt = null; $("v-teach").style.display = "none";
  buildGuides();
  renderLessonList();
  buildOthers(d.cars || []);
  ghostCar.visible = !!d.ghost;
  $("v-session").value = file;
  $("v-lap").innerHTML = d.laps.map((l) => `<option value="${l.lap}">${lapLabel(l, d.best_lap)}</option>`).join("");
  $("v-lap").value = d.lap.lap;
  $("v-ghost").innerHTML = `<option value="">kein Geist</option>` + d.laps.filter((l) => l.full)
    .map((l) => `<option value="${l.lap}">${lapLabel(l, d.best_lap)}</option>`).join("");
  $("v-ghost").value = d.ghost ? d.ghost.lap : "";
  const notes = [];
  if (tr.source === "estimated") notes.push("Streckenränder geschätzt");
  if (d.offs.length) notes.push(`${d.offs.length}× neben der Strecke (rote/orange Markierung)`);
  notes.push("Curbs angedeutet");
  $("v-note").textContent = notes.join(" · ");
  camera.position.set(0, 300, 300); controls.target.set(0, 0, 0);
}

document.querySelector('[data-page="view3d"]').addEventListener("click", loadSessions);
$("v-session").addEventListener("change", (e) => load(e.target.value));
const reload = () => load(V.file, +$("v-lap").value, $("v-ghost").value === "" ? null : +$("v-ghost").value);
$("v-lap").addEventListener("change", reload);
$("v-ghost").addEventListener("change", reload);
$("v-follow").addEventListener("change", (e) => (V.follow = e.target.value));
$("v-play").addEventListener("click", () => { V.playing = !V.playing; });
$("v-rate").addEventListener("change", (e) => (V.rate = parseFloat(e.target.value)));
$("v-seek").addEventListener("input", (e) => { if (V.data) V.t = (e.target.value / 1000) * V.data.lap.time_ms; });
document.querySelectorAll("#v-cam button").forEach((b) => b.addEventListener("click", () => {
  V.cam = b.dataset.cam; controls.enabled = V.cam === "free"; V.stopAt = null;
  document.querySelectorAll("#v-cam button").forEach((x) => x.classList.toggle("on", x === b));
}));
$("v-line").querySelector("button").addEventListener("click", (e) => {
  V.showLine = !V.showLine; e.target.classList.toggle("on", V.showLine); if (lineObj) lineObj.visible = V.showLine;
});
$("v-carsbtn").addEventListener("click", (e) => { V.showCars = !V.showCars; e.target.classList.toggle("on", V.showCars); });
$("v-labelsbtn").addEventListener("click", (e) => { V.showLabels = !V.showLabels; e.target.classList.toggle("on", V.showLabels); buildGuides(); });
$("v-brakesbtn").addEventListener("click", (e) => { V.showBrakes = !V.showBrakes; e.target.classList.toggle("on", V.showBrakes); buildGuides(); });
window.addEventListener("keydown", (e) => {
  if (!$("page-view3d").classList.contains("active") || !V.data || e.target.tagName === "SELECT") return;
  if (e.code === "Space") { V.playing = !V.playing; e.preventDefault(); }
  if (e.code === "ArrowRight") V.t = Math.min(V.data.lap.time_ms, V.t + 1000);
  if (e.code === "ArrowLeft") V.t = Math.max(0, V.t - 1000);
});
