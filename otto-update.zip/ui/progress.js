// Fortschritt: Bestzeiten pro Strecke, Entwicklung über Sessions, Konstanz
const PG = { data: null, track: null };

document.querySelector('[data-page="progress"]').addEventListener("click", pLoad);

const carName = (c) => c.replace(/\s+(\d+)\s+LM$/, " #$1").replace(/\s{2,}/g, " ");
const dateDe = (d) => { const [y, m, day] = d.slice(0, 10).split("-"); return `${day}.${m}.${y.slice(2)} ${d.slice(11)}`; };

async function pLoad() {
  PG.data = await window.pywebview.api.progress();
  const tracks = PG.data.tracks;
  const empty = !tracks.length;
  $("p-empty").style.display = empty ? "block" : "none";
  $("p-grid").style.display = empty ? "none" : "grid";
  const laps = tracks.reduce((s, t) => s + t.laps, 0);
  const ms = tracks.reduce((s, t) => s + t.sessions.reduce((a, x) => a + x.lap_times.reduce((b, l) => b + l, 0), 0), 0);
  $("p-tracks").textContent = tracks.length;
  $("p-laps").textContent = laps;
  $("p-time").textContent = ms >= 3600000 ? `${Math.floor(ms / 3600000)} h ${Math.round((ms % 3600000) / 60000)} min` : `${Math.round(ms / 60000)} min`;
  if (empty) return;
  if (!tracks.some((t) => t.track === PG.track)) PG.track = tracks[0].track;
  pRenderList();
  pRenderTrack();
}

function pRenderList() {
  $("p-list").innerHTML = PG.data.tracks.map((t) => {
    const impr = t.first_best_ms - t.best_ms;
    return `<div class="p-track ${t.track === PG.track ? "sel" : ""}" data-t="${t.track}">
      <h3>${t.track}</h3>
      <div class="meta">${t.game} · ${t.sessions.length} Session${t.sessions.length > 1 ? "s" : ""} · ${t.laps} Runden</div>
      <div class="row2"><span class="t">${fmt(t.best_ms)}</span>
        <span class="d ${impr > 0 ? "pos" : "muted"}">${impr > 0 ? "−" + (impr / 1000).toFixed(2) + " s" : dateDe(t.last_date).slice(0, 8)}</span></div>
    </div>`;
  }).join("");
  $("p-list").querySelectorAll(".p-track").forEach((el) => el.addEventListener("click", () => {
    PG.track = el.dataset.t; pRenderList(); pRenderTrack();
  }));
}

function pRenderTrack() {
  const t = PG.data.tracks.find((x) => x.track === PG.track);
  const last = t.sessions[t.sessions.length - 1];
  $("p-game").textContent = t.game;
  $("p-name").textContent = t.track;
  $("p-cars").textContent = t.cars.map(carName).join(" · ");
  $("p-best").textContent = fmt(t.best_ms);
  $("p-bestcar").textContent = carName(t.best_car);
  const impr = t.first_best_ms - t.best_ms;
  $("p-impr").textContent = t.sessions.length < 2 ? "—" : impr > 0 ? `−${(impr / 1000).toFixed(2)} s` : "±0";
  $("p-impr").className = impr > 0 ? "pos" : "";
  $("p-cons").textContent = last.spread_ms == null ? "—" : `±${(last.spread_ms / 1000).toFixed(2)} s`;
  // Echte WEC-Zeiten als Einordnung (aus der Streckendatenbank)
  // Multiclass: deine Bestzeit je Klasse nur mit der echten Zeit derselben Klasse vergleichen
  const refKey = { Hypercar: "Hypercar", LMP2: "LMP2", LMP3: "LMP3", GT3: "LMGT3", GTE: "LMGTE" };
  const myBest = {};
  t.sessions.forEach((s) => { const k = refKey[s.cls]; if (k && s.best_ms && !(myBest[k] <= s.best_ms)) myBest[k] = s.best_ms; });
  const known = Object.keys(myBest).length > 0;
  const refs = Object.entries(t.ref_times || {}).filter(([cls, v]) => v && v.s && (!known || myBest[cls]));
  $("p-ref").classList.toggle("on", refs.length > 0);
  $("p-ref").innerHTML = refs.length ? `<div class="card-title">Zum Vergleich: echte WEC-Zeiten${known ? " (deine Klasse)" : ""}</div><div class="refs">` +
    refs.map(([cls, v]) => {
      const mine = myBest[cls] || t.best_ms;
      const gap = mine / 1000 - v.s, pct = (mine / 1000 / v.s - 1) * 100;
      return `<span class="ref">${cls}<b>${fmt(v.s * 1000)}</b><em class="${gap <= 0 ? "pos" : ""}">${gap > 0 ? "+" : "−"}${Math.abs(gap).toFixed(2)} s (${pct > 0 ? "+" : ""}${pct.toFixed(1)} %)</em></span>`;
    }).join("") + `</div><div class="src">${refs.map(([cls, v]) => `${cls}: ${v.source || ""}`).join(" · ")} – echte Autos, echte Strecke; in der Simulation sind ±1–2 % normal.</div>` : "";
  $("p-cons").className = last.spread_ms == null ? "" : last.spread_ms < 300 ? "pos" : last.spread_ms > 800 ? "neg" : "";

  $("p-table").innerHTML = `<tr><th>Datum</th><th>Auto</th><th>Runden</th><th>Bestzeit</th><th>Schnitt</th><th data-tip="Schwankung der sauberen Runden – kleiner ist konstanter.">Konstanz</th><th></th></tr>` +
    [...t.sessions].reverse().map((s) => `<tr class="${s.best_ms === t.best_ms ? "best" : ""}">
      <td>${dateDe(s.date)}</td><td>${carName(s.car)}</td><td>${s.laps_full}</td>
      <td>${fmt(s.best_ms)}</td><td>${fmt(s.median_ms)}</td>
      <td>${s.spread_ms == null ? "—" : "±" + (s.spread_ms / 1000).toFixed(2)}</td>
      <td><button data-f="${s.file}">Analyse →</button></td></tr>`).join("");
  $("p-table").querySelectorAll("button").forEach((b) => b.addEventListener("click", () => openAnalyse(b.dataset.f)));
  pDrawChart();
}

function pDrawChart() {
  const t = PG.data?.tracks.find((x) => x.track === PG.track); if (!t) return;
  const [ctx, w, h] = fitCanvas($("p-chartc"));
  ctx.clearRect(0, 0, w, h);
  const ss = t.sessions, n = ss.length;
  const all = ss.flatMap((s) => s.lap_times.filter((l) => l <= s.best_ms * 1.07));
  const lo = Math.min(...all) - 500, hi = Math.max(...all) + 500;
  const L = 70, R = 50, T = 24, Bm = 28;
  const X = (i) => n === 1 ? (L + w - R) / 2 : L + (i / (n - 1)) * (w - L - R);
  const Y = (v) => T + ((v - lo) / (hi - lo || 1)) * (h - T - Bm);   // schneller = weiter oben

  // Raster
  ctx.font = "10px JetBrains Mono, monospace"; ctx.textAlign = "right"; ctx.textBaseline = "middle";
  for (let k = 0; k <= 4; k++) {
    const v = lo + ((hi - lo) * k) / 4, y = Y(v);
    ctx.strokeStyle = "#1a2030"; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(w - R, y); ctx.stroke();
    ctx.fillStyle = "#66728a"; ctx.fillText(fmt(v), L - 8, y);
  }
  ctx.textAlign = "center";
  ss.forEach((s, i) => { ctx.fillStyle = "#66728a"; ctx.fillText(dateDe(s.date).slice(0, 8), X(i), h - 10); });

  // alle sauberen Runden als Punkte
  ss.forEach((s, i) => s.lap_times.forEach((l, j) => {
    if (l > s.best_ms * 1.07) return;
    const jitter = ((j * 37) % 11 - 5) * 1.6;
    ctx.fillStyle = "rgba(255,255,255,.28)"; ctx.beginPath(); ctx.arc(X(i) + jitter, Y(l), 2.5, 0, Math.PI * 2); ctx.fill();
  }));
  // Bestzeit-Linie
  ctx.strokeStyle = "#00e5ff"; ctx.lineWidth = 2.2; ctx.shadowColor = "#00e5ff"; ctx.shadowBlur = 10;
  ctx.beginPath(); ss.forEach((s, i) => (i ? ctx.lineTo(X(i), Y(s.best_ms)) : ctx.moveTo(X(i), Y(s.best_ms)))); ctx.stroke();
  ctx.shadowBlur = 0;
  ss.forEach((s, i) => {
    const best = s.best_ms === t.best_ms;
    ctx.fillStyle = best ? "#ff2d95" : "#00e5ff";
    ctx.beginPath(); ctx.arc(X(i), Y(s.best_ms), best ? 6 : 4, 0, Math.PI * 2); ctx.fill();
    if (best) { ctx.fillStyle = "#e8eef8"; ctx.font = "700 11px JetBrains Mono, monospace"; ctx.fillText(fmt(s.best_ms), X(i), Y(s.best_ms) - 14); ctx.font = "10px JetBrains Mono, monospace"; }
  });
  if (n === 1) {
    ctx.fillStyle = "#66728a"; ctx.font = "12px Titillium Web, sans-serif";
    ctx.fillText("Ab der zweiten Session siehst du hier deine Entwicklung.", w / 2, T + 14);
  }
}
window.addEventListener("resize", pDrawChart);
