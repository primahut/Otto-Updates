"""Otto – Sim-Racing-Telemetrie & Coach. Start: python app.py"""
import os
import threading
from pathlib import Path

# Eingebetteter Edge-Browser: Overlay nie drosseln, auch wenn das Spiel im Vordergrund ist
os.environ.setdefault("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS",
                      "--disable-features=ElasticOverscroll,CalculateNativeWinOcclusion --disable-background-timer-throttling "
                      "--disable-renderer-backgrounding --disable-backgrounding-occluded-windows")
import webview
from otto import analysis, progress, sessions, track3d
from otto import changelog, cleanup, engineer, discord, hotkey, overlay_win, paths, settings, tracknames, updater, voice
from otto.engine import Engine

UI = Path(__file__).parent / "ui" / "index.html"
# LMU-Simulator nur in der Entwickler-Version (tools/ kommt nie in Otto.zip / Update-Dateien)
DEVSIM_FILE = Path(__file__).parent / "tools" / "devsim.py"
DEVSIM_UI = Path(__file__).parent / "tools" / "devsim.html"
DEVSIM_WIN = None
OVERLAY = None


class Api:
    def __init__(self, engine: Engine):
        self._engine = engine

    def state(self):
        return self._engine.state()

    def track(self):
        return self._engine.track_data()

    def set_source(self, source):
        self._engine.set_source(source)

    def sessions(self):
        return sessions.list_sessions()

    def laps(self, file):
        return sessions.lap_summary(file)

    def lap(self, file, lap):
        return sessions.lap_data(file, int(lap))

    def view3d(self, file, lap=None, ghost=None):
        return track3d.build(file, int(lap) if lap is not None else None,
                             int(ghost) if ghost is not None else None)

    def toggle_record(self):
        return self._engine.toggle_recording()

    def set_auto_record(self, value):
        self._engine.set_auto_record(value)

    def set_voice(self, key, value):
        self._engine.set_voice_setting(key, value)

    def learn_button(self):
        self._engine.learn_button()

    def rename_corner(self, track, apex_m, name, nick=""):
        tracknames.rename(track, float(apex_m), name, nick)

    def cleanup_list(self, keep_days=0):
        return cleanup.candidates(int(keep_days or 0))

    def cleanup_run(self, files):
        n = cleanup.clean(list(files))
        progress.INDEX.unlink(missing_ok=True)     # Zusammenfassungen neu berechnen
        return n

    def voices(self, lang=None):
        return voice.list_voices(lang)

    def voice_test(self, cmd="help"):
        threading.Thread(target=self._engine.handle_command, args=(cmd,), daemon=True).start()

    def progress(self):
        return progress.overview()

    def overlay_stats(self, fps):
        self._engine.overlay_fps = (int(fps), __import__("time").time())

    # ---------- LMU-Simulator (nur Entwickler-Version) ----------
    def dev_mode(self):
        return getattr(self._engine, "_devsim", None) is not None

    def devsim_open(self):
        global DEVSIM_WIN
        if not self.dev_mode():
            return False
        self._engine.set_source("devsim")
        if DEVSIM_WIN is None:
            DEVSIM_WIN = webview.create_window("Otto · LMU-Simulator", html=DEVSIM_UI.read_text(encoding="utf-8"),
                                               js_api=self, width=1250, height=820)

            def closed():
                global DEVSIM_WIN
                DEVSIM_WIN = None
            DEVSIM_WIN.events.closed += closed
        return True

    def devsim_state(self):
        e = self._engine
        sim = getattr(e, "_devsim", None)
        if sim is None:
            return None
        snap = sim.snapshot()
        st = e.state()
        snap["otto"] = {
            "connected": st["connected"], "source": e.source, "delta_ms": st["delta_ms"],
            "said": list(getattr(e.coach, "history", [])[-7:]),
            "heard": list(getattr(e.listener, "heard", [])[-6:]),
            "mic": st.get("mic"), "listening": st["listening"], "pace": st["pace_next"],
            "ai": st.get("ai"), "spot": st.get("spot"), "pace_source": st.get("pace_source"),
            "voice_error": st.get("voice_error"), "rates": st.get("rates"),
        }
        return snap

    def devsim_action(self, name):
        sim = getattr(self._engine, "_devsim", None)
        if sim is not None:
            sim.action(name)
            if name.startswith("track:"):
                self._engine.set_source("devsim")       # neue Strecke = neue Session
        return True

    def devsim_ask(self, cmd):
        """Befehl auslösen, als hätte man ihn gesagt (zum Vergleichen ohne Mikro)."""
        threading.Thread(target=self._engine.handle_command, args=(cmd, ""), daemon=True).start()
        return True

    # ---------- KI-Engineer ----------
    def engineer_info(self):
        return {"key": engineer.masked(), "ready": self._engine.engineer.ready}

    def engineer_save_key(self, key):
        engineer.save_key(key)            # nur lokal in <Datenordner>/engineer_key.txt
        return self.engineer_info()

    def engineer_test(self):
        self._engine.handle_command("ai_test")
        return True

    # ---------- Was ist neu ----------
    def whats_new(self):
        return changelog.whats_new(self._engine.settings)

    def whats_new_seen(self):
        with self._engine.lock:
            self._engine.settings["seen_version"] = paths.version()
            settings.save(self._engine.settings)
        return True

    # ---------- Discord ----------
    def discord_settings(self):
        st = settings.load()
        return {k: st.get(k) for k in ("discord_name", "discord_bug_url", "discord_best_url", "discord_session_url",
                                       "discord_post_best", "discord_post_session")}

    def discord_save(self, data):
        st = settings.load()
        for k, v in data.items():
            if k.startswith("discord_"):
                st[k] = v.strip() if isinstance(v, str) else v
        settings.save(st)
        self._engine.settings.update({k: st[k] for k in st if k.startswith("discord_")})
        return True

    def discord_test(self, kind):
        ok, msg = discord.test(kind)
        return {"ok": ok, "msg": msg}

    def discord_bug(self, title, text):
        ok, msg = discord.report_bug(title, text, self._engine.bug_context())
        return {"ok": ok, "msg": msg}

    def discord_code(self):
        return discord.export_code()

    def discord_import(self, code):
        ok, msg = discord.import_code(code)
        st = settings.load()      # Engine-Kopie der Einstellungen aktuell halten (sonst überschreibt sie später)
        self._engine.settings.update({k: st[k] for k in st if k.startswith("discord_")})
        return {"ok": ok, "msg": msg}

    # ---------- Overlay ----------
    def toggle_overlay(self):
        """Kleines Fenster immer im Vordergrund über dem Spiel (Spiel im Modus „Randlos/Borderless“)."""
        global OVERLAY
        if OVERLAY is not None:
            self._overlay_save_pos()
            try:
                OVERLAY.destroy()
            except Exception:
                pass
            OVERLAY = None
            return False
        st = settings.load()
        scale = {"S": 0.85, "M": 1.0, "L": 1.25}.get(st.get("overlay_size", "M"), 1.0)
        x, y = st.get("overlay_x", 40), st.get("overlay_y", 40)
        if not overlay_win.on_screen(x, y):          # z. B. 2. Monitor nicht mehr da
            x, y = 40, 40
        OVERLAY = webview.create_window("Otto Overlay", str(UI.with_name("overlay.html")), js_api=self,
                                        width=int(420 * scale), height=int(152 * scale), frameless=True,
                                        easy_drag=True, on_top=True, background_color="#05070c", x=x, y=y)
        OVERLAY.initial_width, OVERLAY.initial_height = int(420 * scale), int(152 * scale)
        threading.Thread(target=self._overlay_watch, args=(OVERLAY,), daemon=True).start()
        threading.Thread(target=self._overlay_push, args=(OVERLAY,), daemon=True).start()
        return True

    def open_mic_settings(self):
        import os as _os
        try:
            _os.startfile("ms-settings:sound")        # Windows: System › Sound (Eingabegerät wählen)
        except Exception:
            _os.startfile("mmsys.cpl")

    def mic_devices(self):
        from otto import mic
        return mic.devices()

    def mic_probe(self):
        """3 s in jedes Mikrofon hören – zeigt, wo deine Stimme ankommt."""
        from otto import mic
        return [{"name": n, "level": l} for n, l in mic.probe(3.0)]

    def overlay_state(self):
        return self._engine.overlay_state()

    def _overlay_push(self, win):
        """Daten aktiv ins Overlay schicken (30x/s) – schneller als wenn das Overlay selbst nachfragt."""
        import json as _json
        import time as _t
        try:
            win.events.loaded.wait(15)
        except Exception:
            _t.sleep(3)
        while OVERLAY is win:
            t0 = _t.time()
            try:
                win.run_js("window.ottoPush && window.ottoPush(" + _json.dumps(self._engine.overlay_state(), default=str) + ")")
            except Exception:
                _t.sleep(0.5)
            _t.sleep(max(0.005, 0.05 - (_t.time() - t0)))

    def _overlay_watch(self, win):
        """Solange das Overlay offen ist: Durchsichtigkeit/Fixieren anwenden, Position merken."""
        import time as _t
        applied, last_pos, fixed = None, None, False
        while OVERLAY is win:
            hwnd = overlay_win.find()
            if hwnd and not fixed:
                # Windows zieht bei rahmenlosen Fenstern den Rand von der gewünschten Größe ab -> einmal ausgleichen
                fixed = True
                r = overlay_win.rect(hwnd)
                dpi = overlay_win.dpi_scale(hwnd)
                want_w, want_h = win.initial_width, win.initial_height
                if r and (r[2] / dpi < want_w - 2 or r[3] / dpi < want_h - 2):
                    try:
                        win.resize(want_w, want_h)          # resize() setzt die Größe exakt (create_window nicht)
                    except Exception as e:
                        print("Overlay-Größe:", e)
            st = self._engine.settings
            want = (round(st.get("overlay_opacity", 0.85), 2), bool(st.get("overlay_lock")))
            if hwnd and want != applied:
                overlay_win.style(hwnd, *want)
                applied = want
            pos = overlay_win.rect(hwnd) if hwnd else None
            if pos and pos[:2] != last_pos:
                last_pos = pos[:2]
                self._overlay_save_pos(pos)
            _t.sleep(0.5)

    def _overlay_save_pos(self, pos=None):
        pos = pos or overlay_win.rect(overlay_win.find())
        if pos and pos[0] > -10000:                       # minimierte Fenster melden -32000
            for k, v in (("overlay_x", pos[0]), ("overlay_y", pos[1])):
                self._engine.settings[k] = v
            settings.save(self._engine.settings)

    def overlay_resize(self):
        """Größe geändert -> Overlay neu öffnen."""
        if OVERLAY is not None:
            self.toggle_overlay()
            self.toggle_overlay()

    def toggle_overlay_lock(self):
        on = not self._engine.settings.get("overlay_lock")
        self._engine.set_voice_setting("overlay_lock", on)
        return on

    # ---------- Version & Updates ----------
    def version_info(self):
        return {"version": paths.version(), "installed": updater.FROZEN, "data": str(paths.DATA),
                "update_url": settings.load().get("update_url", "")}

    def install_update_file(self):
        try:
            kind = webview.FileDialog.OPEN if hasattr(webview, "FileDialog") else webview.OPEN_DIALOG
            # Achtung: pywebview lehnt Bindestriche in der Beschreibung ab („Otto-Update“ -> Fenster ging nie auf)
            files = WINDOW.create_file_dialog(kind, file_types=("Otto Update (*.zip)",))
        except Exception as e:
            return {"ok": False, "msg": f"Dateiauswahl ging nicht auf: {e}"}
        if not files:
            return {"ok": False, "msg": ""}
        try:
            return updater.stage_zip(files[0])
        except Exception as e:
            return {"ok": False, "msg": f"Update fehlgeschlagen: {e}"}

    def check_update_quiet(self):
        """Beim Start: nur nachsehen (nicht installieren)."""
        if not updater.FROZEN:
            return {"ok": False}
        try:
            return updater.check_online(settings.load().get("update_url", ""), install=False)
        except Exception as e:
            return {"ok": False, "msg": str(e)}

    def check_update(self, url=None):
        st = settings.load()
        if url is not None:
            st["update_url"] = url.strip()
            with self._engine.lock:                  # Engine-Kopie mitziehen, sonst überschreibt sie die Adresse
                self._engine.settings["update_url"] = st["update_url"]
                settings.save(self._engine.settings)
        try:
            return updater.check_online(st.get("update_url", ""))
        except Exception as e:
            return {"ok": False, "msg": f"Keine Verbindung zum Update-Server: {e}"}

    def restart(self):
        """Otto neu starten (übernimmt ein bereitgelegtes Update)."""
        import subprocess
        import sys
        if updater.FROZEN:
            # erst beenden, dann (nach ~8 s) neu starten: solange das alte Otto läuft, darf Windows den
            # Programmordner nicht austauschen – sonst bliebe die alte Version
            subprocess.Popen(f'cmd /c ping 127.0.0.1 -n 9 >nul & start "" "{sys.executable}"',
                             cwd=str(updater.ROOT), creationflags=0x08000000)    # ohne Konsolenfenster
        WINDOW.destroy()

    def analyse(self, file, lap=None, ref=None):
        return analysis.analyse(file, int(lap) if lap is not None else None,
                                int(ref) if ref is not None else None)


if __name__ == "__main__":
    if settings.load()["auto_cleanup"]:
        threading.Thread(target=cleanup.auto_clean, daemon=True).start()
    # Hänger-Melder: friert Python > 3 s ein, schreibt faulthandler (läuft ohne Python-Sperre) die Stapel aller
    # Threads nach <Datenordner>/otto_haenger.log – so sehen wir genau, was blockiert hat
    import faulthandler
    _hang_log = open(paths.DATA / "otto_haenger.log", "a", encoding="utf-8")

    def _heartbeat():
        import time as _t
        while True:
            faulthandler.dump_traceback_later(3.0, repeat=False, file=_hang_log)
            _t.sleep(1.0)
            faulthandler.cancel_dump_traceback_later()
    threading.Thread(target=_heartbeat, daemon=True).start()
    engine = Engine()
    if DEVSIM_FILE.exists() and not getattr(__import__("sys"), "frozen", False):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("devsim", DEVSIM_FILE)
            devsim = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(devsim)
            engine._devsim = devsim.SimLMU()
            print("Entwickler-Version: LMU-Simulator verfügbar")
        except Exception as e:
            print("LMU-Simulator nicht geladen:", e)
    hotkey.register("R", engine.toggle_recording)   # Strg+Alt+R: Aufnahme Start/Stopp, auch im Spiel
    hotkey.register("T", engine.push_to_talk)       # Strg+Alt+T: jetzt sprechen (wie der Lenkradknopf)
    api = Api(engine)
    hotkey.register("O", api.toggle_overlay)        # Strg+Alt+O: Overlay ein/aus
    hotkey.register("L", api.toggle_overlay_lock)   # Strg+Alt+L: Overlay fixieren/lösen (Klicks gehen ans Spiel)
    WINDOW = webview.create_window(f"Otto {paths.version()}", str(UI), js_api=api,
                                   width=1400, height=860, min_size=(1000, 640), background_color="#07080c")
    UPDATE_INFO = {}

    def _bg_check():                             # beim Start still nachsehen, ob es ein neues Update gibt
        try:
            UPDATE_INFO.update(updater.check_online(settings.load().get("update_url", ""), install=False))
        except Exception as e:
            print("Update-Check:", e)
    if updater.FROZEN:
        threading.Thread(target=_bg_check, daemon=True).start()
    api.update_info = lambda: dict(UPDATE_INFO)
    def _main_closed():
        # Hauptfenster zu -> Overlay mit schließen (sonst bleibt es allein auf dem Bildschirm hängen)
        for w in (OVERLAY, DEVSIM_WIN):
            if w is not None:
                try:
                    w.destroy()
                except Exception:
                    pass
    WINDOW.events.closed += _main_closed
    webview.start()
    engine.shutdown()   # Fenster zu -> Aufnahme sauber abschließen
    import os
    os._exit(0)         # Hintergrund-Threads (Spracherkennung, Hotkeys) nicht weiterlaufen lassen
