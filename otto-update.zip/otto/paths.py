"""Wo liegen Code und Nutzerdaten?

- Entwicklung (python app.py): alles im Projektordner, wie bisher.
- Installierte Otto.exe: der Starter setzt OTTO_DATA auf einen eigenen Datenordner
  (%LOCALAPPDATA%\\Otto). Updates ersetzen nur den Code, Aufnahmen/Einstellungen bleiben."""
import os
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("OTTO_DATA") or CODE)
DATA.mkdir(parents=True, exist_ok=True)

SESSIONS = DATA / "sessions"
SETTINGS = DATA / "settings.json"
TRACKNAMES = DATA / "tracknames.json"
LOG = DATA / "otto.log"
VERSION_FILE = CODE / "VERSION"


def version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return "dev"
