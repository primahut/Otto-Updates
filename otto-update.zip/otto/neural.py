"""Natürliche Stimmen (Piper, neuronale Sprachausgabe – läuft komplett offline auf dem PC).

Die Stimmen sind große Modelldateien (60–120 MB) und werden deshalb erst bei Bedarf einmalig
heruntergeladen (offizielle Piper-Stimmen von huggingface.co/rhasspy/piper-voices) und dann in
<Datenordner>/voices gespeichert. Danach braucht Otto kein Internet mehr dafür.

„Thorsten – mit Betonung“ ist ein Modell mit mehreren Gefühlslagen: Fahrlehrer-Kommandos klingen
damit energisch („Bremsen!“), normale Ansagen locker – je nach Einstellung „Betonung“."""
import io
import threading
import urllib.request
import wave
from pathlib import Path
from . import paths

try:
    from piper import PiperVoice, SynthesisConfig
    AVAILABLE = True
except Exception as e:          # ältere Otto.exe ohne Piper-Bibliothek
    print("Natürliche Stimmen nicht verfügbar:", e)
    AVAILABLE = False

DIR = paths.DATA / "voices"
URL = ("https://huggingface.co/rhasspy/piper-voices/resolve/main/{fam}/{code}/{name}/{q}/"
       "{code}-{name}-{q}{ext}?download=true")

# kuratierte Auswahl: gut verständlich, auch schnell gesprochen
CATALOG = {
    "de": [
        {"model": "de_DE-thorsten_emotional-medium", "name": "Thorsten – mit Betonung", "gender": "männlich", "mb": 73,
         "emotional": True},
        {"model": "de_DE-thorsten-high", "name": "Thorsten – klar (beste Qualität, rechnet langsamer)", "gender": "männlich", "mb": 109},
        {"model": "de_DE-karlsson-low", "name": "Karlsson", "gender": "männlich", "mb": 63},
        {"model": "de_DE-pavoque-low", "name": "Pavoque", "gender": "männlich", "mb": 63},
        {"model": "de_DE-kerstin-low", "name": "Kerstin", "gender": "weiblich", "mb": 63},
        {"model": "de_DE-ramona-low", "name": "Ramona", "gender": "weiblich", "mb": 63},
        {"model": "de_DE-eva_k-x_low", "name": "Eva (einfacher)", "gender": "weiblich", "mb": 21},
    ],
    "en": [
        {"model": "en_GB-alan-medium", "name": "Alan (British)", "gender": "male", "mb": 61},
        {"model": "en_GB-northern_english_male-medium", "name": "Northern English", "gender": "male", "mb": 63},
        {"model": "en_US-ryan-high", "name": "Ryan (American)", "gender": "male", "mb": 116},
        {"model": "en_US-joe-medium", "name": "Joe (American)", "gender": "male", "mb": 63},
        {"model": "en_US-john-medium", "name": "John (American)", "gender": "male", "mb": 64},
        {"model": "en_GB-cori-high", "name": "Cori (British)", "gender": "female", "mb": 110},
        {"model": "en_GB-jenny_dioco-medium", "name": "Jenny (British)", "gender": "female", "mb": 63},
        {"model": "en_US-lessac-high", "name": "Lessac (American)", "gender": "female", "mb": 114},
        {"model": "en_US-amy-medium", "name": "Amy (American)", "gender": "female", "mb": 63},
    ],
}
# Gefühlslage je Betonung: (Kommandos, normale Ansagen) – Sprecher-Namen des emotionalen Modells
MOODS = {"ruhig": ("neutral", "neutral"), "lebendig": ("surprised", "amused"), "energisch": ("angry", "surprised")}
# für Modelle ohne Gefühlslagen: etwas mehr Lebendigkeit in der Sprachmelodie
NOISE = {"ruhig": 0.55, "lebendig": 0.7, "energisch": 0.8}

_lock = threading.Lock()
_loaded: dict = {"model": None, "voice": None}
DL = {"model": None, "pct": 0, "error": ""}       # Download-Fortschritt fürs UI


def _entry(model: str) -> dict | None:
    return next((v for vs in CATALOG.values() for v in vs if v["model"] == model), None)


def installed(model: str) -> bool:
    return (DIR / f"{model}.onnx").is_file() and (DIR / f"{model}.onnx.json").is_file()


def voices(lang: str) -> list[dict]:
    """Für die Stimmen-Auswahl: id = „piper:<Modell>“."""
    if not AVAILABLE:
        return []
    out = []
    for v in CATALOG.get(lang, []):
        tag = "natürlich" if lang == "de" else "natural"
        if not installed(v["model"]):
            tag += f", einmalig ca. {v['mb']} MB laden" if lang == "de" else f", one-time ~{v['mb']} MB download"
        out.append({"id": "piper:" + v["model"], "name": f"{v['name']} ({tag})", "gender": v["gender"],
                    "neural": True, "installed": installed(v["model"]), "emotional": bool(v.get("emotional"))})
    return out


def download(model: str) -> bool:
    """Stimme herunterladen (blockiert; im Hintergrund-Thread aufrufen). True = fertig."""
    if not AVAILABLE or not _entry(model):
        return False
    if installed(model):
        return True
    if DL["model"] and DL["model"] != model and not DL["error"]:
        return False                                    # es läuft schon ein anderer Download
    DL.update(model=model, pct=0, error="")
    code, name, q = model.split("-", 2)
    try:
        DIR.mkdir(parents=True, exist_ok=True)
        for ext in (".onnx.json", ".onnx"):
            url = URL.format(fam=code.split("_")[0], code=code, name=name, q=q, ext=ext)
            tmp = DIR / f"{model}{ext}.part"
            with urllib.request.urlopen(url, timeout=30) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                done = 0
                while chunk := r.read(1 << 16):
                    f.write(chunk)
                    done += len(chunk)
                    if ext == ".onnx" and total:
                        DL["pct"] = int(done * 100 / total)
            tmp.replace(DIR / f"{model}{ext}")
        DL.update(pct=100, model=None)
        return True
    except Exception as e:
        DL["error"] = f"Download fehlgeschlagen: {e}"
        print("Stimme laden:", DL["error"])
        for ext in (".onnx.json", ".onnx"):
            (DIR / f"{model}{ext}.part").unlink(missing_ok=True)
        return False


def _voice(model: str):
    if _loaded["model"] != model:
        _loaded["voice"] = PiperVoice.load(DIR / f"{model}.onnx", config_path=DIR / f"{model}.onnx.json")
        _loaded["model"] = model
    return _loaded["voice"]


def render(model: str, text: str, rate: float = 1.0, volume: float = 0.9,
           mood: str = "info", vibe: str = "lebendig") -> bytes:
    """Text -> WAV-Bytes. mood: „command“ (Fahrlehrer-Kommando) oder „info“ (normale Ansage)."""
    with _lock:
        v = _voice(model)
        spk = None
        ids = getattr(v.config, "speaker_id_map", None) or {}
        if ids:
            want = MOODS.get(vibe, MOODS["lebendig"])[0 if mood == "command" else 1]
            spk = ids.get(want, ids.get("neutral"))
        cfg = SynthesisConfig(speaker_id=spk, length_scale=1.0 / max(0.5, min(2.0, rate)),
                              noise_scale=NOISE.get(vibe, 0.7), noise_w_scale=0.8,
                              volume=max(0.05, min(1.0, volume)))
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            v.synthesize_wav(text, w, syn_config=cfg)
        return buf.getvalue()
