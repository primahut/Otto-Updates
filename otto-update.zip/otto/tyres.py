"""Reifen & Bremsen wie ein Renningenieur auswerten: kalt / im Fenster / zu heiß, und wann sie warm sind.

Temperaturfenster (ungefähr, LMU): Reifen 75–100 °C (darunter wenig Grip, darüber Abbau).
Bremsen nach CrewChief-Werten: Carbon (Hypercar, LMP2) kalt unter 400 °C, gut bis 1000 °C, heiß darüber;
Stahl (GT3, LMP3, GTE) kalt unter 150 °C, gut bis 800 °C, heiß darüber."""
import time

TYRE_COLD, TYRE_OK_MAX, TYRE_HOT = 75.0, 100.0, 108.0
BRAKES = {"carbon": (400.0, 1000.0, 1200.0), "steel": (150.0, 800.0, 950.0)}
CARBON_CLASSES = {"Hypercar", "LMP2"}


def brake_kind(cls: str | None) -> str:
    return "carbon" if cls in CARBON_CLASSES else "steel"


class TyreWatch:
    """Merkt sich die Temperaturen (1x pro Sekunde) -> Erwärmungstempo -> „in etwa 2 Runden warm“."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.hist = []               # (t, Reifen vorne, Reifen hinten, Bremse vorne)
        self.announced_warm = False
        self.hot_since = None
        self.hot_said = 0.0

    def add(self, ty: dict, t: float | None = None):
        t = time.time() if t is None else t
        w = ty["wheels"]
        self.hist = [h for h in self.hist if t - h[0] < 120] + [
            (t, (w[0]["temp"] + w[1]["temp"]) / 2, (w[2]["temp"] + w[3]["temp"]) / 2, (w[0]["brake"] + w[1]["brake"]) / 2)]

    def rate(self, idx: int, window: float = 45.0) -> float | None:
        """Erwärmung in °C pro Sekunde (über die letzten ~45 s)."""
        if len(self.hist) < 10:
            return None
        t1 = self.hist[-1][0]
        old = next((h for h in self.hist if t1 - h[0] <= window), None)
        if old is None or t1 - old[0] < 8:
            return None
        return (self.hist[-1][idx] - old[idx]) / (t1 - old[0])

    def status(self) -> dict | None:
        if not self.hist:
            return None
        _, front, rear, brake = self.hist[-1]
        cold = min(front, rear)
        eta = None
        if cold < TYRE_COLD:
            idx = 1 if front <= rear else 2
            r = self.rate(idx)
            if r and r > 0.02:
                eta = (TYRE_COLD - cold) / r
        return {"front": front, "rear": rear, "brake": brake, "cold": cold < TYRE_COLD,
                "hot": max(front, rear) > TYRE_HOT, "eta_s": eta}
