"""Reifen & Bremsen wie ein Renningenieur auswerten: kalt / im Fenster / zu heiß, und wann sie warm sind.

Temperaturfenster (ungefähr, LMU): Reifen 75–100 °C (darunter wenig Grip, darüber Abbau).
Bremsen nach CrewChief-Werten: Carbon (Hypercar, LMP2) kalt unter 400 °C, gut bis 1000 °C, heiß darüber;
Stahl (GT3, LMP3, GTE) kalt unter 150 °C, gut bis 800 °C, heiß darüber."""
import time

# Gemessen wird dieselbe Zahl wie in der LMU-Reifenanzeige (Innenschicht + 45 % zum Kern, siehe games/lmu.py;
# die Oberfläche kühlt auf jeder Geraden ab und wirkte dann „kalt“). Testfahrt: warm im Rennen ~70–72 °C.
TYRE_COLD, TYRE_OK_MAX, TYRE_HOT = 65.0, 95.0, 105.0
BRAKES = {"carbon": (400.0, 1000.0, 1200.0), "steel": (150.0, 800.0, 950.0)}
CARBON_CLASSES = {"Hypercar", "LMP2"}


def brake_kind(cls: str | None) -> str:
    return "carbon" if cls in CARBON_CLASSES else "steel"


# ---------------------------------------------------------------- Startreifen vor dem Rennen
# Schätzwerte (LMU, trocken, normale Streckentemperatur) – werden durch gemessenen Verschleiß ersetzt:
LIFE_MIN = {"Soft": 40.0, "Medium": 75.0, "Hard": 110.0}     # Minuten, bis der Grip deutlich nachlässt
PACE = {"Soft": -0.5, "Medium": 0.0, "Hard": 0.5}            # s pro Runde gegenüber Medium
WEAR_FACTOR = {"Soft": 1.4, "Medium": 1.0, "Hard": 0.7}      # Verschleiß relativ zu Medium
WEAR_LIMIT = 60.0             # % Abnutzung, ab der der Reifen „durch“ ist
TYRE_CHANGE_S = 12.0          # was ein Reifenwechsel beim Stopp zusätzlich kostet
DEFAULT_STINT_MIN = 45.0      # Tank-Stint, wenn wir den Verbrauch nicht kennen


def start_plan(race_s: float | None, race_laps: int | None, lap_s: float, fuel_laps: float | None,
               track: float | None, wet: bool, wear_per_lap: dict | None = None) -> dict | None:
    """Mit welcher Mischung starten? -> {"rec", "laps", "stints", "stint_laps", "k" (Stints auf diesen Reifen),
    "life" {Mischung: Runden}, "why", "measured"}"""
    if lap_s <= 20 or (not race_s and not race_laps):
        return None
    laps = race_laps or int(race_s // lap_s) + 1
    if wet:
        return {"rec": "Wet", "laps": laps, "why": "wet"}
    stint = min(laps, fuel_laps) if fuel_laps and fuel_laps > 1 else min(laps, max(1, round(DEFAULT_STINT_MIN * 60 / lap_s)))
    stints = max(1, -(-laps // max(1, int(stint))))
    temp = 1.0 if track is None else (0.8 if track > 40 else 0.9 if track > 34 else 1.1 if track < 20 else 1.0)
    life, measured = {}, False
    base = None
    for c, r in (wear_per_lap or {}).items():          # gemessen: auf alle Mischungen umrechnen
        if c in WEAR_FACTOR and r > 0.05:
            base, measured = WEAR_LIMIT / (r / WEAR_FACTOR[c]), True
            break
    for c in LIFE_MIN:
        life[c] = base / WEAR_FACTOR[c] if base else LIFE_MIN[c] * 60 / lap_s * temp
    cold = track is not None and track < 15
    best = None
    for c in ("Soft", "Medium", "Hard"):
        # wie viele Tank-Stints hält die Mischung (hält sie das ganze Rennen: alle, ohne Reifenwechsel)
        k = stints if life[c] >= laps else min(stints, int(life[c] // stint))
        if k == 0:
            continue
        pace = PACE[c] + (1.0 if cold and c == "Hard" else 0.0)
        score = pace * k * stint - TYRE_CHANGE_S * (k - 1)
        if best is None or score < best[1] - 0.5:
            best = (c, score, k)
    if best is None:                                    # nichts hält einen Stint -> die haltbarste nehmen
        best = ("Hard", 0.0, 0)
    c, _, k = best
    why = ("all" if k >= stints else "double" if k > 1 else "short" if stints == 1 else "fast_stint")
    if cold and c != "Hard" and life["Hard"] >= stint and why == "fast_stint":
        why = "cold"
    if c == "Hard" and why == "fast_stint":
        why = "only"
    return {"rec": c, "laps": laps, "stints": stints, "stint_laps": round(stint), "k": k,
            "life": {x: round(v) for x, v in life.items()}, "why": why, "measured": measured}


class TyreWatch:
    """Merkt sich die Temperaturen (1x pro Sekunde) -> Erwärmungstempo -> „in etwa 2 Runden warm“."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.hist = []               # (t, Reifen vorne, Reifen hinten, Bremse vorne)
        self.announced_warm = False
        self.hot_since = None
        self.hot_said = 0.0

    def add(self, ty: dict, t: float | None = None):
        t = time.time() if t is None else t
        w = ty["wheels"]
        self.hist = [h for h in self.hist if t - h[0] < 120] + [
            (t, (w[0]["temp"] + w[1]["temp"]) / 2, (w[2]["temp"] + w[3]["temp"]) / 2, (w[0]["brake"] + w[1]["brake"]) / 2)]

    def rate(self, idx: int, window: float = 45.0) -> float | None:
        """Erwärmung in °C pro Sekunde (über die letzten ~45 s)."""
        if len(self.hist) < 10:
            return None
        t1 = self.hist[-1][0]
        old = next((h for h in self.hist if t1 - h[0] <= window), None)
        if old is None or t1 - old[0] < 8:
            return None
        return (self.hist[-1][idx] - old[idx]) / (t1 - old[0])

    def status(self) -> dict | None:
        if not self.hist:
            return None
        _, front, rear, brake = self.hist[-1]
        cold = min(front, rear)
        eta = None
        if cold < TYRE_COLD:
            idx = 1 if front <= rear else 2
            r = self.rate(idx)
            if r and r > 0.02:
                eta = (TYRE_COLD - cold) / r
        return {"front": front, "rear": rear, "brake": brake, "cold": cold < TYRE_COLD,
                "hot": max(front, rear) > TYRE_HOT, "eta_s": eta}
