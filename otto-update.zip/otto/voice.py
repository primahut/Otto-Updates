"""Sprache: Ansagen (Windows-Stimmen, offline) und Sprachbefehle („<Name>, …“, Windows-Spracherkennung).
Deutsch oder Englisch (i18n.LANG).

Ausgabe: bevorzugt die modernen Windows-Stimmen (WinRT, z. B. Katja/Stefan); sonst die klassischen
SAPI-Stimmen (z. B. Hedda/Zira). Eingabe: System.Speech über pythonnet (kommt mit pywebview mit)."""
import asyncio
import math
import queue
import re
import struct
import wave
import threading
import time
from . import i18n, neural
from .i18n import T

try:
    import clr
    clr.AddReference("System.Speech, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35")
    from System.Globalization import CultureInfo
    from System.Speech.Recognition import Choices, Grammar, GrammarBuilder, RecognizeMode, SpeechRecognitionEngine
    from System.Speech.Synthesis import SpeechSynthesizer as SapiSynth
    AVAILABLE = True
except Exception as e:  # z. B. kein .NET / keine Sprachpakete
    print("Spracherkennung nicht verfügbar:", e)
    AVAILABLE = False

try:
    import winsound
    from winrt.windows.media.speechsynthesis import SpeechSynthesizer as WinRTSynth
    from winrt.windows.storage.streams import DataReader
    WINRT = True
except Exception:
    WINRT = False


_CLR_LOCK = threading.RLock()     # .NET/Sprach-Objekte nie aus zwei Threads gleichzeitig anlegen
_VOICES: dict[str, list] = {}


def list_voices(lang: str | None = None) -> list[dict]:
    """Alle Stimmen der Sprache: WinRT (id = Name) und klassische SAPI (id = „sapi:Name“). Zwischengespeichert."""
    lang = lang or i18n.LANG
    with _CLR_LOCK:
        if lang not in _VOICES:
            _VOICES[lang] = _list_voices(lang)
        # natürliche Stimmen (Piper) zuerst – Status „installiert“ ändert sich, daher nicht zwischenspeichern
        return neural.voices(lang) + list(_VOICES[lang])


def _list_voices(lang: str) -> list[dict]:
    out = []
    if WINRT:
        for v in WinRTSynth.all_voices:
            if v.language.lower().startswith(lang):
                out.append({"id": v.display_name, "name": v.display_name.replace("Microsoft ", ""),
                            "gender": "männlich" if int(v.gender) == 0 else "weiblich"})
    if AVAILABLE:
        names = {o["name"] for o in out}
        for v in SapiSynth().GetInstalledVoices():
            info = v.VoiceInfo
            short = info.Name.replace("Microsoft ", "").replace(" Desktop", "")
            if info.Culture.Name.lower().startswith(lang) and short not in names:
                out.append({"id": "sapi:" + info.Name, "name": short + " (klassisch)",
                            "gender": "weiblich" if str(info.Gender) == "Female" else "männlich"})
    return out


class Speaker:
    """Spricht Texte nacheinander im Hintergrund; veraltete Ansagen werden verworfen."""

    def __init__(self):
        self.q: queue.Queue = queue.Queue()
        self.volume = 90
        self.rate = 1.1              # 1.0 = normal
        self.voice = ""              # „piper:Modell“, WinRT-Name, „sapi:Name“ oder "" (= erste passende Stimme)
        self.vibe = "lebendig"       # Betonung der natürlichen Stimmen: ruhig | lebendig | energisch
        self.cmd_lang = ""           # Sprache der Fahrlehrer-Kommandos ("" = wie die Ansagen, "en" = Renn-Englisch)
        self.gate = lambda: 99.0     # Sekunden bis zum nächsten Fahrlehrer-Kommando (setzt die Engine)
        self.busy_until = 0.0        # bis dahin spielt gerade ein Kommando
        self.speaking_until = 0.0
        self.last_text = ""
        self.on_reply = None          # Engine: Funk-Pause bis Antwortende + kurze Ruhe
        self.replies_waiting = 0      # Antworten in der Warteschlange haben Vorfahrt vor normalen Ansagen
        self._count_lock = threading.Lock()
        self.on_other = None          # Engine: normale Ansage während einer Funk-Pause -> Pause verlängern
        self.enabled = WINRT or AVAILABLE
        if self.enabled:
            threading.Thread(target=self._run, daemon=True).start()

    def say(self, text: str, max_age: float = 4.0, lang: str | None = None, reply: bool = False):
        """reply=True: Antwort auf eine Frage des Fahrers -> on_reply(Dauer) beim Abspielen (Funk-Pause)."""
        if self.enabled and text:
            if reply:
                with self._count_lock:
                    self.replies_waiting += 1
            self.q.put((time.time(), max_age, text, lang, reply))

    def _pick(self, lang: str | None = None) -> str:
        """Gewählte Stimme, falls sie zur Sprache passt und bereit ist – sonst die erste passende Windows-Stimme
        (z. B. solange eine natürliche Stimme noch heruntergeladen wird).
        Andere Sprache (Renn-Englisch-Kommandos): eine fertige natürliche Stimme dieser Sprache, sonst Windows."""
        lang = lang or i18n.LANG
        vs = list_voices(lang)
        ready = [v["id"] for v in vs if not v.get("neural") or v.get("installed")]
        windows = [v["id"] for v in vs if not v.get("neural")]
        if lang != i18n.LANG:
            natural = [v["id"] for v in vs if v.get("neural") and v.get("installed")]
            wants_natural = self.voice.startswith("piper:") or not self.voice
            return (natural[0] if natural and wants_natural else windows[0] if windows else (ready[0] if ready else ""))
        return self.voice if self.voice in ready else (windows[0] if windows else (ready[0] if ready else ""))

    @property
    def natural(self) -> bool:
        return self._pick().startswith("piper:")

    def render(self, text: str, rate_boost: float = 1.0, mood: str = "info", lang: str | None = None) -> bytes:
        """Text -> WAV-Bytes (für Ansagen und die Sound-Bank). Lautstärke über 100 % = digital verstärkt."""
        vol = self.volume                       # einmal lesen (Einstellungen können sich parallel ändern)
        wav = self._render(text, rate_boost, mood, lang, min(vol, 100))
        return _boost(wav, vol / 100) if vol > 100 else wav

    def _render(self, text: str, rate_boost: float = 1.0, mood: str = "info", lang: str | None = None,
                vol: float = 100) -> bytes:
        vid = self._pick(lang)
        if vid.startswith("piper:"):
            return neural.render(vid[6:], text, rate=self.rate * rate_boost, volume=vol / 100,
                                 mood=mood, vibe=self.vibe)
        if vid and not vid.startswith("sapi:") and WINRT:
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(self._winrt_wav(text, vid, rate_boost, vol))
            finally:
                loop.close()
        import io
        import tempfile
        import os
        s = SapiSynth()
        if vid.startswith("sapi:"):
            s.SelectVoice(vid[5:])
        s.Rate = max(-10, min(10, round((self.rate * rate_boost - 1) * 10)))
        s.Volume = int(vol)
        fd, path = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        s.SetOutputToWaveFile(path)
        s.Speak(text)
        s.SetOutputToNull()
        s.Dispose()
        data = open(path, "rb").read()
        os.remove(path)
        return data

    def _run(self):
        while True:
            t, max_age, text, lang, reply = self.q.get()
            if reply:
                with self._count_lock:
                    self.replies_waiting = max(0, self.replies_waiting - 1)
            elif self.replies_waiting:
                continue                         # normale Ansage verfällt, eine Antwort auf deine Frage wartet
            if time.time() - t > max_age and not reply:      # zu alt -> passt nicht mehr zur Fahrsituation
                continue
            try:
                rl = lang if lang and lang != i18n.LANG else None
                parts = [p for p in re.split(r"(?<=[.!?])\s+", text) if p.strip()] if reply else [text]
                if reply and len(parts) > 1:
                    self._say_streamed(parts, rl)        # Antwort: Satz für Satz, erster Satz sofort
                    continue
                with _CLR_LOCK:
                    wav = self.render(text, lang=rl)
                dur = _wav_seconds(wav)
                # „Funk-Disziplin“: nur sprechen, wenn bis zum nächsten Fahrlehrer-Kommando genug Ruhe ist
                # und gerade kein Kommando läuft – sonst warten (bis die Ansage zu alt ist).
                while not reply and (self.gate() < dur + 0.4 or time.time() < self.busy_until):
                    if time.time() - t > max_age + 4 or self.replies_waiting:   # zu alt / Antwort hat Vorfahrt
                        wav = None
                        break
                    time.sleep(0.1)
                if wav and reply:
                    while time.time() < self.busy_until:        # ein gerade laufendes Kommando noch ausklingen lassen
                        time.sleep(0.05)
                if wav:
                    self.speaking_until = time.time() + dur
                    self.last_text = text            # für „Otto, nochmal“
                    if reply and self.on_reply:
                        self.on_reply(dur, True)
                    elif self.on_other:
                        self.on_other(dur)               # läuft gerade eine Funk-Pause, verlängert sie sich um diese Ansage
                    winsound.PlaySound(wav, winsound.SND_MEMORY)
            except Exception as e:
                print("Sprachausgabe-Fehler:", e)

    def _say_streamed(self, parts: list[str], lang: str | None):
        """Lange Antworten: den ersten Satz sofort sprechen, die nächsten im Hintergrund berechnen
        (eine hochwertige Stimme braucht für 13 s Text sonst bis zu 15 s Rechenzeit, bevor überhaupt etwas kommt)."""
        wavs = [None] * len(parts)
        ready = [threading.Event() for _ in parts]

        def work():
            for i in range(1, len(parts)):
                try:
                    with _CLR_LOCK:
                        wavs[i] = self.render(parts[i], lang=lang)
                except Exception as e:
                    print("Sprachausgabe-Fehler:", e)
                ready[i].set()
        with _CLR_LOCK:
            wavs[0] = self.render(parts[0], lang=lang)
        threading.Thread(target=work, daemon=True).start()
        while time.time() < self.busy_until:                    # laufendes Kommando ausklingen lassen
            time.sleep(0.05)
        self.last_text = " ".join(parts)
        ended = False
        try:
            for i, w in enumerate(wavs):
                if i:
                    ready[i].wait(20)
                    w = wavs[i]
                if not w:
                    continue
                while time.time() < self.busy_until:            # z. B. „Auto links“ nicht abschneiden
                    time.sleep(0.05)
                dur = _wav_seconds(w)
                self.speaking_until = time.time() + dur
                last = i == len(parts) - 1
                if self.on_reply:
                    self.on_reply(dur, last)                    # Pause hält bis zum letzten Satz (+ Ruhe)
                ended = ended or last
                winsound.PlaySound(w, winsound.SND_MEMORY)
        finally:
            if not ended and self.on_reply:
                self.on_reply(0, True)                          # letzter Satz fehlte -> Pause trotzdem beenden

    async def _winrt_wav(self, text: str, vid: str, rate_boost: float = 1.0, vol: float = 100) -> bytes:
        s = WinRTSynth()
        pick = next((v for v in WinRTSynth.all_voices if v.display_name == vid), None)
        if pick:
            s.voice = pick
        s.options.speaking_rate = max(0.5, min(2.5, self.rate * rate_boost))
        s.options.audio_volume = max(0.0, min(1.0, vol / 100))
        stream = await s.synthesize_text_to_stream_async(text)
        reader = DataReader(stream.get_input_stream_at(0))
        n = stream.size
        await reader.load_async(n)
        buf = bytearray(n)
        reader.read_bytes(buf)
        return bytes(buf)


class SoundBank:
    """Fahrlehrer-Kommandos vorab als WAV erzeugen und ohne Verzögerung abspielen.
    Piep-Töne werden selbst berechnet."""

    CODES = ["brake_hard", "brake", "brake_light", "lift", "coast", "gas", "left", "right", "left_out", "right_out",
             "car_left", "car_right", "three_wide", "clear", "still_there", "car_behind", "fast_behind",
             "stay_outside", "hold_inside", "three_wide_brake", "cut_invalid",
             "crowd_outside", "crowd_inside", "crowd_careful", "still_behind"]

    def __init__(self, speaker: Speaker):
        import tempfile
        from pathlib import Path
        self.speaker = speaker
        self.dir = Path(tempfile.gettempdir()) / "otto_sounds"
        self.dir.mkdir(exist_ok=True)
        self.files: dict[str, str] = {}
        self._dur: dict[str, float] = {}
        self._key = None
        self._lock = threading.Lock()
        self._make_beeps()

    def _make_beeps(self):
        for name, freq, dur in (("beep3", 880, 0.07), ("beep2", 880, 0.07), ("beep1", 1320, 0.09)):
            p = self.dir / f"{name}.wav"
            with wave.open(str(p), "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
                frames = int(22050 * dur)
                w.writeframes(b"".join(struct.pack("<h", int(12000 * math.sin(2 * math.pi * freq * i / 22050)
                                                          * min(1, (frames - i) / 300))) for i in range(frames)))
            self.files[name] = str(p)
        # kleine Fanfare für einen neuen persönlichen Streckenrekord (C – E – G – C')
        p = self.dir / "fanfare.wav"
        notes = [(523, 0.12), (659, 0.12), (784, 0.12), (1047, 0.42)]
        frames = []
        for freq, dur in notes:
            n = int(22050 * dur)
            for i in range(n):
                env = min(1, i / 200) * min(1, (n - i) / 600)
                s = math.sin(2 * math.pi * freq * i / 22050) + 0.3 * math.sin(4 * math.pi * freq * i / 22050)
                frames.append(struct.pack("<h", int(9000 * env * s)))
        with wave.open(str(p), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
            w.writeframes(b"".join(frames))
        self.files["fanfare"] = str(p)

    def prepare(self):
        """Alle Kommandos mit aktueller Sprache/Stimme/Tempo erzeugen (im Hintergrund aufrufen)."""
        with self._lock:
            lang = self.speaker.cmd_lang or i18n.LANG
            vid = self.speaker._pick(lang)
            key = (lang, vid, self.speaker.vibe, round(self.speaker.rate, 2), self.speaker.volume)
            if key == self._key or not self.speaker.enabled:
                return
            for code in self.CODES:
                for attempt in range(3):          # beim Start kann .NET noch kurz beschäftigt sein
                    try:
                        tag = __import__("hashlib").md5(repr(key).encode()).hexdigest()[:8]
                        p = self.dir / f"{code}_{lang}_{tag}.wav"
                        # natürliche Stimme: mit Ausrufezeichen -> Kommando-Betonung („Bremsen!“)
                        text = T(code, _lang=lang) + ("!" if vid.startswith("piper:") else "")
                        with _CLR_LOCK:
                            wav = self.speaker.render(text, rate_boost=1.25, mood="command", lang=lang)
                        p.write_bytes(wav)
                        self.files[code] = str(p)
                        self._dur.pop(code, None)
                        break
                    except Exception as e:
                        if attempt == 2:
                            print("Sound-Bank:", code, e)
                        time.sleep(1)
            self._key = key

    # Spotter/Sicherheit: dürfen von Fahrlehrer-Pieps und -Kommandos nicht abgeschnitten werden
    PRIORITY = {"car_left", "car_right", "three_wide", "clear", "still_there", "car_behind", "fast_behind",
                "stay_outside", "hold_inside", "three_wide_brake", "cut_invalid",
                "crowd_outside", "crowd_inside", "crowd_careful", "still_behind"}
    _prio_until = 0.0

    def play(self, code: str):
        f = self.files.get(code)
        if code not in self.PRIORITY and time.time() < self._prio_until:
            return                                    # Spotter spricht gerade – Kommando fällt aus
        if f:
            if code not in self._dur:
                self._dur[code] = _wav_seconds(open(f, "rb").read())
            if code in self.PRIORITY:
                self._prio_until = time.time() + self._dur[code]
            self.speaker.busy_until = time.time() + self._dur[code] + 0.15
            winsound.PlaySound(f, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
        else:
            self.speaker.say(T(code), max_age=1.0)

    def beep(self, n: float):
        self.play({3.0: "beep3", 2.0: "beep2", 1.0: "beep1"}.get(n, "beep1"))


class Listener:
    """Hört auf „<Weckwort> …“-Befehle (oder ohne Weckwort kurz nach Knopfdruck)."""

    def __init__(self, on_command, min_confidence: float = 0.6):
        self.on_command = on_command
        self.min_confidence = min_confidence
        self.wake = "Otto"
        self.lang = "de"
        self.mode = "always"         # "always" (Weckwort) | "button" (nur kurz nach Lenkradknopf, ohne Weckwort)
        self.window_until = 0.0
        self.engine = None
        self.running = False
        self.last = ""
        self.error = ""
        self.note = ""
        self._phrases = {}
        self.ai_enabled = lambda: False   # setzt die Engine: KI-Engineer an + Schlüssel da
        self.on_speech = None             # Engine: Fahrer spricht gerade mit Otto -> Funk-Pause
        self.on_wake = None               # Engine: nur „Otto“ gehört -> Piep (jetzt zuhören)
        self.mic_device = ""              # "" = Windows-Standard, sonst Gerätename (otto/mic.py)
        self.mic_gain = 1.0               # Verstärkung der eigenen Aufnahme
        self.mic_sens = 6                 # Empfindlichkeit 1 (streng) .. 10 (sehr großzügig)
        self.capture = None
        self._grammar_lock = threading.Lock()
        self.last_audio = None            # WAV der letzten Frage für den KI-Engineer

    @staticmethod
    def _audio(r) -> bytes | None:
        """Die erkannte Sprachaufnahme als WAV (System.Speech liefert sie zu jedem Ergebnis mit)."""
        try:
            from System.IO import MemoryStream
            if r is None or r.Audio is None:
                return None
            ms = MemoryStream()
            r.Audio.WriteToWaveStream(ms)
            data = bytes(ms.ToArray())
            return data if len(data) > 8000 else None      # < ~0,25 s = nur ein Geräusch
        except Exception as e:
            print("Aufnahme für Engineer:", e)
            return None

    def _to_ai(self, r, text: str) -> bool:
        audio = self._audio(r)
        if not audio:
            return False
        self.last_audio = audio
        self.heard = (getattr(self, "heard", []) + [f"{time.strftime('%H:%M:%S')} „{text}“ → KI-Engineer"])[-10:]
        try:
            self._dispatch("ai", text)
        except Exception as e:
            print("Befehl-Fehler:", e)
        return True

    def _dispatch(self, cmd: str, text: str):
        """Befehl in eigenem Thread ausführen. Die Rückmeldung der Windows-Spracherkennung darf nie warten:
        „Coach an“, „lauter“ usw. stellen die Erkennung um – aus ihrer eigenen Rückmeldung heraus
        verklemmt sich das (Otto fror ein)."""
        def run():
            try:
                self.on_command(cmd, text)
            except Exception as e:
                print("Befehl-Fehler:", e)
        threading.Thread(target=run, daemon=True).start()

    def open_window(self, seconds: float = 6.0):
        """Nach Knopfdruck: ein paar Sekunden lang Befehle auch ohne Weckwort annehmen."""
        self.window_until = time.time() + seconds

    def _wake_only(self):
        """Nur das Weckwort gehört (Pause danach, oder der Rest ging im Lärm unter): kurzer Piep und 5 s lang
        Befehle ohne Weckwort annehmen – „Otto … (Piep) … Reifen“."""
        if self.mode == "button" or time.time() < self.window_until:
            return
        self.open_window(5.0)
        self.heard = (getattr(self, "heard", []) + [f"{time.strftime('%H:%M:%S')} „{self.wake}“ → höre zu"])[-10:]
        if self.on_wake:
            try:
                self.on_wake()
            except Exception as e:
                print("Weckwort:", e)

    def start(self) -> bool:
        if not AVAILABLE or self.running:
            return self.running
        with _CLR_LOCK:
            return self._start_any()

    def _start_any(self) -> bool:
        if self._start(self.lang):
            self.note = ""
            self._start_second("en" if self.lang == "de" else "de")
            return True
        if self.lang != "de" and self._start("de"):    # Ersatz: Befehle auf Deutsch
            self.note = "Englische Spracherkennung ist in Windows nicht installiert – Befehle bitte auf Deutsch."
            self.error = ""
            return True
        return False

    def _start(self, lang: str) -> bool:
        try:
            culture = CultureInfo(i18n.CULTURE[lang])
            # passendes installiertes Erkennungsmodul direkt wählen (über die Kultur klappt es nicht immer)
            info = next((r for r in SpeechRecognitionEngine.InstalledRecognizers()
                         if r.Culture.Name.lower() == i18n.CULTURE[lang].lower()), None)
            if info is None:
                raise RuntimeError(f"Keine Spracherkennung für {i18n.CULTURE[lang]} installiert")
            eng = SpeechRecognitionEngine(info)
            cmds = i18n.COMMANDS[lang]
            self._phrases = {f"{self.wake} {p}": c for p, c in cmds.items()}
            self._phrases.update(cmds)                        # ohne Weckwort (nur nach Knopf)
            self._phrases[self.wake] = "wake"                 # nur „Otto“ + Pause -> Piep, dann zuhören
            choices = Choices()
            for phrase in self._phrases:
                choices.Add(phrase)
            gb = GrammarBuilder(choices)
            gb.Culture = culture
            g = Grammar(gb)
            g.Name = "exact"
            eng.LoadGrammar(g)
            self._load_keywords(eng, lang, culture)
            self._load_places(eng, lang)
            own = self._open_input(eng)
            self._tune(eng)
            eng.SpeechRecognized += self._recognized
            eng.SpeechRecognitionRejected += self._rejected
            eng.AudioSignalProblemOccurred += self._signal      # selten; Pegel wird nur bei Bedarf abgefragt
            eng.SpeechHypothesized += self._hypothesis          # Zwischenergebnis: „Otto …“ -> Fahrlehrer pausiert
            eng.RecognizeAsync(RecognizeMode.Multiple)
            self.engine, self.running, self.error = eng, True, ""
            self._lang_active, self._gap_grammars, self._targets_sig = lang, [], None
            if getattr(self, "_targets", None):
                self.set_targets(self._targets)
        except Exception as e:
            self.error = f"Mikrofon/Spracherkennung nicht verfügbar: {str(e).splitlines()[0]}"
            print(f"Spracherkennung {lang}: {self.error}")
        return self.running

    def _start_second(self, lang: str):
        """Zweite Spracherkennung parallel (z. B. Englisch neben Deutsch) – nur Befehle, falls installiert.
        Klappt sie nicht (Sprachpaket fehlt), läuft alles wie bisher mit einer Sprache."""
        self.engine2 = None
        try:
            info = next((r for r in SpeechRecognitionEngine.InstalledRecognizers()
                         if r.Culture.Name.lower() == i18n.CULTURE[lang].lower()), None)
            if info is None:
                return
            eng = SpeechRecognitionEngine(info)
            culture = CultureInfo(i18n.CULTURE[lang])
            cmds = i18n.COMMANDS[lang]
            phrases = {f"{self.wake} {p}": c for p, c in cmds.items()}
            phrases.update(cmds)
            choices = Choices()
            for phrase in phrases:
                choices.Add(phrase)
            gb = GrammarBuilder(choices)
            gb.Culture = culture
            g = Grammar(gb)
            g.Name = "exact_" + lang
            eng.LoadGrammar(g)
            eng.SetInputToDefaultAudioDevice()
            eng.SpeechRecognized += self._recognized
            eng.RecognizeAsync(RecognizeMode.Multiple)
            for p, c in phrases.items():
                self._phrases.setdefault(p, c)
            self.engine2 = eng
            self.note2 = f"Zusätzlich aktiv: Spracherkennung {i18n.CULTURE[lang]}"
            print(self.note2)
        except Exception as e:
            print(f"Zweite Spracherkennung {lang} nicht verfügbar:", str(e).splitlines()[0])

    def _open_input(self, eng) -> bool:
        """Mikrofon-Eingang: eigene Aufnahme über eine Leitung (Gerät wählbar, Verstärkung, Pegel) –
        klappt das nicht, nimmt Otto wie bisher das Windows-Standardmikrofon."""
        try:
            from . import mic
            from System.Speech.AudioFormat import SpeechAudioFormatInfo, AudioBitsPerSample, AudioChannel
            dev = mic.find(self.mic_device)
            if self.mic_device and dev is None:
                self.note = f"Mikrofon „{self.mic_device}“ nicht gefunden – nehme Windows-Standard"
            stream = mic.audio_stream()
            self._stream = stream
            self.capture = mic.Capture(dev, self.mic_gain, lambda data: stream.Push(data))
            self.capture.denoise = getattr(self, "mic_denoise", True)
            if not self.capture.start():                 # Mikro belegt/gesperrt -> nicht ewig auf Daten warten
                raise RuntimeError(self.capture.error)
            eng.SetInputToAudioStream(stream, SpeechAudioFormatInfo(16000, AudioBitsPerSample.Sixteen, AudioChannel.Mono))
            return True
        except Exception as e:
            print("Eigene Mikrofon-Aufnahme nicht möglich, nehme Windows-Standard:", e)
            if self.capture is not None:
                self.capture.stop()
            self.capture = None
            self.note = f"Gewähltes Mikrofon nicht nutzbar ({e}) – nehme Windows-Standard"
            eng.SetInputToDefaultAudioDevice()
            return False

    def set_mic(self, device: str, gain: float, sens: int, denoise: bool = True):
        """Mikrofon-Einstellungen: Verstärkung/Empfindlichkeit/Filter sofort, Gerätewechsel mit Neustart der Erkennung."""
        restart = device != self.mic_device
        retune = int(sens) != self.mic_sens
        self.mic_device, self.mic_gain, self.mic_sens, self.mic_denoise = device, float(gain), int(sens), bool(denoise)
        if self.capture:
            self.capture.gain, self.capture.denoise = self.mic_gain, self.mic_denoise
        if self.engine is not None and retune:     # nur wenn sich die Empfindlichkeit wirklich geändert hat
            self._tune(self.engine)
        if restart and self.running:
            self.stop()
            self.start()

    def _thresholds(self):
        s = max(1, min(10, int(self.mic_sens)))
        # Empfindlichkeit hoch -> Windows verwirft weniger, Otto nimmt auch unsicherere Erkennungen an
        return 70 - s * 6, round(0.8 - s * 0.05, 2)

    def _tune(self, eng):
        """Erkennung einstellen: weniger „nicht verstanden“ (je nach Empfindlichkeit), Satzende nicht zu früh abschneiden."""
        from System import TimeSpan
        reject, self.min_confidence = self._thresholds()
        for name, val in (("CFGConfidenceRejectionThreshold", reject), ("HighConfidenceThreshold", 70),
                          ("NormalConfidenceThreshold", 45), ("LowConfidenceThreshold", 20)):
            try:
                eng.UpdateRecognizerSetting(name, val)
            except Exception:
                pass                         # nicht jede Windows-Version kennt jede Einstellung
        try:
            eng.EndSilenceTimeout = TimeSpan.FromMilliseconds(350)
            eng.EndSilenceTimeoutAmbiguous = TimeSpan.FromMilliseconds(700)
            eng.BabbleTimeout = TimeSpan.FromSeconds(0)
            eng.InitialSilenceTimeout = TimeSpan.FromSeconds(0)
        except Exception as e:
            print("Erkennung einstellen:", e)

    def mic_level(self) -> int:
        """Mikrofon-Pegel 0–100 – nur auf Nachfrage gelesen (ein Ereignis pro Pegeländerung bremst Python aus).
        Hält den Spitzenwert kurz, damit man beim Sprechen etwas sieht."""
        if self.capture is not None and self.capture.running:
            return self.capture.level
        try:
            lvl = int(self.engine.AudioLevel) if self.engine is not None else 0
        except Exception:
            lvl = 0
        if lvl >= getattr(self, "level_peak", 0) or time.time() - getattr(self, "_peak_t", 0) > 1.0:
            self.level_peak, self._peak_t = lvl, time.time()
        return self.level_peak

    def _hypothesis(self, sender, args):
        """Während du noch sprichst: beginnt es mit dem Weckwort (oder kurz nach Knopfdruck), Fahrlehrer pausieren."""
        try:
            text = args.Result.Text
        except Exception:
            return
        if self.on_speech and (text.startswith(self.wake) or time.time() < self.window_until):
            if time.time() - getattr(self, "_speech_t", 0) > 0.5:
                self._speech_t = time.time()
                self.on_speech()

    def _signal(self, sender, args):
        """Windows meldet Probleme mit dem Mikrofon-Signal (zu leise, zu laut, Rauschen, kein Signal)."""
        names = {"TooLoud": "Mikrofon übersteuert – Pegel in Windows etwas runter",
                 "TooSoft": "Mikrofon zu leise – näher ran oder Pegel in Windows hoch",
                 "TooNoisy": "Zu viel Hintergrundgeräusch – Headset-Mikro nutzen",
                 "NoSignal": "Kein Mikrofon-Signal – Standard-Aufnahmegerät in Windows prüfen",
                 "TooFast": "Etwas langsamer sprechen", "TooSlow": "Etwas zügiger sprechen"}
        try:
            p = str(args.AudioSignalProblem)
        except Exception:
            return
        if p in names:
            self.signal_note, self._signal_t = names[p], time.time()

    @staticmethod
    def _duration(r) -> float:
        try:
            return float(r.Audio.Duration.TotalSeconds) if r is not None and r.Audio is not None else 0.0
        except Exception:
            return 0.0

    def _load_keywords(self, eng, lang: str, culture):
        """Freie Sätze: „<Weckwort> … Sprit …“ – beliebige Wörter vor/nach einem Schlüsselwort.
        Ohne Weckwort nur nach Knopfdruck (wird in _recognized geprüft)."""
        kws = i18n.KEYWORDS.get(lang, {})
        if not kws:
            return
        try:
            wild = GrammarBuilder()
            wild.AppendWildcard()
            for with_wake in (True, False):
                gb = GrammarBuilder(self.wake) if with_wake else GrammarBuilder()
                gb.Culture = culture
                gb.Append(GrammarBuilder(wild, 0, 1))
                ch = Choices()
                for k in kws:
                    ch.Add(k)
                gb.Append(ch)
                gb.Append(GrammarBuilder(wild, 0, 1))
                g = Grammar(gb)
                g.Name = "kw"
                g.Priority = -1 if with_wake else -2  # genaue Sätze gehen vor, dann die mit Weckwort
                eng.LoadGrammar(g)
            # zwei Stichwörter: „Otto … Reifen … Rennen …“ – genauer als ein Stichwort, Antwort sofort und lokal
            for first, second, cmd in i18n.COMBOS.get(lang, []):
                for with_wake in (True, False):
                    gb = GrammarBuilder(self.wake) if with_wake else GrammarBuilder()
                    gb.Culture = culture
                    for part in (first, second):
                        gb.Append(GrammarBuilder(wild, 0, 1))
                        ch = Choices()
                        for k in part:
                            ch.Add(k)
                        gb.Append(ch)
                    gb.Append(GrammarBuilder(wild, 0, 1))
                    g = Grammar(gb)
                    g.Name = "combo:" + cmd
                    g.Priority = 0 if with_wake else -2
                    eng.LoadGrammar(g)
        except Exception as e:
            print("Freie Sprachbefehle nicht geladen:", e)

    # ---------- „Abstand zu Platz 3 / Nummer 8 / Fabian“ ----------
    # Als Baukasten-Grammatik statt tausender ausgeschriebener Sätze: früher 12.000 Sätze und 6 s Umbau bei jeder
    # Platzänderung (hat die Datenschleife blockiert). Jetzt: Plätze einmal beim Start, Namen/Nummern nur bei
    # Fahrerwechsel – und immer im Hintergrund.
    _PRE = {"de": ["Abstand", "Abstand zu", "Abstand zum", "Abstand zur", "Gap", "Gap zu", "Gäp", "Gäp zu"],
            "en": ["gap", "gap to", "distance to"]}
    _PLACE = {"de": ["Platz", "P", "Pe", "Position"], "en": ["position", "P", "place"]}
    _NUM = {"de": ["Nummer", "Startnummer", "Auto", "Wagen"], "en": ["number", "car"]}
    _ASK = {"de": ["wo ist", "wie schnell ist", "wie weit ist"], "en": ["where is", "how fast is", "how far is"]}
    _CATCH_A = {"de": ["kann ich", "krieg ich", "kriege ich", "hole ich"], "en": ["can I catch", "will I catch"]}
    _CATCH_B = {"de": ["einholen", "noch einholen", "kriegen", "noch kriegen", "ein", "noch ein"], "en": []}

    def _builder(self, lang: str, *parts, wake_optional: bool = True):
        """GrammarBuilder aus Teilen: str = festes Wort, list = eins davon, (list,) = optional eins davon."""
        gb = GrammarBuilder()
        gb.Culture = CultureInfo(i18n.CULTURE[lang])
        gb.Append(GrammarBuilder(self.wake), 0 if wake_optional else 1, 1)
        for part in parts:
            if isinstance(part, tuple):
                ch = Choices()
                for x in part[0]:
                    ch.Add(x)
                gb.Append(GrammarBuilder(ch), 0, 1)
            elif isinstance(part, list):
                ch = Choices()
                for x in part:
                    ch.Add(x)
                gb.Append(ch)
            else:
                gb.Append(part)
        return gb

    def _load_places(self, eng, lang: str):
        """„[Otto] [Abstand zu] Platz/P/Position 1–60“ – einmal beim Start."""
        try:
            nums = [str(n) for n in range(1, 61)]
            builders = [self._builder(lang, (self._PRE[lang],), self._PLACE[lang], nums)]
            # „Holt Platz 2 mich noch ein?“ / „Kann ich Platz 3 noch einholen?“ -> Aufhol-Rechnung
            if lang == "de":
                builders.append(self._builder(lang, ["holt", "kriegt", "schnappt"], (["mich"],), self._PLACE[lang], nums,
                                              (["mich"],), (["noch"],), (["ein", "ran"],)))
                builders.append(self._builder(lang, self._CATCH_A[lang], self._PLACE[lang], nums, self._CATCH_B[lang]))
            else:
                builders.append(self._builder(lang, ["is", "will"], self._PLACE[lang], nums, ["catching me", "catch me"]))
                builders.append(self._builder(lang, self._CATCH_A[lang], self._PLACE[lang], nums))
            for gb in builders:
                g = Grammar(gb)
                g.Name = "places"
                eng.LoadGrammar(g)
            # „Welche Reifen für 30 Minuten Rennen?“ – Renndauer selbst nennen (LMU verrät sie vor dem Start nicht)
            if lang == "de":
                gb = self._builder(lang, (["welche", "was für"],), ["Reifen", "Mischung", "Startreifen"],
                                   (["soll ich", "nehme ich"],), ["für", "bei", "für ein"], nums + ["eine", "anderthalb"],
                                   ["Minuten", "Stunden", "Stunde", "Runden"], (["Rennen"],))
            else:
                gb = self._builder(lang, (["which"],), ["tyres", "tires", "compound"], ["for"], (["a"],), nums,
                                   ["minute", "minutes", "hour", "hours", "lap", "laps"], (["race"],))
            g = Grammar(gb)
            g.Name = "racelen"
            eng.LoadGrammar(g)
        except Exception as e:
            print("Platz-Befehle nicht geladen:", e)

    def set_targets(self, drivers: list[dict]):
        """Namen/Nummern der Session nachladen – im Hintergrund, nur wenn sich die Fahrer ändern (nicht die Plätze)."""
        self._targets = drivers
        sig = tuple(sorted((d.get("name", ""), d.get("number", "")) for d in drivers if not d.get("player")))
        if sig == getattr(self, "_targets_sig", None):
            return
        self._targets_sig = sig

        def work():
            # eigene Sperre statt _CLR_LOCK: das Laden wartet auf die Erkennung – die Sprachausgabe darf
            # dabei nie mit blockiert werden (sonst stand bei hängendem Mikro alles still)
            with self._grammar_lock:
                if self.running and self.engine:
                    self._load_targets(drivers)
        threading.Thread(target=work, daemon=True).start()

    def _load_targets(self, drivers: list[dict]):
        lang = self._lang_active
        names, numbers = {}, set()
        for d in drivers:
            if d.get("player"):
                continue
            if d.get("number"):
                numbers.add(str(int(d["number"])))
            name = re.sub(r"[^A-Za-zÄÖÜäöüß \-]", "", d.get("name", "")).strip()
            if len(name) >= 2:
                names[name] = d["name"]
                first = name.split()[0]
                if len(first) >= 3:
                    names.setdefault(first, d["name"])
        self._target_names = names
        try:
            # alte Listen nicht entladen (Entladen wartet auf die laufende Erkennung): sie stören nicht,
            # weil nur Namen aus der aktuellen Liste einem Befehl zugeordnet werden
            grammars = []
            if numbers:
                grammars.append(("targets", self._builder(lang, (self._PRE[lang],), self._NUM[lang], sorted(numbers))))
            if names:
                nm = list(names)
                grammars.append(("targets", self._builder(lang, (self._PRE[lang] + self._ASK[lang],), nm)))
                if self._CATCH_B[lang]:
                    grammars.append(("targets", self._builder(lang, self._CATCH_A[lang], nm, self._CATCH_B[lang])))
                else:
                    grammars.append(("targets", self._builder(lang, self._CATCH_A[lang], nm)))
            self._gap_grammars = []
            for name, gb in grammars:
                g = Grammar(gb)
                g.Name = name
                self.engine.LoadGrammarAsync(g)        # nicht warten – lädt im Hintergrund
                self._gap_grammars.append(g)
        except Exception as e:
            print("Abstands-Befehle nicht geladen:", e)

    def _parse_target(self, text: str) -> str | None:
        """Text aus der Baukasten-Grammatik -> Befehl („Otto Gap zu P 3“ -> gap:place:3)."""
        lang = self._lang_active
        t = text[len(self.wake):].strip() if text.startswith(self.wake + " ") else text
        words = t.split()
        k = next((i for i, w in enumerate(words) if w.isdigit()), None)
        if k is not None:
            n = words[k]
            catch = any(w in ("holt", "kriegt", "schnappt", "einholen", "kriegen", "catch", "catching") for w in words) \
                or any(a in t for a in self._CATCH_A[lang])
            if any(w in self._PLACE[lang] for w in words[:k]):
                return f"catch:place:{n}" if catch else f"gap:place:{n}"
            if any(w in self._NUM[lang] for w in words[:k]):
                return f"gap:number:{n}"
        for nm, full in sorted(getattr(self, "_target_names", {}).items(), key=lambda x: -len(x[0])):
            if nm in t:
                rest = t.replace(nm, " ")
                if any(a in rest for a in self._CATCH_A[lang]):
                    return f"catch:name:{full}"
                return f"gap:name:{full}"
        return None

    def stop(self):
        with _CLR_LOCK:
            eng2, self.engine2 = getattr(self, "engine2", None), None
            if eng2:
                try:
                    eng2.SpeechRecognized -= self._recognized
                    eng2.RecognizeAsyncCancel()
                    eng2.Dispose()
                except Exception:
                    pass
            eng, self.engine, self.running = self.engine, None, False
            if self.capture is not None:
                self.capture.stop()
                self.capture = None
            if getattr(self, "_stream", None) is not None:
                try:
                    self._stream.Finish()          # Erkennung bekommt „Ende“, statt ewig zu warten
                except Exception:
                    pass
                self._stream = None
            if eng:
                try:                                   # Ereignisse abmelden, bevor Python sich beendet
                    eng.SpeechRecognized -= self._recognized
                    eng.SpeechRecognitionRejected -= self._rejected
                    eng.AudioSignalProblemOccurred -= self._signal
                    eng.SpeechHypothesized -= self._hypothesis
                except Exception:
                    pass
                try:
                    eng.RecognizeAsyncCancel()
                    eng.Dispose()
                except Exception:
                    pass

    def configure(self, wake: str, lang: str):
        wake = (wake or "Otto").strip()
        if wake != self.wake or lang != self.lang:
            self.wake, self.lang = wake, lang
            if self.running:      # Grammatik neu laden
                self.stop()
                self.start()

    def _rejected(self, sender, args):
        """Nicht verstanden: Nur wenn das Weckwort klar zu hören war („Otto, …“), kommt „Bitte wiederholen“ –
        sonst würde Otto bei jedem Geräusch nachfragen."""
        r = args.Result
        in_window = time.time() < self.window_until
        try:
            wake_ok = r is not None and r.Words.Count >= 2 and r.Words[0].Text == self.wake and r.Words[0].Confidence >= 0.75
            # lange Frage („Otto, welche Reifen ich nehmen soll fürs Rennen“): Weckwort darf unsicherer sein –
            # sonst verschwand die ganze Frage still (Testfahrt 12.10.)
            long_ok = r is not None and r.Words.Count >= 3 and r.Words[0].Text == self.wake \
                and r.Words[0].Confidence >= 0.5 and self._duration(r) >= 2.0
            if r is None or not (wake_ok or long_ok or (in_window and r.Words.Count >= 1)) \
                    or time.time() - getattr(self, "_again_t", 0) < 3:
                return
        except Exception:
            return
        self._again_t = time.time()
        if r.Text.strip() == self.wake:                 # nur „Otto“ (unsicher) gehört -> trotzdem zuhören
            self._wake_only()
            return
        guess = r.Text[len(self.wake):].strip() if r.Text.startswith(self.wake) else r.Text
        self.heard = (getattr(self, "heard", []) + [f"{time.strftime('%H:%M:%S')} „{r.Text}“ (unsicher {r.Confidence:.2f})"])[-10:]
        # 1) bekannter Befehl / Stichwort -> sofort lokal (schnell, offline). Kurze Äußerungen auch großzügiger.
        short = self._duration(r) < 2.4
        cmd = self._fuzzy(guess, 0.8) or (self._fuzzy(guess, 0.6) if short else None)
        if cmd is None and self.ai_enabled():       # 2) nur echte, längere Fragen -> KI (versteht viel mehr)
            self.window_until = 0.0
            if self._to_ai(r, r.Text):
                return
        cmd = cmd or self._fuzzy(guess, 0.6)        # 3) großzügiger ähnlicher Befehl
        if cmd:
            self.window_until = 0.0
            self.heard[-1] += f" → {cmd}"
            try:
                self._dispatch(cmd, r.Text)
            except Exception as e:
                print("Befehl-Fehler:", e)
            return
        try:
            self._dispatch("say_again", r.Text)
        except Exception as e:
            print("Befehl-Fehler:", e)

    def _fuzzy(self, text: str, cutoff: float) -> str | None:
        """Ähnlichsten bekannten Befehl suchen („wie viel Spritt“ -> fuel) – für Fälle, in denen Windows
        nur ungefähr verstanden hat. Erst ganze Sätze, dann einzelne Stichwörter."""
        import difflib
        t = (text or "").strip().lower()
        if len(t) < 3:
            return None
        phrases = {p.lower(): c for p, c in self._phrases.items() if not p.startswith(self.wake + " ") and c != "wake"}
        if t in phrases:
            return phrases[t]
        kws = {k.lower(): c for k, c in i18n.KEYWORDS.get(getattr(self, "_lang_active", "de"), {}).items()}
        words = t.replace(",", " ").split()
        hit = next((kws[w] for w in words if w in kws), None)     # klar gehörtes Stichwort („Reifen“) hat Vorrang
        if hit:
            return hit
        m = difflib.get_close_matches(t, list(phrases), n=1, cutoff=cutoff)
        if m:
            return phrases[m[0]]
        for w in words:
            m = difflib.get_close_matches(w, list(kws), n=1, cutoff=max(cutoff, 0.8))
            if m:
                return kws[m[0]]
        return None

    def _recognized(self, sender, args):
        r = args.Result
        if r is None:
            return
        in_window = time.time() < self.window_until
        # nach Knopfdruck großzügiger: man hat ja absichtlich gedrückt
        if r.Confidence < (0.3 if in_window else self.min_confidence):
            self._rejected(sender, args)          # unsicher erkannt -> ähnlicher Befehl / KI / „Bitte wiederholen“
            return
        text = r.Text
        if text == self.wake:                            # „Otto …“ mit Pause danach: Piep, 5 s ohne Weckwort zuhören
            self._wake_only()
            return
        has_wake = text.startswith(self.wake + " ")
        # Weckwort-Modus: Befehle mit Weckwort immer; Knopf-Modus: nur kurz nach dem Knopfdruck
        if (self.mode == "button" and not in_window) or (not has_wake and not in_window):
            return
        cmd = self._phrases.get(text)
        if cmd is None and r.Grammar is not None and r.Grammar.Name in ("places", "targets"):
            cmd = self._parse_target(text)
        if cmd is None and r.Grammar is not None and r.Grammar.Name == "racelen":
            cmd = "start_tyres"
        if cmd is None and r.Grammar is not None and r.Grammar.Name.startswith("combo:"):
            if r.Confidence < (0.35 if in_window else max(0.55, self.min_confidence - 0.1)):
                self._rejected(sender, args)
                return
            cmd = r.Grammar.Name[6:]
        if cmd is None and r.Grammar is not None and r.Grammar.Name == "kw":
            # freier Satz: kurz („Otto, … Reifen“) -> Otto antwortet sofort selbst;
            # lang („Otto, soll ich bei den Reifen auf Medium wechseln?“) -> KI-Engineer (versteht die ganze Frage)
            if self.ai_enabled() and self._duration(r) >= 2.4:
                self.window_until = 0.0
                if self._to_ai(r, text):
                    return
            # sonst: Schlüsselwort heraussuchen (etwas strenger, weil Platzhalter mehr zulassen)
            if r.Confidence < (0.4 if in_window else max(0.7, self.min_confidence)):
                return
            kws = i18n.KEYWORDS.get(self._lang_active, {})
            cmd = next((kws[w.Text] for w in r.Words if w.Text in kws), None)
        if cmd is None:
            return
        self.window_until = 0.0
        self.last = text
        self.heard = (getattr(self, "heard", []) + [f"{time.strftime('%H:%M:%S')} „{text}“ ({r.Confidence:.2f})"])[-10:]
        try:
            self._dispatch(cmd, text)
        except Exception as e:
            print("Befehl-Fehler:", e)


def default_mic() -> str:
    """Name des Standard-Aufnahmegeräts (das hört die Windows-Spracherkennung)."""
    import ctypes
    from ctypes import wintypes
    try:
        winmm = ctypes.windll.winmm

        class WAVEINCAPSW(ctypes.Structure):
            _fields_ = [("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("vDriverVersion", wintypes.UINT),
                        ("szPname", ctypes.c_wchar * 32), ("dwFormats", wintypes.DWORD), ("wChannels", wintypes.WORD),
                        ("wReserved1", wintypes.WORD)]
        dev, flags = wintypes.DWORD(0), wintypes.DWORD(0)
        # DRVM_MAPPER_PREFERRED_GET = 0x2015 auf WAVE_MAPPER (-1): welches Gerät ist Standard?
        if winmm.waveInMessage(wintypes.HANDLE(-1), 0x2015, ctypes.byref(dev), ctypes.byref(flags)) != 0:
            dev = wintypes.DWORD(0)
        caps = WAVEINCAPSW()
        if winmm.waveInGetDevCapsW(dev.value, ctypes.byref(caps), ctypes.sizeof(caps)) == 0:
            return caps.szPname
    except Exception:
        pass
    return ""


def _boost(wav: bytes, gain: float) -> bytes:
    """Lauter machen ohne hartes Übersteuern: Verstärkung mit weichem Begrenzer (tanh)."""
    import io
    try:
        import numpy as np
        with wave.open(io.BytesIO(wav)) as w:
            params, frames = w.getparams(), w.readframes(w.getnframes())
        if params.sampwidth != 2:
            return wav
        x = np.frombuffer(frames, dtype="<i2").astype(np.float32) / 32768.0
        y = np.tanh(x * gain) / np.tanh(min(gain, 3.0))       # leise Teile lauter, Spitzen weich begrenzt
        out = io.BytesIO()
        with wave.open(out, "wb") as w:
            w.setparams(params)
            w.writeframes((np.clip(y, -1, 1) * 32000).astype("<i2").tobytes())
        return out.getvalue()
    except Exception as e:
        print("Lautstärke-Verstärkung:", e)
        return wav


def _wav_seconds(wav: bytes) -> float:
    """Länge einer WAV-Datei in Sekunden (aus dem Header)."""
    import io
    import wave
    try:
        with wave.open(io.BytesIO(wav)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return 1.5


# ---------------------------------------------------------------- Zahlen zum Vorlesen
def say_time(ms: float) -> str:
    """1:39.815 -> „1 39 Komma 8“ / „1 39 point 8“."""
    tenths = int(round(ms / 100))                 # auf Zehntel runden (39,96 -> 40,0)
    m, rest = divmod(tenths, 600)
    whole, tenth = divmod(rest, 10)
    if not m:
        return f"{whole} {T('point')} {tenth}"
    return f"{m} {T('oh') + ' ' if whole < 10 else ''}{whole} {T('point')} {tenth}"


def say_delta(ms: float) -> str:
    """+234 -> „2 Zehntel langsamer“, -1530 -> „1 Komma 5 Sekunden schneller“."""
    a = abs(ms) / 1000
    word = T("slower") if ms > 0 else T("faster")
    if a < 0.05:
        return T("same")
    if a < 1:
        return f"{round(a * 10)} {T('tenths')} {word}"
    return f"{a:.1f} {T('seconds')} {word}".replace(".", f" {T('point')} ")
