"""Alle gesprochenen Texte auf Deutsch und Englisch. LANG wird aus den Einstellungen gesetzt."""
import threading
LANG = "de"
_local = threading.local()      # Antwortsprache nur für den aktuellen Sprachbefehl (Englisch gefragt -> Englisch)

TEXTS = {
    # Fahrlehrer-Kommandos (werden vorab als Audio erzeugt)
    "voice_ready": {"de": "So klinge ich jetzt. Besser, oder?", "en": "This is my new voice. Better, right?"},
    "brake_hard": {"de": "Hart bremsen", "en": "Brake hard"},
    "brake": {"de": "Bremsen", "en": "Brake"},
    "brake_light": {"de": "Leicht bremsen", "en": "Light brake"},
    "lift": {"de": "Lupfen", "en": "Lift"},
    "coast": {"de": "Rollen lassen", "en": "Coast"},
    "gas": {"de": "Gas", "en": "Power"},
    "left": {"de": "Links", "en": "Left"},
    "right": {"de": "Rechts", "en": "Right"},
    "left_out": {"de": "Links, außen bleiben", "en": "Left, stay wide"},
    "right_out": {"de": "Rechts, außen bleiben", "en": "Right, stay wide"},
    # Spotter (ebenfalls vorab als Audio)
    "car_left": {"de": "Auto links", "en": "Car left"},
    "car_right": {"de": "Auto rechts", "en": "Car right"},
    "three_wide": {"de": "Drei nebeneinander", "en": "Three wide"},
    "clear": {"de": "Frei", "en": "Clear"},
    # Runden / Begrüßung
    "lap": {"de": "Runde {t}", "en": "Lap {t}"},
    "invalid": {"de": "ungültig", "en": "invalid"},
    "pb": {"de": "Neuer persönlicher Streckenrekord{name}!", "en": "New personal track record{name}!"},
    "first_best": {"de": "erste Bestzeit", "en": "first best lap"},
    "new_best": {"de": "neue Bestzeit", "en": "new best"},
    "just": {"de": "ganz knapp", "en": "just"},
    "strong": {"de": "Stark{name}!", "en": "Nice one{name}!"},
    "close": {"de": "Ganz nah dran, weiter so.", "en": "So close, keep going."},
    "hello": {"de": "Hallo{name}! So klinge ich. Ich sage dir beim Fahren, wo du Zeit liegen lässt.",
              "en": "Hi{name}! This is how I sound. I'll tell you where you're losing time."},
    "greet": {"de": "Hallo{name}, {track}.", "en": "Hi{name}, {track}."},
    "greet_best": {"de": " Deine Bestzeit hier ist {t}.", "en": " Your best here is {t}."},
    "greet_new": {"de": " Neue Strecke für uns, viel Spaß.", "en": " New track for us, have fun."},
    # Sprachbefehle – Antworten
    "no_lap": {"de": "Noch keine Runde abgeschlossen.", "en": "No lap completed yet."},
    "last_lap": {"de": "Letzte Runde {t}", "en": "Last lap {t}"},
    "vs_best": {"de": ", {d} als die Bestzeit", "en": ", {d} than your best"},
    "best": {"de": "Bestzeit {t}", "en": "Best lap {t}"},
    "no_best": {"de": "Noch keine Bestzeit.", "en": "No best lap yet."},
    "delta": {"de": "Du bist {d}", "en": "You are {d}"},
    "no_delta": {"de": "Noch kein Vergleich möglich.", "en": "No comparison yet."},
    "no_pos": {"de": "Keine Positionsdaten.", "en": "No position data."},
    "pos": {"de": "Platz {p} von {n}", "en": "P{p} of {n}"},
    "ahead": {"de": ", {s} Sekunden zum Vordermann", "en": ", {s} seconds to the car ahead"},
    "behind": {"de": ", {s} Sekunden Vorsprung nach hinten", "en": ", {s} seconds to the car behind"},
    "no_fuel": {"de": "Keine Spritdaten.", "en": "No fuel data."},
    "fuel": {"de": "{l} Liter", "en": "{l} litres"},
    "fuel_laps": {"de": ", reicht für etwa {n} Runden", "en": ", about {n} laps left"},
    "gap_unknown": {"de": "Den Fahrer finde ich gerade nicht.", "en": "I can't find that driver right now."},
    "gap_who": {"de": "Platz {p}", "en": "P{p}"},
    "gap_num": {"de": ", Nummer {n}", "en": ", number {n}"},
    "gap_ahead_of_you": {"de": "{who} liegt {s} Sekunden vor dir", "en": "{who} is {s} seconds ahead"},
    "gap_behind_you": {"de": "{who} liegt {s} Sekunden hinter dir", "en": "{who} is {s} seconds behind"},
    "gap_laps_ahead": {"de": "{who} ist {n} Runden vor dir", "en": "{who} is {n} laps ahead"},
    "gap_laps_behind": {"de": "{who} liegt {n} Runden zurück", "en": "{who} is {n} laps down"},
    "gap_best": {"de": "{who}: Bestzeit {t}, du bist {d}", "en": "{who}: best lap {t}, you are {d}"},
    "gap_best_only": {"de": "{who}: Bestzeit {t}", "en": "{who}: best lap {t}"},
    "gap_nobest": {"de": "{who} hat noch keine Zeit gesetzt.", "en": "{who} has no lap time yet."},
    "tr_none": {"de": "Kein Verkehr in Sicht.", "en": "No traffic coming up."},
    "tr_ahead": {"de": "In {t} Sekunden {c}", "en": "{c} in {t} seconds"},
    "tr_then": {"de": ", danach {c} in {t} Sekunden", "en": ", then {c} in {t} seconds"},
    "tr_behind": {"de": "{c} kommt von hinten, {t} Sekunden", "en": "{c} coming from behind, {t} seconds"},
    "tr_alert": {"de": "Verkehr in {t} Sekunden, {c}", "en": "Traffic in {t} seconds, {c}"},
    "tr_alert_behind": {"de": "{c} von hinten", "en": "{c} behind"},
    "tr_num": {"de": " Nummer {n}", "en": " number {n}"},
    "rec_on": {"de": "Aufnahme läuft.", "en": "Recording."},
    "rec_off": {"de": "Aufnahme gestoppt.", "en": "Recording stopped."},
    "coach_on": {"de": "Coach ist an.", "en": "Coach is on."},
    "coach_off": {"de": "Okay, ich sage nur noch Rundenzeiten.", "en": "Okay, lap times only from now."},
    "help": {"de": "Sag zum Beispiel: {w} Rundenzeit, {w} Delta, {w} wo verliere ich Zeit, {w} Gap vorne, "
                   "{w} Abstand zu P 3, {w} wo ist mein Kumpel, {w} wie lange noch, {w} Sprit, {w} Wetter, oder {w} Ruhe.",
             "en": "Try: {w} lap time, {w} delta, {w} where am I slow, {w} gap ahead, {w} gap to P 3, "
                   "{w} where is my buddy, {w} time left, {w} fuel, {w} weather, or {w} quiet."},
    "button_saved": {"de": "Knopf gespeichert.", "en": "Button saved."},
    "need_ref": {"de": "Ich brauche erst eine saubere, vollständige Runde als Vergleich.",
                 "en": "I need one clean full lap to compare first."},
    "no_issues": {"de": "In der letzten Runde hast du nirgends deutlich Zeit verloren. Sauber.",
                  "en": "No big time loss last lap. Clean."},
    "costs": {"de": "kostet", "en": "costs"},
    # Session / Wetter / Kumpel / Bedienung
    "no_session": {"de": "Keine Sessiondaten.", "en": "No session data."},
    "time_left": {"de": "Noch {m} Minuten", "en": "{m} minutes to go"},
    "time_left_s": {"de": "Noch {s} Sekunden", "en": "{s} seconds to go"},
    "laps_est": {"de": ", etwa {n} Runden", "en": ", about {n} laps"},
    "laps_left": {"de": "Noch {n} Runden", "en": "{n} laps to go"},
    "time_over": {"de": "Die Zeit ist um – das ist die letzte Runde.", "en": "Time is up, this is the last lap."},
    "min_warn": {"de": "Noch {m} Minuten.", "en": "{m} minutes left."},
    "weather": {"de": "Luft {a} Grad, Strecke {t} Grad, {c}.", "en": "Air {a} degrees, track {t}, {c}."},
    "w_rain": {"de": "es regnet", "en": "it's raining"},
    "w_wet": {"de": "die Strecke ist nass", "en": "the track is wet"},
    "w_damp": {"de": "die Strecke ist feucht", "en": "the track is damp"},
    "w_clouds": {"de": "trocken, aber dunkle Wolken", "en": "dry, but dark clouds"},
    "w_dry": {"de": "trocken", "en": "dry"},
    "fuel_end_ok": {"de": ", reicht bis zum Ende", "en": ", enough to the finish"},
    "fuel_end_short": {"de": ", bis zum Ende fehlen etwa {l} Liter", "en": ", about {l} litres short for the finish"},
    "friend_unset": {"de": "Sag mir in den Einstellungen unter Coach, wer dein Kumpel ist.",
                     "en": "Tell me in the coach settings who your buddy is."},
    "friend_missing": {"de": "{n} ist gerade nicht auf dem Server.", "en": "{n} is not on the server right now."},
    "friend_pits": {"de": "{n} ist in der Box.", "en": "{n} is in the pits."},
    "friend_out": {"de": "{n} fährt wieder raus.", "en": "{n} is back out."},
    "friend_best": {"de": "{n} fährt neue Bestzeit, {t}.", "en": "{n} sets a new best, {t}."},
    "friend_vs": {"de": " Du bist {d}.", "en": " You are {d}."},
    "friend_track": {"de": "{n} ist {m} Meter {w} dir auf der Strecke", "en": "{n} is {m} metres {w} you on track"},
    "w_ahead": {"de": "vor", "en": "ahead of"},
    "w_behind": {"de": "hinter", "en": "behind"},
    "passed_friend": {"de": "Du bist an {n} vorbei!", "en": "You're past {n}!"},
    "friend_passed": {"de": "{n} ist an dir vorbei.", "en": "{n} got past you."},
    "friend_close": {"de": "{n} ist direkt hinter dir.", "en": "{n} is right behind you."},
    "blue": {"de": "Blaue Flagge – schnelleres Auto hinter dir, lass es vorbei.",
             "en": "Blue flag, faster car behind, let it by."},
    "session": {"de": "{n} Runden, davon {v} sauber. Bestzeit {b}, Schnitt {a}, Streuung {s}.",
                "en": "{n} laps, {v} clean. Best {b}, average {a}, spread {s}."},
    "louder": {"de": "So besser?", "en": "Better?"},
    "quieter": {"de": "Okay, leiser.", "en": "Okay, quieter."},
    "tyres": {"de": "Reifen vorne {fl} und {fr}, hinten {rl} und {rr} Grad. Druck vorne {pf} bar. Abnutzung bis {w} Prozent.",
              "en": "Tyres front {fl} and {fr}, rear {rl} and {rr} degrees. Front pressure {pf} bar. Wear up to {w} percent."},
    "no_tyres": {"de": "Keine Reifendaten – erst losfahren.", "en": "No tyre data yet, get moving first."},
    # Race Engineer: Aufholen / Verteidigen
    "catch_yes": {"de": "Ja. Du holst {c} pro Runde auf {who}, in etwa {n} Runden bist du dran.",
                  "en": "Yes. You're gaining {c} a lap on {who}, you'll be on him in about {n} laps."},
    "catch_barely": {"de": "Ganz knapp. Du holst {c} pro Runde, das wird eine Sache der letzten Runde. Halte {t} oder schneller.",
                     "en": "Barely. You're gaining {c} a lap, it comes down to the last lap. Keep it at {t} or better."},
    "catch_short": {"de": "Knapp nicht. Du holst {c} pro Runde, am Ende fehlen dir etwa {s} Sekunden. Mit {t} pro Runde schaffst du es.",
                    "en": "Not quite. You're gaining {c} a lap, you'll be about {s} seconds short. Lap in {t} and you'll get him."},
    "catch_no": {"de": "Im Moment nicht, {who} ist {c} pro Runde schneller. Du bräuchtest im Schnitt {t}.",
                 "en": "Not at this pace, {who} is {c} a lap quicker. You'd need to average {t}."},
    "catch_unreal": {"de": "Ehrlich gesagt nein. Dafür bräuchtest du im Schnitt {t} – schneller als deine Bestzeit. Sichere die Position.",
                     "en": "Honestly, no. You'd need to average {t}, faster than your best. Secure the position."},
    "def_safe": {"de": "Nein, {who} kommt nicht ran. Du bist {c} pro Runde schneller.",
                 "en": "No, {who} is not catching you. You're {c} a lap quicker."},
    "def_ok": {"de": "{who} holt {c} pro Runde, aber das reicht nicht – am Ende fehlen ihm etwa {s} Sekunden. Bleib unter {t}.",
               "en": "{who} is gaining {c} a lap, but should run out of time, about {s} seconds short. Stay under {t}."},
    "def_barely": {"de": "Knapp. {who} holt {c} pro Runde, in der letzten Runde könnte er dran sein. Du musst unter {t} bleiben.",
                   "en": "Barely. {who} is gaining {c} a lap, it'll be close at the end. You need to stay under {t}."},
    "def_caught": {"de": "Ja, {who} holt {c} pro Runde und ist in etwa {n} Runden dran. Um vorne zu bleiben, brauchst du {t}.",
                   "en": "Yes, {who} is catching you, {c} a lap, on you in about {n} laps. You need {t} to stay ahead."},
    "catch_nodata": {"de": "Dafür brauche ich von euch beiden erst ein, zwei volle Runden.",
                     "en": "I need a lap or two from both of you first."},
    "catch_norace": {"de": "Das geht nur im Rennen.", "en": "That only works in a race."},
    "catch_none_ahead": {"de": "Vor dir ist niemand aus deiner Klasse. Du führst!", "en": "Nobody ahead in your class. You're leading!"},
    "catch_none_behind": {"de": "Hinter dir ist niemand aus deiner Klasse.", "en": "Nobody behind you in your class."},
    # Reifen & Bremsen (Renningenieur)
    "tyres_each": {"de": "Vorne links {fl}, rechts {fr}, hinten links {rl}, rechts {rr} Grad.",
                   "en": "Front left {fl}, right {fr}, rear left {rl}, right {rr} degrees."},
    "tyres_cold2": {"de": "Reifen kalt.", "en": "Tyres cold."},
    "tyres_ok2": {"de": "Reifen im Fenster.", "en": "Tyres in the window."},
    "tyres_hot2": {"de": "Reifen zu heiß, sanfter fahren.", "en": "Tyres hot, ease off."},
    "tyres_grip_from": {"de": "Grip ab {c}.", "en": "Grip from {c}."},
    "tyres_press": {"de": "Druck {pf} vorne, {pr} hinten.", "en": "Pressures {pf} front, {pr} rear."},
    "tyres_wear2": {"de": "Abnutzung {w} Prozent.", "en": "Wear {w} percent."},
    "brakes_each": {"de": "Vorne links {fl}, vorne rechts {fr}, hinten links {rl}, hinten rechts {rr} Grad.",
                    "en": "Front left {fl}, front right {fr}, rear left {rl}, rear right {rr} degrees."},
    "tyres_cold": {"de": "Reifen noch kalt: vorne {f}, hinten {r} Grad. Richtig Grip ab etwa {c} Grad.",
                   "en": "Tyres still cold: fronts {f}, rears {r} degrees. Proper grip from about {c}."},
    "tyres_ok": {"de": "Reifen im Fenster: vorne {f}, hinten {r} Grad.", "en": "Tyres are in the window: fronts {f}, rears {r}."},
    "tyres_hot": {"de": "Reifen zu heiß: vorne {f}, hinten {r} Grad. Weniger rutschen, sanfter rein und raus.",
                  "en": "Tyres running hot: fronts {f}, rears {r}. Less sliding, smoother in and out."},
    "tyres_wear": {"de": "Druck vorne {p} bar, Abnutzung {w} Prozent.", "en": "Front pressure {p} bar, wear {w} percent."},
    "eta_laps": {"de": "Warm in etwa {n} Runden.", "en": "Up to temp in about {n} laps."},
    "eta_s": {"de": "Warm in etwa {s} Sekunden.", "en": "Up to temp in about {s} seconds."},
    "tyres_push": {"de": "Mehr pushen, dann kommen sie.", "en": "Push harder, they'll come in."},
    "tyres_warm_now": {"de": "Reifen sind jetzt auf Temperatur. Du kannst pushen.", "en": "Tyres are up to temperature. You can push now."},
    "tyres_hot_alert": {"de": "Reifen {a} werden zu heiß, {t} Grad. Etwas sanfter.", "en": "{a} tyres getting hot, {t} degrees. Ease off a little."},
    "front_axle": {"de": "vorne", "en": "Front"},
    "rear_axle": {"de": "hinten", "en": "Rear"},
    "brakes_cold": {"de": "Bremsen noch kalt, {b} Grad. Richtig beißen tun sie ab etwa {c} Grad – bis dahin etwas früher bremsen.",
                    "en": "Brakes still cold, {b} degrees. They bite properly from about {c}, so brake a touch earlier until then."},
    "brakes_ok": {"de": "Bremsen im Fenster, {b} Grad.", "en": "Brakes are in the window, {b} degrees."},
    "brakes_warm": {"de": "Bremsen warm, {b} Grad – noch okay, aber nicht weiter aufheizen.", "en": "Brakes warm, {b} degrees, still fine but don't cook them."},
    "brakes_hot": {"de": "Bremsen sehr heiß, {b} Grad! Sanfter bremsen, im Windschatten etwas Abstand lassen.",
                   "en": "Brakes very hot, {b} degrees! Brake gentler and give some room out of the tow."},
    "ai_nokey": {"de": "Für den KI-Engineer fehlt noch der Schlüssel – Einstellungen, System.",
                 "en": "The AI engineer needs a key first, settings, system."},
    "ai_offline": {"de": "Engineer gerade nicht erreichbar.", "en": "Engineer offline right now."},
    "ai_test_q": {"de": "Funkcheck: Wie ist meine Lage gerade, in einem Satz?", "en": "Radio check: how am I doing right now, in one sentence?"},
    "some": {"de": "einige", "en": "several"},
    "wet_name": {"de": "Regenreifen", "en": "wets"},
    "comp_take": {"de": "Ich würde {rec} nehmen.", "en": "I'd go {rec}."},
    "comp_stay": {"de": "Bleib auf {rec}.", "en": "Stay on the {rec}."},
    "comp_not": {"de": "Lieber {rec}, nicht {asked}.", "en": "I'd rather go {rec}, not {asked}."},
    "why_wet": {"de": "Die Strecke ist nass.", "en": "The track is wet."},
    "why_dry": {"de": "Die Strecke ist abgetrocknet.", "en": "The track has dried."},
    "why_short": {"de": "Nur noch etwa {n} Runden, Soft hält das und ist am schnellsten.", "en": "Only about {n} laps left, softs will last and are quickest."},
    "why_hot": {"de": "Heiße Strecke, {t} Grad – Soft und Medium bauen zu schnell ab.", "en": "Hot track, {t} degrees, softer tyres will fade."},
    "why_long": {"de": "Noch etwa {n} Runden, das ist ein langer Stint.", "en": "About {n} laps to go, long stint."},
    "why_mid": {"de": "Guter Kompromiss für etwa {n} Runden.", "en": "Good compromise for about {n} laps."},
    "comp_worn": {"de": "Deine Reifen sind schon zu {w} Prozent runter.", "en": "Your tyres are already {w} percent worn."},
    "pit_nodata": {"de": "Dafür brauche ich erst eine Runde Spritverbrauch.", "en": "I need one lap of fuel data first."},
    "pit_now": {"de": "Box, Box! Der Sprit reicht nur noch {n} Runden.", "en": "Box, box! Fuel only for {n} more laps."},
    "pit_wets": {"de": "Box für Regenreifen, die Strecke ist nass.", "en": "Box for wets, the track is wet."},
    "pit_stay_end": {"de": "Bleib draußen, der Sprit reicht bis ins Ziel.", "en": "Stay out, fuel is good to the end."},
    "pit_worn": {"de": "Aber die Reifen sind bei {w} Prozent Abnutzung.", "en": "But the tyres are at {w} percent wear."},
    "pit_later": {"de": "Du musst noch einmal rein. Der Sprit reicht für etwa {n} Runden.", "en": "You need one more stop. Fuel for about {n} laps."},
    "say_again": {"de": "Bitte wiederholen.", "en": "Say again?"},
    "focus": {"de": "Größter Verlust in {t}", "en": "Biggest loss in {t}"},
    "nothing_said": {"de": "Ich habe noch nichts gesagt.", "en": "I haven't said anything yet."},
    # Tipps nach der Kurve
    "corner": {"de": "Kurve {n}", "en": "Turn {n}"},
    "better": {"de": "{c} besser", "en": "{c} better"},
    "good_so": {"de": ", gut so", "en": ", good job"},
    "a_brake_later": {"de": "{m} Meter später bremsen", "en": "brake {m} metres later"},
    "a_brake_earlier": {"de": "früher bremsen, zu schnell rein", "en": "brake earlier, too fast in"},
    "a_carry_speed": {"de": "{v} km/h mehr mitnehmen", "en": "carry {v} more speed"},
    "a_throttle_earlier": {"de": "früher aufs Gas", "en": "earlier on power"},
    "a_exit": {"de": "besser rausbeschleunigen", "en": "better exit"},
    "a_line": {"de": "{z} Zehntel verloren", "en": "lost {z} tenths"},
    "r_brake_later": {"de": "später bremsen", "en": "brake later"},
    "r_brake_earlier": {"de": "früher bremsen", "en": "brake earlier"},
    "r_carry_speed": {"de": "mehr Speed mitnehmen", "en": "carry more speed"},
    "r_throttle_earlier": {"de": "früh aufs Gas", "en": "early power"},
    "r_exit": {"de": "sauber rausbeschleunigen", "en": "clean exit"},
    # Zahlen
    "point": {"de": "Komma", "en": "point"},
    "faster": {"de": "schneller", "en": "faster"},
    "slower": {"de": "langsamer", "en": "slower"},
    "same": {"de": "gleich schnell", "en": "the same"},
    "tenths": {"de": "Zehntel", "en": "tenths"},
    "seconds": {"de": "Sekunden", "en": "seconds"},
    "oh": {"de": "null", "en": "oh"},
}

# Sprachbefehle (ohne Weckwort) -> Kennung.
# Schreibweise: (a|b) = eins davon, [x] = darf fehlen. Viele Synonyme, damit man frei reden kann –
# auch Renn-Englisch („Gap“, „Fuel“, „Last Lap“). Englische Wörter zusätzlich in deutscher Lautschrift
# („Fjuhl“), weil die deutsche Spracherkennung sie sonst schlecht versteht.
COMMAND_SPEC = {
    "de": {
        "last_lap": ["(Rundenzeit|letzte Runde|Zeit|Last Lap|Läst Läp|Lap Time|Läp Taim|Laptime)",
                     "(wie|was) war [die|meine] [letzte] Runde", "letzte Zeit"],
        "best": ["(Bestzeit|beste Runde|schnellste Runde|Rekord|Best Lap|Best Läp|Personal Best)",
                 "was ist meine Bestzeit"],
        "delta": ["(Delta|Split|wie liege ich|wie stehe ich|bin ich schneller|bin ich langsamer|wie läuft es)"],
        "where": ["(wo verliere ich Zeit|Tipp|Tip|Feedback|Fokus|Lernziel)", "gib mir einen Tipp",
                  "was mache ich falsch", "wo bin ich langsam", "worauf soll ich achten"],
        "position": ["(Position|Platz|Pe|Standing|Abstand|Gap|Gäp|Abstände)", "welcher Platz",
                     "auf welchem Platz bin ich", "wo liege ich"],
        "fuel": ["(Sprit|Benzin|Tank|Fuel|Fjuhl|Fjuel|Spritstand|Tankinhalt)", "wie viel Sprit [habe ich] [noch]",
                 "reicht der Sprit", "wie lange reicht der Sprit"],
        "gap:ahead": ["(Abstand|Gap|Gäp) [nach] vorne", "(Abstand|Gap) zum Vordermann", "wer ist vor mir",
                      "wie weit ist der Vordermann [weg]", "(Gap ahead|Gäp ehed)"],
        "gap:behind": ["(Abstand|Gap|Gäp) [nach] hinten", "(Abstand|Gap) zum Hintermann", "wer ist hinter mir",
                       "wie weit ist der Hintermann [weg]", "(Gap behind|Gäp bihaind)"],
        "gap:leader": ["(Abstand|Gap) (zum Führenden|zur Spitze|Leader|Lieder)", "wie weit ist der Führende [weg]"],
        "traffic": ["(Verkehr|Traffic|Träffik|Multiclass)", "wann kommt Verkehr", "wer kommt [von hinten]", "kommt wer"],
        "time_left": ["(Restzeit|Zeit übrig|Time left|Taim left|Runden übrig|Laps left|Läps left)",
                      "wie lange [geht es] noch", "wie viel Zeit [ist] noch", "wie viele Runden [sind es] noch"],
        "weather": ["(Wetter|Regen|Temperatur|Streckentemperatur|Weather|Wedder)", "regnet es", "kommt Regen",
                    "wie warm ist die Strecke"],
        "friend": ["(Kumpel|mein Kumpel|Buddy|Teamkollege|Partner|Bro)",
                   "wo ist mein (Kumpel|Buddy|Teamkollege|Partner)",
                   "(Abstand|Gap) (zum Kumpel|zu meinem Kumpel|zum Teamkollegen|zum Partner|zum Buddy)",
                   "wie schnell ist mein (Kumpel|Buddy|Teamkollege|Partner)"],
        "tyres": ["(Reifen|Reifentemperatur|Reifendruck|Gummi|Tyres|Tires|Teiers|Tyre temps)", "wie sind die Reifen",
                  "(sind|wann sind) die Reifen (warm|auf Temperatur)", "Reifen warm", "wie warm sind die Reifen"],
        "brakes": ["(Bremsen|Bremstemperatur|Bremsentemperatur|Brakes|Brake temps|Breiks)",
                   "(sind|wann sind) die Bremsen (warm|auf Temperatur)", "wie (warm|heiß) sind die Bremsen"],
        "catch:ahead": ["(schaffe|schaff) ich es [noch] (aufzuholen|ranzukommen|ihn zu kriegen)",
                        "(kann|krieg|kriege|hol|hole) ich ihn [noch] (einholen|kriegen|ein)", "krieg ich ihn [noch]",
                        "(reicht es|reicht das) [noch] zum (Aufholen|Einholen|Überholen)", "(Aufholen|Catch|Kätsch)",
                        "(will I catch him|can I catch him|Will ai kätsch him)"],
        "catch:behind": ["holt er mich ein", "(kommt|kriegt) er [mich] [noch] (ran|ein)", "holt der Hintermann auf",
                         "wird es (eng|knapp) [nach hinten]", "(is he catching me|Is hi kätsching mi)"],
        "catch:friend": ["(kann|krieg|kriege|hol|hole) ich meinen (Kumpel|Buddy|Teamkollegen|Partner) [noch] (einholen|kriegen|ein)",
                         "holt mein (Kumpel|Buddy|Teamkollege|Partner) mich ein"],
        "session": ["(Zusammenfassung|Statistik|Summary|Sammeri)", "wie läuft die Session", "wie lief es [bisher]"],
        "repeat": ["(Wiederholen|wiederhol das|nochmal|noch mal|Repeat|wie bitte|was hast du gesagt)"],
        "louder": ["(lauter|Lautstärke hoch|Volume up)"],
        "quieter": ["(leiser|Lautstärke runter|Volume down)"],
        "rec_start": ["Aufnahme (starten|start|an)", "(nimm auf|Record)"],
        "rec_stop": ["Aufnahme (stoppen|stop|aus)"],
        "coach_on": ["(Coach|Fahrlehrer|Kommandos) an", "(Coach|Fahrlehrer) on", "weiter ansagen"],
        "coach_off": ["(Coach|Fahrlehrer|Kommandos) aus", "(Coach|Fahrlehrer) off", "(Ruhe|sei leise|sei still)"],
        "help": ["(Hilfe|Help|Hälp|was kannst du)", "welche Befehle gibt es"],
    },
    "en": {
        "last_lap": ["(lap time|last lap|laptime)", "how was [my] [last] lap"],
        "best": ["(best lap|best time|personal best|record)", "what is my best [lap]"],
        "delta": ["(delta|split|how am I doing|am I faster|am I slower)"],
        "where": ["(where am I slow|where am I losing time|tip|feedback|focus)", "give me a tip", "what am I doing wrong"],
        "position": ["(position|place|standing|gap|gaps)", "what position am I", "where am I"],
        "fuel": ["(fuel|fuel level|tank)", "how much fuel [do I have] [left]", "will the fuel last"],
        "gap:ahead": ["(gap|distance) ahead", "gap to the car ahead", "who is ahead [of me]"],
        "gap:behind": ["(gap|distance) behind", "gap to the car behind", "who is behind [me]"],
        "gap:leader": ["gap to [the] leader", "how far is the leader"],
        "traffic": ["(traffic|multiclass)", "when is traffic", "who is coming"],
        "time_left": ["(time left|time remaining|laps left|laps remaining)", "how long to go", "how many laps [to go]"],
        "weather": ["(weather|rain|track temperature|temperature)", "is it raining", "is rain coming"],
        "friend": ["(buddy|my buddy|mate|teammate|partner)", "where is my (buddy|mate|teammate|partner)",
                   "gap to my (buddy|mate|teammate|partner)"],
        "tyres": ["(tyres|tires|tyre temps|tire pressure)", "how are the tyres", "are the tyres warm"],
        "brakes": ["(brakes|brake temps)", "how are the brakes", "are the brakes warm"],
        "catch:ahead": ["(will|can) I catch him", "can I catch the car ahead", "(catch|catching)"],
        "catch:behind": ["is he catching me", "(is|will) the car behind catch me"],
        "catch:friend": ["can I catch my (buddy|mate|teammate)", "is my (buddy|mate|teammate) catching me"],
        "session": ["(summary|stats|session summary)", "how is the session going"],
        "repeat": ["(repeat|say again|say that again|pardon)"],
        "louder": ["(louder|volume up)"],
        "quieter": ["(quieter|volume down)"],
        "rec_start": ["start recording"], "rec_stop": ["stop recording"],
        "coach_on": ["coach on"], "coach_off": ["(coach off|quiet|be quiet)"],
        "help": ["(help|what can you do)"],
    },
}
# Schlüsselwörter für freie Sätze: „Otto, sag mal, wie viel Sprit hab ich noch?“ -> fuel.
# (Spracherkennung mit Platzhaltern: Weckwort … Schlüsselwort …)
KEYWORDS = {
    "de": {"Sprit": "fuel", "Benzin": "fuel", "Tank": "fuel", "Fuel": "fuel", "Bestzeit": "best", "Rekord": "best",
           "Rundenzeit": "last_lap", "Delta": "delta", "Tipp": "where", "Fokus": "where", "Verkehr": "traffic", "Traffic": "traffic", "Wetter": "weather", "Regen": "weather",
           "Temperatur": "weather", "Restzeit": "time_left", "übrig": "time_left", "Kumpel": "friend", "Reifen": "tyres", "Bremsen": "brakes", "Medium": "compound", "Soft": "compound",
           "Hard": "compound", "Mischung": "compound", "Regenreifen": "compound", "Box": "pit", "Boxenstopp": "pit",
           "hinten": "gap:behind", "vorne": "gap:ahead", "Vorsprung": "gap:behind", "Rückstand": "gap:ahead", "aufholen": "catch:ahead", "einholen": "catch:ahead",
           "Verfolger": "catch:behind",
           "Buddy": "friend", "Teamkollege": "friend", "Zusammenfassung": "session", "Statistik": "session",
           "wiederholen": "repeat", "lauter": "louder", "leiser": "quieter", "Hilfe": "help",
           "Vordermann": "gap:ahead", "Hintermann": "gap:behind", "Führende": "gap:leader", "Führenden": "gap:leader"},
    "en": {"fuel": "fuel", "best": "best", "delta": "delta", "traffic": "traffic",
           "weather": "weather", "rain": "weather", "buddy": "friend", "mate": "friend", "summary": "session",
           "repeat": "repeat", "louder": "louder", "quieter": "quieter", "help": "help", "leader": "gap:leader"},
}


# Weitere Varianten (Umgangssprache, Funk-Englisch) – werden an COMMAND_SPEC angehängt
EXTRA_SPEC = {
    "de": {
        "last_lap": ["(Rundenzeit|Zeit) bitte", "wie schnell war (ich|die Runde|die letzte)", "Zeit der letzten Runde",
                     "was bin ich [gerade] gefahren", "(meine|die) letzte Zeit"],
        "best": ["(meine|die) Bestzeit", "was ist (die|meine) beste Zeit", "schnellste Zeit", "beste Zeit"],
        "delta": ["(bin ich|liege ich) auf Bestzeitkurs", "(wie|was) ist (mein|das) Delta", "Delta bitte", "(Pace|Peys)",
                  "wie ist meine Pace", "bin ich gut unterwegs", "wie sieht es aus"],
        "where": ["wo kann ich (schneller werden|Zeit holen|mich verbessern)", "(was|wo) soll ich besser machen",
                  "wo lasse ich Zeit liegen", "was kann ich besser machen"],
        "position": ["(welche Position|Rennstand|Stand|Platzierung)", "welcher Platz bin ich", "auf welcher Position bin ich",
                     "(wie|wo) liege ich im Rennen", "was ist meine Position"],
        "fuel": ["wie viel Sprit hab ich [noch]", "(habe|hab) ich [noch] genug Sprit", "reicht (mein|das) Benzin",
                 "wie viel Benzin [habe ich|hab ich] [noch]", "(Spritverbrauch|Verbrauch)", "wie ist der Spritstand",
                 "(Fuel level|Fjuhl Level)", "(komme|komm) ich [mit dem Sprit] bis ins Ziel"],
        "gap:ahead": ["wie weit ist (der vor mir|das Auto vor mir) [weg]", "Abstand zum Auto vor mir", "(Vordermann|wer ist vorne)",
                      "wie groß ist der Abstand [nach] vorne", "(Gap to the car ahead|Gäp tu se kar ehed)"],
        "gap:behind": ["wie weit ist (der hinter mir|das Auto hinter mir) [weg]", "Abstand zum Auto hinter mir", "Hintermann",
                       "wie groß ist der Abstand [nach] hinten", "wer sitzt mir im Nacken"],
        "gap:leader": ["(Abstand|Gap) zum Ersten", "wie weit ist die Spitze [weg]", "wer führt"],
        "traffic": ["(kommt|ist) da (Verkehr|jemand)", "(Überrundung|Überrunder)", "wer kommt von vorne", "Klassen"],
        "time_left": ["wie viel Zeit (bleibt|haben wir) [noch]", "wie lange [noch] bis [zum] Ende", "wann ist (Schluss|das Rennen vorbei)",
                      "wie viele Minuten [noch]", "(Restlaufzeit|Zeit) noch", "(Time remaining|Taim rimeining)"],
        "weather": ["wie ist das Wetter", "wird es nass", "(Lufttemperatur|Asphalttemperatur|Streckentemperatur)",
                    "ist die Strecke nass", "(Rain|Rein)"],
        "friend": ["wo ist mein Mate", "wie läuft es bei meinem (Kumpel|Teamkollegen)", "(Teammate|Tiemmeit)"],
        "tyres": ["(wie|was) sagen die Reifen", "(Reifenstatus|Reifenzustand|Reifenverschleiß|Verschleiß|Abnutzung)",
                  "wie lange halten die Reifen", "(wie heiß|wie kalt) sind die Reifen", "(Tyre wear|Teier wär)"],
        "brakes": ["(Bremsentemperaturen|Bremstemperaturen)", "(sind|werden) die Bremsen (zu heiß|heiß)",
                   "wie sind die Bremsen"],
        "catch:ahead": ["(kann|schaffe|schaff) ich (den|das Auto) vor mir [noch] (einholen|kriegen)",
                        "(komme|komm) ich [noch] an ihn ran", "(schaffe|schaff) ich das [noch]", "geht da noch was [nach vorne]"],
        "catch:behind": ["(kann|wird) der hinter mir [mich] [noch] (einholen|kriegen)", "(komme|komm) ich [noch] durch",
                         "bin ich sicher [nach hinten]", "muss ich mir Sorgen machen [nach hinten]"],
        "session": ["(Statistiken|Stats|Überblick)", "wie (läuft|lief) es [heute]", "wie war die Session [bisher]",
                    "wie konstant bin ich", "(Konstanz|Schnitt|Durchschnitt)"],
        "repeat": ["(sag das nochmal|bitte nochmal|was war das|Say again|Sei egen)"],
        "louder": ["(lauter bitte|ich höre dich nicht|ich hör dich nicht)"],
        "quieter": ["(leiser bitte|zu laut)"],
        "coach_off": ["(Fahrlehrer|Coach) Pause", "keine Ansagen [mehr]", "(Funkstille|Funk aus)"],
        "coach_on": ["(Fahrlehrer|Coach) weiter", "(Ansagen|Funk) an"],
        "help": ["was kann ich (fragen|sagen)", "(Befehle|Kommandos)", "was verstehst du"],
    },
    "en": {
        "last_lap": ["what was my (last lap|lap time)", "last lap time"],
        "best": ["(fastest lap|my best)"],
        "delta": ["(pace|what is my delta|how is my pace)", "am I on a (good|fast) lap"],
        "position": ["what place am I", "where am I in the race"],
        "fuel": ["do I have enough fuel", "fuel to the end", "(fuel usage|consumption)"],
        "gap:ahead": ["(gap|distance) to the car (ahead|in front)", "how far is the car (ahead|in front)"],
        "gap:behind": ["how far is the car behind", "who is on my tail"],
        "time_left": ["how much time (is left|do we have)", "(minutes left|how many minutes)"],
        "weather": ["(track temp|air temp|is it wet)"],
        "tyres": ["(tyre wear|tire wear|tyre status|how hot are the tyres)"],
        "brakes": ["(brake temperature|are the brakes hot)"],
        "catch:ahead": ["can I get him", "is there anything (left|more) up front"],
        "catch:behind": ["am I safe [behind]", "can he get me"],
        "repeat": ["(come again|what was that)"],
        "help": ["(commands|what can I ask)"],
    },
}


# Einzelwörter & weitere Begriffe – „Otto, Spitze“, „Otto, Verfolger“, „Otto, Druck“ …
for _cmd, _pats in {
    "gap:leader": ["(Spitze|Führender|der Führende|Leader)"],
    "catch:behind": ["(Verfolger|Defend|Difend|verteidigen)", "kann ich (die Position|den Platz) halten"],
    "catch:ahead": ["(Angriff|Attacke|Attack|Ättäck)", "kann ich angreifen"],
    "tyres": ["(Reifentemperaturen|Reifendrücke|Druck|Luftdruck|Temps|Tempis)"],
    "brakes": ["(Bremse|Bremsentemperatur bitte)"],
    "time_left": ["(Restzeit bitte|Minuten)"],
    "fuel": ["(Sprit bitte|Tankstand|Benzinstand)"],
    "weather": ["(Bedingungen|Wetterlage)"],
}.items():
    EXTRA_SPEC["de"].setdefault(_cmd, []).extend(_pats)


# Englische Funk-Sätze für die DEUTSCHE Erkennung – in deutscher Lautschrift, damit sie verstanden werden
for _cmd, _pats in {
    "fuel": ["(how much fuel|hau matsch fjuhl|hau mätsch fjuhl) [do we have|du wi häw|left|left]"],
    "gap:ahead": ["(what's the gap|wots se gäp|wats se gäp) [ahead|ehed]", "(car ahead|kar ehed)"],
    "gap:behind": ["(what's the gap behind|wots se gäp bihaind)", "(car behind|kar bihaind)"],
    "tyres": ["(tyre temps|teier temps|how are the tyres|hau ar se teiers|tyre check|teier tschek)"],
    "brakes": ["(brake temps|breik temps|how are the brakes|hau ar se breiks)"],
    "position": ["(what's my position|wots mai posischen|where am I|wär äm ai|wär äm ei)"],
    "time_left": ["(how long to go|hau long tu go|how many laps|hau männi läps)"],
    "catch:ahead": ["(can I catch him|kän ai kätsch him|can I get him|kän ai get him)"],
    "last_lap": ["(what was my lap|wot wos mai läp|lap time please|läp taim plies)"],
    "weather": ["(weather report|wedder riport|is it raining|is it reining)"],
    "repeat": ["(come again|kam egen)"],
}.items():
    EXTRA_SPEC["de"].setdefault(_cmd, []).extend(_pats)

for _cmd, _pats in {
    "compound": ["(Reifenwahl|Reifenempfehlung|Mischung|Reifenmischung|Compound|Kompaund|Reifenstrategie)",
                 "(welche|was für) Reifen soll ich (nehmen|fahren|wählen|draufmachen|aufziehen)",
                 "welche Reifen (empfiehlst du|sind besser|sind die besten)",
                 "soll ich [auf] [die] (Soft|Softs|Medium|Mediums|Hard|Hards|Regenreifen|Wets|Inter) (wechseln|nehmen|fahren|holen|draufmachen)",
                 "(Soft|Softs|Medium|Mediums|Hard|Hards) oder (Soft|Softs|Medium|Mediums|Hard|Hards)",
                 "(lohnt sich|lohnen sich) [die] (Soft|Softs|Medium|Mediums|Hard|Hards)",
                 "(lieber|besser) (Soft|Medium|Hard)", "brauche ich Regenreifen",
                 "(should I go|schud ai go) (soft|medium|hard|wets)", "(which tyres|witsch teiers)"],
    "pit": ["(Boxenstopp|Box|Stopp|Pit|Pitstop|Pit Stop|Box Box)",
            "(soll|muss) ich (rein|reinkommen|an die Box|in die Box|stoppen|reinfahren)",
            "wann muss ich (rein|an die Box|in die Box|stoppen)", "(reicht es|komme ich) ohne Stopp",
            "(should I pit|schud ai pit|do I need to pit)"],
    "gap:behind": ["(Gepp|Gapp|Gaap|Gähp) [nach] hinten", "hinten", "(wie|was) ist (der Abstand|das Gap) [nach] hinten",
                   "wie viel Vorsprung habe ich", "Vorsprung"],
    "gap:ahead": ["(Gepp|Gapp|Gaap|Gähp) [nach] vorne", "vorne", "(wie|was) ist (der Abstand|das Gap) [nach] vorne",
                  "wie viel fehlt [mir] nach vorne", "Rückstand"],
}.items():
    EXTRA_SPEC["de"].setdefault(_cmd, []).extend(_pats)
for _cmd, _pats in {
    "compound": ["(which tyres|which tires|tyre choice|what compound)", "should I go (soft|medium|hard|wets)",
                 "(soft|medium|hard) or (soft|medium|hard)"],
    "pit": ["(box|pit stop|should I pit|do I need to pit|when do I pit)"],
}.items():
    EXTRA_SPEC["en"].setdefault(_cmd, []).extend(_pats)

# Wörter, an denen Otto erkennt, dass auf Englisch gefragt wurde (auch in Lautschrift)
EN_WORDS = set("""gap gäp fuel fjuhl fjuel last läst lap läp laps läps best personal tyres tires teiers tyre teier temps
brakes breiks breik time taim left ahead ehed behind bihaind leader lieder traffic träffik weather wedder rain rein
catch kätsch catching kätsching will can kän is i ai he hi him me mi say sei again egen come kam attack ättäck defend difend
buddy teammate tiemmeit help hälp volume up down wear wär level remaining rimeining the se car kar to tu how hau much
matsch mätsch what's wots wats what wot was wos my mai do du we wi have häw are ar where wär am äm ei position posischen
long go many männi please plies report riport raining reining check tschek get summary sammeri repeat standing
lap time""".split())


def is_english(text: str) -> bool:
    """„Gap ahead“, „how much fuel“ -> Englisch; „Gap vorne“ -> Deutsch (gemischt = Deutsch)."""
    words = [w.strip(".,?!").lower() for w in (text or "").split()]
    words = [w for w in words if w and not w.isdigit()]
    return bool(words) and all(w in EN_WORDS for w in words)


def expand(pattern: str) -> list[str]:
    """„(Abstand|Gap) [nach] vorne“ -> alle Varianten („Abstand nach vorne“, „Abstand vorne“, „Gap …“)."""
    m = None
    depth = 0
    for i, ch in enumerate(pattern):              # erste Klammer auf oberster Ebene finden
        if ch in "([":
            if depth == 0:
                m = i
            depth += 1
        elif ch in ")]":
            depth -= 1
            if depth == 0 and m is not None:
                inner, opt = pattern[m + 1:i], pattern[m] == "["
                alts = _split_top(inner) + ([""] if opt else [])
                out = []
                for alt in alts:
                    for rest in expand(pattern[:m] + alt + pattern[i + 1:]):
                        out.append(rest)
                return list(dict.fromkeys(" ".join(x.split()) for x in out))
    return [" ".join(pattern.split())]


def _split_top(s: str) -> list[str]:
    parts, depth, cur = [], 0, ""
    for ch in s:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "|" and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    return parts + [cur]


def commands(lang: str) -> dict[str, str]:
    """Alle Sätze -> Kennung (ohne Weckwort)."""
    out = {}
    spec = COMMAND_SPEC.get(lang, COMMAND_SPEC["de"])
    extra = EXTRA_SPEC.get(lang if lang in COMMAND_SPEC else "de", {})
    for cmd in list(spec) + [c for c in extra if c not in spec]:
        pats = spec.get(cmd, []) + extra.get(cmd, [])
        for p in pats:
            for phrase in expand(p):
                out.setdefault(phrase, cmd)
    return out


COMMANDS = {lang: commands(lang) for lang in COMMAND_SPEC}
CULTURE = {"de": "de-DE", "en": "en-US"}


CLASS_NAMES = {"hyper": "Hypercar", "lmh": "Hypercar", "lmdh": "Hypercar", "lmp2": "LMP2", "lmp3": "LMP3",
               "lmgt3": "GT3", "gt3": "GT3", "gte": "GTE", "lmgte": "GTE"}


def class_name(cls: str) -> str:
    """„LMGT3“ -> „GT3“, „Hyper“ -> „Hypercar“ – so, wie man es sagt."""
    key = (cls or "").lower().replace(" ", "").replace("_", "")
    return CLASS_NAMES.get(key, cls or "Auto")


def T(key: str, _lang: str | None = None, **kw) -> str:
    t = TEXTS.get(key, {})
    s = t.get(_lang or getattr(_local, "lang", None) or LANG) or t.get("de") or key
    return s.format(**kw) if kw else s
