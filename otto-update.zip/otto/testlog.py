"""Test-Protokoll – NUR in der Entwickler-Version (python app.py, Daten im Projektordner).

Schreibt beim Fahren einmal pro Sekunde die Rohwerte von LMU mit, die sich nur im echten Spiel prüfen lassen
(Reifen Kern/Oberfläche, Sektor-Flaggen, gestrichene Runden, Verkehrsabstand, Schaden, Boxenstopps), dazu alles,
was Otto gesagt und gehört hat. Danach lässt sich genau nachvollziehen, ob eine Ansage gestimmt hat.

Datei: testlog/<Datum>_<Uhrzeit>.jsonl (eine JSON-Zeile pro Eintrag)."""
import json
import threading
import time

from .paths import CODE, DATA

ENABLED = DATA == CODE                 # installierte Otto.exe: Daten liegen woanders -> kein Protokoll


class TestLog:
    def __init__(self):
        self.enabled = ENABLED
        self._f = None
        self._lock = threading.Lock()

    def _file(self):
        if self._f is None:
            d = DATA / "testlog"
            d.mkdir(exist_ok=True)
            self._f = open(d / time.strftime("%Y-%m-%d_%H-%M-%S.jsonl"), "a", encoding="utf-8")
        return self._f

    def write(self, kind: str, **data):
        if not self.enabled:
            return
        try:
            line = json.dumps({"t": time.strftime("%H:%M:%S"), "k": kind, **data}, ensure_ascii=False, default=str)
            with self._lock:
                f = self._file()
                f.write(line + "\n")
                f.flush()
        except Exception:
            pass                         # Protokoll darf nie stören
