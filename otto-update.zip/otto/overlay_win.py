"""Windows-Fensterfunktionen fürs Overlay: echte Durchsichtigkeit, „durchklickbar“ (Klicks gehen ans Spiel),
nicht in Taskleiste/Alt-Tab, Position lesen. (pywebview kann unter Windows keine echte Transparenz.)"""
import ctypes
from ctypes import wintypes

user32 = ctypes.WinDLL("user32", use_last_error=True)
GWL_EXSTYLE = -20
WS_EX_LAYERED, WS_EX_TRANSPARENT, WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE, WS_EX_APPWINDOW = 0x80000, 0x20, 0x80, 0x08000000, 0x40000
LWA_ALPHA = 0x2
user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
user32.SetLayeredWindowAttributes.argtypes = [wintypes.HWND, wintypes.COLORREF, wintypes.BYTE, wintypes.DWORD]
user32.FindWindowW.restype = wintypes.HWND
user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]


def find(title: str = "Otto Overlay"):
    return user32.FindWindowW(None, title) or None


def style(hwnd, alpha: float, click_through: bool):
    """alpha 0.2..1 = Deckkraft des ganzen Fensters; click_through = Mausklicks gehen ans Spiel darunter."""
    if not hwnd:
        return False
    ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    ex |= WS_EX_LAYERED | WS_EX_TOOLWINDOW
    ex &= ~WS_EX_APPWINDOW
    if click_through:
        ex |= WS_EX_TRANSPARENT | WS_EX_NOACTIVATE
    else:
        ex &= ~(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE)
    user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex)
    user32.SetLayeredWindowAttributes(hwnd, 0, max(40, min(255, int(alpha * 255))), LWA_ALPHA)
    return True


def rect(hwnd):
    r = wintypes.RECT()
    if hwnd and user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return r.left, r.top, r.right - r.left, r.bottom - r.top
    return None


def dpi_scale(hwnd) -> float:
    """Windows-Skalierung des Bildschirms mit dem Fenster (1.0 = 100 %, 1.25 = 125 %)."""
    try:
        return max(1.0, user32.GetDpiForWindow(hwnd) / 96.0)
    except Exception:
        return 1.0


def on_screen(x: int, y: int) -> bool:
    """Liegt der Punkt auf irgendeinem Bildschirm? (z. B. wenn ein 2. Monitor fehlt)"""
    pt = wintypes.POINT(x + 20, y + 20)
    return bool(user32.MonitorFromPoint(pt, 0))   # 0 = MONITOR_DEFAULTTONULL
