"""Rundenanalyse: Runden auf ein gemeinsames Distanzraster legen, Zeitverlust (Delta),
Kurvenerkennung, Kurvenbericht mit Tipps und theoretische Bestzeit."""
import math
from . import tracknames
from .sessions import lap_info, load_laps, track_of

STEP_M = 4.0          # Rasterabstand in Metern
MIN_DROP_KMH = 12     # so viel muss die Geschwindigkeit fallen, damit es eine "Kurve" ist


# ---------------------------------------------------------------- Raster
def _path_length(d) -> float:
    xs, zs = d["x"], d["z"]
    return sum(math.hypot(xs[i] - xs[i - 1], zs[i] - zs[i - 1]) for i in range(1, len(xs)))


def _resample(d, track_len: float, extra=()) -> dict:
    extra = list(extra)
    """Runde auf feste Distanzpunkte (alle STEP_M Meter) umrechnen."""
    pos, n = d["lap_pos"], len(d["lap_pos"])
    k0 = next((i for i, p in enumerate(pos) if p < 0.5), 0)   # Hänger am Rundenanfang
    dist, keep, last = [], [], -1.0
    for i in range(k0, n):
        m = pos[i] * track_len
        if m > last:                     # nur vorwärts
            dist.append(m)
            keep.append(i)
            last = m
    keys = ["lap_time_ms", "speed_kmh", "throttle", "brake", "steering", "x", "z", "gear"] + extra
    out = {k: [] for k in keys}
    grid = [i * STEP_M for i in range(int(track_len / STEP_M))]
    j = 0
    for g in grid:
        while j < len(dist) - 2 and dist[j + 1] < g:
            j += 1
        a, b = keep[j], keep[j + 1]
        span = dist[j + 1] - dist[j] or 1
        f = max(0.0, min(1.0, (g - dist[j]) / span))
        for k in keys:
            out[k].append(d[k][a] + f * (d[k][b] - d[k][a]))
    out["dist"] = grid
    out["time"] = out.pop("lap_time_ms")
    # Zeitbasis bei 0 starten
    t0 = out["time"][0]
    out["time"] = [t - t0 for t in out["time"]]
    return out


def _smooth(v, r=3):
    n = len(v)
    return [sum(v[max(0, i - r):min(n, i + r + 1)]) / (min(n, i + r + 1) - max(0, i - r)) for i in range(n)]


# ---------------------------------------------------------------- Kurven
def find_corners(ref: dict) -> list[dict]:
    """Kurven = deutliche Geschwindigkeitsminima. Pro Kurve: Bremspunkt, Scheitel, Gas-Punkt."""
    v = _smooth(ref["speed_kmh"], 4)
    n = len(v)
    win = int(70 / STEP_M)       # lokales Minimum in ±70 m
    reach = int(350 / STEP_M)    # Abfall/Anstieg innerhalb von 350 m davor/danach
    apexes = []
    for i in range(1, n - 1):
        if v[i] != min(v[max(0, i - win):min(n, i + win)]):
            continue
        before = max(v[max(0, i - reach):i + 1])
        after = max(v[i:min(n, i + reach)])
        if min(before, after) - v[i] >= MIN_DROP_KMH:
            if not apexes or i - apexes[-1] > win:
                apexes.append(i)
    # Zusätzlich: Kurven über die Krümmung finden – auch schnelle Kurven, in denen kaum
    # Speed abgebaut wird (Esses, Eau Rouge, Porsche-Kurven)
    for i in _curvature_peaks(ref):
        if all(abs(i - a) > win for a in apexes):
            apexes.append(i)
    apexes.sort()
    corners = []
    for num, a in enumerate(apexes, 1):
        corners.append({"name": f"T{num}", "apex": a})
    # Abschnittsgrenzen: Mitte zwischen zwei Scheiteln
    for c, nxt in zip(corners, corners[1:] + [None]):
        c["end"] = (c["apex"] + nxt["apex"]) // 2 if nxt else n - 1
    for c, prev in zip(corners, [None] + corners[:-1]):
        c["start"] = prev["end"] if prev else 0
    return corners


MAX_RADIUS_M = 220      # engere Bögen als das zählen als Kurve
MIN_TURN_DEG = 25       # ... und die Richtung muss sich insgesamt spürbar ändern


def _curvature_peaks(ref: dict) -> list[int]:
    """Scheitelpunkte aus der Streckenform: Richtungsänderung pro Meter (aus x/z der Runde)."""
    xs, zs, n = ref["x"], ref["z"], len(ref["x"])
    if n < 20:
        return []
    h = int(12 / STEP_M) or 1                    # Richtung über ±12 m bestimmen (glättet Rauschen)
    head = [math.atan2(zs[min(n - 1, i + h)] - zs[max(0, i - h)], xs[min(n - 1, i + h)] - xs[max(0, i - h)])
            for i in range(n)]
    k = [0.0] * n
    for i in range(1, n - 1):
        d = head[i + 1] - head[i - 1]
        d = (d + math.pi) % (2 * math.pi) - math.pi
        k[i] = d / (2 * STEP_M)                  # rad pro Meter = 1 / Radius
    k = _smooth(_smooth(k, 3), 3)
    win, span = int(60 / STEP_M), int(80 / STEP_M)
    peaks = []
    for i in range(win, n - win):
        a = abs(k[i])
        if a < 1 / MAX_RADIUS_M or a != max(abs(x) for x in k[i - win:i + win + 1]):
            continue
        turn = abs(sum(k[max(0, i - span):min(n, i + span)])) * STEP_M     # Gesamtwinkel der Kurve
        if math.degrees(turn) >= MIN_TURN_DEG:
            peaks.append(i)
    return peaks


def _brake_point(lap, start, apex):
    """Erster Punkt vor dem Scheitel, an dem deutlich gebremst wird (oder Gas weg)."""
    for i in range(start, apex + 1):
        if lap["brake"][i] > 0.1:
            return i, "brake"
    for i in range(start, apex + 1):
        if lap["throttle"][i] < 0.5:
            return i, "lift"
    return None, None


def _throttle_point(lap, apex, end):
    for i in range(apex, end + 1):
        if lap["throttle"][i] > 0.9:
            return i
    return None


def _corner_metrics(lap, c):
    s, a, e = c["start"], c["apex"], c["end"]
    lo, hi = max(s, a - int(60 / STEP_M)), min(e, a + int(60 / STEP_M))
    seg = range(lo, hi + 1)
    i_min = min(seg, key=lambda i: lap["speed_kmh"][i])
    bp, kind = _brake_point(lap, s, i_min)
    tp = _throttle_point(lap, i_min, e)
    exit_i = min(e, i_min + int(120 / STEP_M))
    return {
        "brake_m": bp * STEP_M if bp is not None else None,
        "brake_kind": kind,
        "max_brake": max(lap["brake"][s:i_min + 1], default=0),
        "min_speed": lap["speed_kmh"][i_min],
        "apex_m": i_min * STEP_M,
        "throttle_m": tp * STEP_M if tp is not None else None,
        "exit_speed": lap["speed_kmh"][exit_i],
        "time": lap["time"][e] - lap["time"][s],
    }


def _tips(m, r) -> list[str]:
    """Regeln: was ist der wahrscheinlichste Grund für den Zeitverlust?"""
    tips = []
    if m["brake_m"] is not None and r["brake_m"] is not None:
        diff = r["brake_m"] - m["brake_m"]          # >0: du bremst früher
        if diff > 8:
            tips.append(f"{diff:.0f} m später bremsen")
        elif diff < -8 and m["min_speed"] < r["min_speed"] - 3:
            tips.append(f"{-diff:.0f} m früher bremsen – du kommst zu schnell rein und verlierst am Scheitel")
    dv = m["min_speed"] - r["min_speed"]
    if dv < -3:
        tips.append(f"{-dv:.0f} km/h mehr Speed durch die Kurve mitnehmen")
    if m["throttle_m"] is not None and r["throttle_m"] is not None:
        dt = m["throttle_m"] - r["throttle_m"]
        if dt > 10:
            tips.append(f"{dt:.0f} m früher voll aufs Gas")
    de = m["exit_speed"] - r["exit_speed"]
    if de < -4 and not any("Gas" in t for t in tips):
        tips.append(f"Besserer Ausgang: {-de:.0f} km/h langsamer raus")
    return tips


# ---------------------------------------------------------------- Einfach-Modus
def _advice(m, r) -> dict:
    """Die EINE wichtigste Sache pro Kurve – in Alltagssprache."""
    bp = (r["brake_m"] - m["brake_m"]) if m["brake_m"] is not None and r["brake_m"] is not None else 0
    dv = m["min_speed"] - r["min_speed"]
    tp = (m["throttle_m"] - r["throttle_m"]) if m["throttle_m"] is not None and r["throttle_m"] is not None else 0
    de = m["exit_speed"] - r["exit_speed"]
    if bp > 8 and dv > -8:
        return {"kind": "brake_later", "title": "Später bremsen",
                "text": f"Du bremst hier ca. {bp:.0f} m zu früh. In deiner Referenzrunde bist du später "
                        f"auf die Bremse und trotzdem sauber um die Kurve gekommen."}
    if bp < -8 and dv < -3:
        return {"kind": "brake_earlier", "title": "Etwas früher bremsen",
                "text": f"Du bremst {-bp:.0f} m später, kommst dadurch aber zu schnell an und musst in der "
                        f"Kurve mehr abbauen – am Ende bist du {-dv:.0f} km/h langsamer. Früher und ruhiger bremsen."}
    if dv < -4:
        return {"kind": "carry_speed", "title": "Mehr Schwung mitnehmen",
                "text": f"Du bist in der Kurve {-dv:.0f} km/h langsamer ({m['min_speed']:.0f} statt "
                        f"{r['min_speed']:.0f} km/h). Weniger stark oder kürzer bremsen und das Auto rollen lassen."}
    if tp > 10:
        return {"kind": "throttle_earlier", "title": "Früher aufs Gas",
                "text": f"Nach der Kurve wartest du zu lange: In der Referenzrunde warst du {tp:.0f} m früher "
                        f"voll auf dem Gas. Sobald du das Lenkrad öffnest, Gas aufbauen."}
    if de < -4:
        return {"kind": "exit", "title": "Besser rausbeschleunigen",
                "text": f"Du kommst {-de:.0f} km/h langsamer aus der Kurve. Das kostet dich auf der ganzen "
                        f"folgenden Geraden Zeit – lieber etwas langsamer rein und dafür früh voll raus."}
    return {"kind": "line", "title": "Linie prüfen",
            "text": "Bremsen, Speed und Gas sind ähnlich wie in der Referenz – der Zeitverlust kommt wahrscheinlich "
                    "von der Linie. Schau dir die Kurve im Replay an."}


def _offtrack_advice(c) -> dict:
    m, r = c["lap"], c["ref"]
    bp = (r["brake_m"] - m["brake_m"]) if m["brake_m"] is not None and r["brake_m"] is not None else 0
    why = (f" Du hast {-bp:.0f} m später gebremst als in der Referenz – wahrscheinlich warst du zu schnell."
           if bp < -5 else " Schau dir die Stelle in der 3D-Ansicht an.")
    return {"kind": "offtrack", "title": "Neben der Strecke",
            "text": f"Hier warst du {c['off_m']:.1f} m über den Streckenrand hinaus. Das kostet Zeit und "
                    f"kann eine Strafe geben.{why}"}


def _style_hints(A, corners) -> list[dict]:
    """Fahrstil über die ganze Runde – typische Einsteiger-Muster."""
    hints = []
    peaks = [max(A["brake"][c["start"]:c["apex"] + 1], default=0) for c in corners]
    peaks = [p for p in peaks if p > 0.1]
    if len(peaks) >= 3 and sorted(peaks)[len(peaks) // 2] < 0.7:
        hints.append({"title": "Fester bremsen",
                      "text": "Du bremst meist nur mit "
                              f"{sorted(peaks)[len(peaks) // 2] * 100:.0f} % Druck. Rennautos verzögern am besten "
                              "mit kräftigem Anfangsdruck, den du dann zur Kurve hin langsam löst."})
    thr = A["throttle"]
    partial = sum(1 for t in thr if 0.15 < t < 0.85) / max(1, len(thr))
    if partial > 0.25:
        hints.append({"title": "Klarer mit dem Gas",
                      "text": f"Auf {partial * 100:.0f} % der Runde fährst du mit halbem Gas. Oft ist es schneller, "
                              "kurz zu warten und dann entschlossen voll aufs Gas zu gehen."})
    return hints


def _coach(report, A, corners, lap_ms, ref_ms, theo_ms, best_ms) -> dict:
    bad = sorted([c for c in report if c["loss_ms"] > 50], key=lambda c: -c["loss_ms"])[:3]
    good = sorted([c for c in report if c["loss_ms"] < -50], key=lambda c: c["loss_ms"])[:3]
    return {
        "gap_ms": lap_ms - ref_ms,
        "potential_ms": (best_ms - theo_ms) if theo_ms else None,
        "top": [{"name": c["name"], "label": c["label"], "nick": c["nick"], "loss_ms": c["loss_ms"],
                 "start": c["start"], "end": c["end"],
                 **(_offtrack_advice(c) if c.get("off_m") else _advice(c["lap"], c["ref"]))} for c in bad],
        "good": [{"name": c["name"], "label": c["label"], "gain_ms": -c["loss_ms"]} for c in good],
        "style": _style_hints(A, corners),
    }


def corner_labels(track: str, grid: dict, corners: list[dict], lap_len: float) -> list[dict]:
    """Offizielle Namen für alle erkannten Kurven (eigene/handgeprüfte Namen, sonst Streckendatenbank)."""
    def direction(c):
        s = grid["steering"][c["apex"]]
        return -1 if s < -0.05 else 1 if s > 0.05 else 0          # LMU: negativ = links
    apexes = [(c["apex"] * STEP_M, direction(c)) for c in corners]
    return tracknames.labels(track, apexes, [c["name"] for c in corners], lap_len)


# ---------------------------------------------------------------- API
def analyse(file: str, lap_no: int, ref_no: int | None = None) -> dict:
    laps = load_laps(file)
    track = track_of(file)
    all_full = [l for l in laps if l["full"]]
    if not all_full:
        return {"error": "Keine vollständige Runde in dieser Session."}
    full = [l for l in all_full if l["valid"]] or all_full   # Runden mit Ausritt zählen nicht
    track_len = sorted(_path_length(l["data"]) for l in all_full)[len(all_full) // 2]
    best = min(full, key=lambda l: l["time_ms"])
    lap = next((l for l in laps if l["lap"] == lap_no), best)
    ref = next((l for l in all_full if l["lap"] == ref_no), best)

    A = _resample(lap["data"], track_len)
    B = _resample(ref["data"], track_len)
    n = min(len(A["dist"]), len(B["dist"]))
    for d in (A, B):
        for k in d:
            d[k] = d[k][:n]
    delta = [A["time"][i] - B["time"][i] for i in range(n)]

    corners = [c for c in find_corners(B) if c["end"] < n]
    names = corner_labels(track, B, corners, track_len)
    report = []
    for c, nm in zip(corners, names):
        ma, mb = _corner_metrics(A, c), _corner_metrics(B, c)
        s_m, e_m = c["start"] * STEP_M, c["end"] * STEP_M
        off = max((o["max_m"] for o in lap["offs"] if s_m <= o["lap_pos"] * track_len <= e_m), default=0)
        tips = _tips(ma, mb) if ma["time"] - mb["time"] > 20 else []
        if off:
            tips.insert(0, f"Neben der Strecke ({off:.1f} m über den Rand)")
        report.append({
            "name": c["name"], **nm, "start": s_m, "end": e_m,
            "apex": c["apex"] * STEP_M, "x": B["x"][c["apex"]], "z": B["z"][c["apex"]],
            "lap": ma, "ref": mb, "loss_ms": ma["time"] - mb["time"], "off_m": off, "tips": tips,
        })

    # theoretische Bestzeit: bester Abschnitt aus allen vollen Runden
    seg_best = []
    theo = None
    if corners:
        all_rs = [_resample(l["data"], track_len) for l in full]
        bounds = [0] + [c["end"] for c in corners if c["end"] < n]
        bounds[-1] = n - 1
        theo = 0.0
        for s, e in zip(bounds, bounds[1:]):
            times = [(r["time"][min(e, len(r["time"]) - 1)] - r["time"][s], l["lap"]) for r, l in zip(all_rs, full)]
            t, who = min(times)
            seg_best.append({"from": s * STEP_M, "to": e * STEP_M, "time_ms": t, "lap": who})
            theo += t
        # Rest bis Start/Ziel aus der Bestrunde
        best_rs = all_rs[full.index(best)]
        theo += best["time_ms"] - best_rs["time"][min(n, len(best_rs["time"])) - 1]

    def pack(d):  # für die Oberfläche etwas ausdünnen (alle 8 m)
        return {k: [round(x, 3) for x in v[::2]] for k, v in d.items()}

    return {
        "track_len": round(track_len),
        "track": track,
        "lap": lap_info(lap),
        "ref": {"lap": ref["lap"], "time_ms": ref["time_ms"]},
        "best_ms": best["time_ms"],
        "theoretical_ms": round(theo) if theo else None,
        "A": pack(A), "B": pack(B), "delta": [round(x) for x in delta[::2]],
        "corners": report, "segments": seg_best,
        "coach": _coach(report, A, [c for c in corners if c["end"] < n], lap["time_ms"], ref["time_ms"],
                        round(theo) if theo else None, best["time_ms"]),
        "laps": [lap_info(l) for l in laps],
    }
