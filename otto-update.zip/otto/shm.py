"""Lesen von Windows Shared Memory (Named File Mappings) per ctypes."""
import ctypes
from ctypes import wintypes

FILE_MAP_READ = 0x0004
_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_k32.OpenFileMappingW.restype = wintypes.HANDLE
_k32.OpenFileMappingW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
_k32.MapViewOfFile.restype = ctypes.c_void_p
_k32.MapViewOfFile.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
_k32.UnmapViewOfFile.argtypes = [ctypes.c_void_p]
_k32.CloseHandle.argtypes = [wintypes.HANDLE]


class _MBI(ctypes.Structure):
    _fields_ = [("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wintypes.DWORD), ("PartitionId", wintypes.WORD),
                ("RegionSize", ctypes.c_size_t), ("State", wintypes.DWORD),
                ("Protect", wintypes.DWORD), ("Type", wintypes.DWORD)]


_k32.VirtualQuery.argtypes = [ctypes.c_void_p, ctypes.POINTER(_MBI), ctypes.c_size_t]
_k32.VirtualQuery.restype = ctypes.c_size_t


class SharedMemory:
    """Öffnet ein existierendes Mapping nur lesend. Legt nie selbst eines an."""

    def __init__(self, name: str, struct_type=None):
        self.name = name
        self.struct_type = struct_type
        self.size = 0
        self._handle = None
        self._view = None

    def open(self) -> bool:
        if self._view:
            return True
        h = _k32.OpenFileMappingW(FILE_MAP_READ, False, self.name)
        if not h:
            return False
        view = _k32.MapViewOfFile(h, FILE_MAP_READ, 0, 0, 0)  # 0 = ganzes Mapping
        if not view:
            _k32.CloseHandle(h)
            return False
        mbi = _MBI()
        _k32.VirtualQuery(view, ctypes.byref(mbi), ctypes.sizeof(mbi))
        self._handle, self._view, self.size = h, view, mbi.RegionSize
        return True

    def read(self):
        """Kopie des Anfangs als struct_type (oder None)."""
        if not self.open():
            return None
        return self.struct_type.from_buffer_copy(
            ctypes.string_at(self._view, ctypes.sizeof(self.struct_type)))

    def read_bytes(self) -> bytes | None:
        """Kopie des gesamten Mappings."""
        if not self.open():
            return None
        return ctypes.string_at(self._view, self.size)

    def read_at(self, offset: int, size: int) -> bytes | None:
        """Kopie eines Ausschnitts (spart bei großen Mappings das Kopieren von allem)."""
        if not self.open() or offset < 0 or offset + size > self.size:
            return None
        return ctypes.string_at(self._view + offset, size)

    def read_consistent(self, size: int, tries: int = 4) -> bytes | None:
        """rFactor-2-Mappings beginnen mit zwei Zählern (Schreiben begonnen / fertig). Nur eine Kopie,
        bei der beide vorher UND nachher gleich waren, ist vollständig – sonst kurz erneut versuchen."""
        size = min(size, self.size) if self.open() else 0
        for _ in range(tries):
            h1 = self.read_at(0, 8)
            if h1 is None:
                return None
            if h1[:4] != h1[4:]:                 # LMU schreibt gerade
                continue
            data = self.read_at(0, size)
            if data is not None and self.read_at(0, 8) == h1:
                return data
        return None

    def close(self):
        if self._view:
            _k32.UnmapViewOfFile(self._view)
            _k32.CloseHandle(self._handle)
        self._handle = self._view = None
