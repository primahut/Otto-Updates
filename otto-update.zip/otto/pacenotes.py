"""Fahrlehrer-Modus: aus einer Referenzrunde eine Liste von Kommandos machen („Rechts, außen bleiben“,
Countdown-Piep, „Bremsen“, „Lupfen“, „Gas“) und sie während der Fahrt im richtigen Moment abspielen.

Es wird NICHT erst die Kurve ausgewertet – die Kommandos kommen vorher, wie bei einem Beifahrer.
Erkennung direkt aus Gas/Bremse der Referenz, deshalb auch für Kurven ohne Bremsen (Eau Rouge: „Lupfen“)."""
import bisect
import math
import time
from .analysis import _path_length

BRAKE_ON = 0.15        # ab hier zählt es als Bremsen
LIFT_FROM, LIFT_TO = 0.9, 0.55
GAS_ON = 0.35          # „Gas“ = ab hier wird Gas AUFGEBAUT (nicht erst Vollgas – das kam zu spät)
GAS_FULL = 0.8         # ... und es muss danach auch wirklich bis fast Vollgas gehen
PREP_S = 4.5           # so viele Sekunden vor dem Bremspunkt: „Rechts, außen bleiben“
BEEPS_S = (3.0, 2.0, 1.0)
LATENCY_S = 0.18       # Audio-Verzögerung ausgleichen


def _trimmed(lap: dict) -> dict:
    """Hänger am Rundenanfang (Position noch ~100 %) abschneiden, nur vorwärts."""
    pos = lap["lap_pos"]
    k0 = next((i for i, p in enumerate(pos) if 0 <= p < 0.5), 0)
    keep, last = [], -1.0
    for i in range(k0, len(pos)):
        if pos[i] > last:
            keep.append(i)
            last = pos[i]
    return {k: [lap[k][i] for i in keep] for k in lap if isinstance(lap[k], list) and len(lap[k]) == len(pos)}


def build_events(lap: dict) -> dict:
    """lap: Spalten-Dict einer Referenzrunde (lap_pos, speed_kmh, throttle, brake, steering, x, z,
    optional path_lateral, track_edge). Ergebnis: {"L": Länge, "events": [...]} sortiert nach Position."""
    d = _trimmed(lap)
    n = len(d["lap_pos"])
    if n < 50:
        return {"L": 0, "events": []}
    L = _path_length(d)
    pos, thr, brk, steer, spd = d["lap_pos"], d["throttle"], d["brake"], d["steering"], d["speed_kmh"]
    lat = d.get("path_lateral") or [0.0] * n
    edge = d.get("track_edge") or [0.0] * n
    ahead = lambda i, m: next((k for k in range(i, n) if (pos[k] - pos[i]) * L >= m), n - 1)   # Index m Meter weiter

    def gas_point(k: int) -> int:
        """Erster Punkt ab k, an dem Gas aufgebaut wird und innerhalb ~2 s fast Vollgas erreicht."""
        while k < n - 1 and not (thr[k] >= GAS_ON and brk[k] < 0.05 and max(thr[k:k + 60]) >= GAS_FULL):
            k += 1
        return k
    events = []
    i, last_kind_i = 1, -999
    while i < n:
        # ---- Bremsen
        if brk[i] >= BRAKE_ON and brk[i - 1] < BRAKE_ON:
            j = ahead(i, 80)
            peak = max(brk[i:j + 1])
            apex = min(range(i, ahead(i, 250) + 1), key=lambda k: spd[k])
            direction = "left" if steer[apex] < 0 else "right"
            # Linie: Scheitel liegt innen -> Vorzeichen von path_lateral am Scheitel = Innenseite
            outside = False
            if abs(edge[i]) > 2 and abs(lat[apex]) > 1:
                inside_sign = math.copysign(1, lat[apex])
                outside = lat[i] * inside_sign < 0 and abs(lat[i]) / abs(edge[i]) > 0.3
            word = "brake_hard" if peak > 0.75 else ("brake" if peak > 0.35 else "brake_light")
            events.append({"pos": pos[i], "kind": "brake", "say": word, "speed": spd[i], "peak": round(peak, 2),
                           "prep": f"{direction}_out" if outside else direction, "drop": spd[i] - spd[apex]})
            last_kind_i = i
            # bis zum Gas-Punkt springen
            k = gas_point(i)
            if k < n - 1:
                events.append({"pos": pos[k], "kind": "gas", "say": "gas", "speed": spd[k]})
            i = k + 1
            continue
        # ---- Lupfen (Gas weg ohne Bremse, z. B. Eau Rouge) / Rollen lassen
        if thr[i - 1] >= LIFT_FROM and thr[i] < LIFT_TO:
            j = ahead(i, 50)
            if max(brk[i:j + 1]) < BRAKE_ON:          # keine Bremse direkt danach
                low = min(thr[i:j + 1])
                word = "coast" if low < 0.1 else "lift"
                events.append({"pos": pos[i], "kind": "lift", "say": word, "speed": spd[i],
                               "prep": "left" if steer[j] < 0 else "right"})
                k = i
                while k < n - 1 and thr[k] >= GAS_ON and brk[k] < BRAKE_ON:   # erst bis zum Tiefpunkt
                    k += 1
                k = gas_point(k)
                if k < n - 1 and max(brk[i:k + 1]) < BRAKE_ON:
                    events.append({"pos": pos[k], "kind": "gas", "say": "gas", "speed": spd[k]})
                i = k + 1
                continue
        i += 1
    # Gas-Kommandos, die direkt (< 1,5 s) vor dem nächsten Bremspunkt kämen, weglassen – nur Lärm
    clean = []
    for e, nxt in zip(events, events[1:] + [None]):
        # zweimal „Bremsen“ kurz hintereinander (Bremse kurz gelöst) -> nur das erste sagen
        if e["kind"] == "brake" and clean and clean[-1]["kind"] == "brake" and (e["pos"] - clean[-1]["pos"]) * L < 60:
            continue
        if e["kind"] == "gas" and nxt and (nxt["pos"] - e["pos"]) * L / max(1, e["speed"] / 3.6) < 1.5:
            continue
        clean.append(e)
    # Vorankündigung + Countdown nur, wenn davor genug Ruhe ist (sonst redet Otto in die vorige Kurve)
    prev = None
    for e in clean:
        gap_s = ((e["pos"] - prev["pos"]) * L / max(1, e["speed"] / 3.6)) if prev else 99
        e["prep_ok"] = gap_s > PREP_S + 0.8
        e["beeps_ok"] = gap_s > BEEPS_S[0] + 0.5
        prev = e
    return {"L": L, "events": clean}


class PaceNotes:
    """Spielt die Kommandos synchron zur aktuellen Position ab."""

    def __init__(self, bank):
        self.bank = bank            # SoundBank: play(text) / beep(n)
        self.enabled = False
        self.L = 0.0
        self.events = []
        self.source = ""            # z. B. „Bestzeit 1:59.6 (05.10.)“
        self._fired, self._fired_next = set(), set()
        self._last_pos = 0.0
        self._ref = None
        self._T = 0.0
        self._v_smooth = None
        self.next = None
        self.next_sound_s = 99.0
        self.hold_until = 0.0       # Funk-Pause: bis dahin keine Kommandos (du sprichst / Otto antwortet)

    def hold(self, seconds: float):
        """Kommandos für eine Weile aussetzen (verlängert nur, verkürzt nie)."""
        self.hold_until = max(self.hold_until, time.time() + seconds)

    def release(self, after: float = 0.0):
        """Funk-Pause in `after` Sekunden beenden (z. B. Antwort fertig + kurze Ruhe)."""
        self.hold_until = time.time() + after

    @property
    def held(self) -> bool:
        return time.time() < self.hold_until

    def quiet_window(self) -> float:
        """Wie viele Sekunden ist garantiert Ruhe vor dem nächsten Fahrlehrer-Kommando?"""
        if self.held:
            return 99.0                                   # Funk-Pause: Antworten sofort, keine Kommandos
        return self.next_sound_s if self.enabled and self.events else 99.0

    def set_reference(self, lap: dict, source: str):
        r = build_events(lap)
        if not r["events"]:
            return
        d = _trimmed(lap)
        t0 = d["lap_time_ms"][0]
        # Zeitachse der Vorlage: wann war die Vorlage wo? (für ruhige, genaue Countdowns)
        self._ref = {"pos": d["lap_pos"], "t": [(x - t0) / 1000 for x in d["lap_time_ms"]],
                     "v": d["speed_kmh"], "brake": d["brake"], "throttle": d["throttle"]}
        self._T = self._ref["t"][-1]
        for e in r["events"]:
            e["t_ref"] = self._ref_at("t", e["pos"])
        self.L, self.events, self.source = r["L"], r["events"], source
        self._fired, self._fired_next = set(), set()
        self._v_smooth = None

    def _ref_at(self, key: str, lap_pos: float) -> float:
        pos = self._ref["pos"]
        i = bisect.bisect_left(pos, lap_pos)
        if i <= 0:
            return self._ref[key][0]
        if i >= len(pos):
            return self._ref[key][-1]
        f = (lap_pos - pos[i - 1]) / ((pos[i] - pos[i - 1]) or 1)
        a, b = self._ref[key][i - 1], self._ref[key][i]
        return a + f * (b - a)

    def ref_pedals(self, lap_pos: float) -> dict | None:
        """Bremse/Gas der Vorlage an dieser Stelle (0..1) – für die Markierung im Overlay."""
        if not getattr(self, "_ref", None) or lap_pos < 0:
            return None
        return {"brake": round(self._ref_at("brake", lap_pos), 3), "throttle": round(self._ref_at("throttle", lap_pos), 3)}

    def ref_speed(self, lap_pos: float) -> float | None:
        """Tempo der Vorlage an dieser Stelle (km/h) – None ohne Vorlage."""
        if not self._ref or lap_pos < 0:
            return None
        return self._ref_at("v", lap_pos)

    def next_corner(self, lap_pos: float, speed_kmh: float):
        """Nächste richtige Kurve (Bremspunkt mit viel Tempoabbau): (Kennung, Sekunden bis dahin, "left"/"right").
        Für den Spotter – funktioniert auch, wenn der Fahrlehrer aus ist (braucht nur die Vorlage)."""
        if not self.events or not self._ref or lap_pos < 0:
            return None
        now_ref = self._ref_at("t", lap_pos)
        ratio = max(0.6, min(1.8, max(20.0, self._ref_at("v", lap_pos)) / max(20.0, speed_kmh)))
        best = None
        for k, e in enumerate(self.events):
            if e["kind"] != "brake" or e.get("drop", 0) < 25:
                continue
            dt = e["t_ref"] - now_ref
            if dt < -1.0 and lap_pos > 0.8:
                dt += self._T
            dt *= ratio
            if dt > -0.3 and (best is None or dt < best[1]):
                best = (k, dt, e["prep"].split("_")[0])
        return best

    def new_lap(self):
        """Neue Runde: was schon „für die nächste Runde“ angesagt wurde (über Start/Ziel hinweg), bleibt erledigt."""
        self._fired, self._fired_next = self._fired_next, set()

    def on_sample(self, lap_pos: float, speed_kmh: float):
        if not self.enabled or not self.events or lap_pos < 0 or speed_kmh < 20:
            self.next = None
            self.next_sound_s = 99.0
            return
        if lap_pos + 0.5 < self._last_pos:      # neue Runde
            self.new_lap()
        self._last_pos = lap_pos
        # Countdown aus der Zeitachse der Vorlage statt „Abstand ÷ aktuelles Tempo“: springt nicht beim
        # Bremsen/Beschleunigen. Bist du langsamer als die Vorlage, dauert es entsprechend länger.
        ref_v = max(20.0, self._ref_at("v", lap_pos))
        self._v_smooth = speed_kmh if self._v_smooth is None else self._v_smooth + 0.15 * (speed_kmh - self._v_smooth)
        ratio = max(0.6, min(1.8, ref_v / max(20.0, self._v_smooth)))
        now_ref = self._ref_at("t", lap_pos)
        self.next = None                                   # nächstes Kommando fürs Overlay
        self.next_sound_s = 99.0                           # wann Otto als Nächstes etwas einspielt
        for k, e in enumerate(self.events):
            dt_ref, wrap = e["t_ref"] - now_ref, False
            if dt_ref < -1.0 and lap_pos > 0.8:            # Kommando gehört schon zur nächsten Runde
                dt_ref, wrap = dt_ref + self._T, True
            dt = dt_ref * ratio
            if self.next is None and -0.6 <= dt <= 6:
                self.next = {"code": e["say"], "kind": e["kind"], "dt": round(dt, 2), "target": e.get("peak")}
            big = e["kind"] == "brake" and e["drop"] > 25
            for t in ([dt - PREP_S] if big and e.get("prep_ok") else []) + ([dt - BEEPS_S[0]] if big and e.get("beeps_ok") else []) + [dt]:
                if t > -0.2:
                    self.next_sound_s = min(self.next_sound_s, t)
            if dt < -0.5 or dt > PREP_S + 0.5:
                continue
            fired = self._fired_next if wrap else self._fired
            if e["kind"] in ("brake", "lift"):
                if e.get("prep") and big and e["prep_ok"]:
                    self._once(fired, (k, "prep"), dt <= PREP_S, lambda e=e: self.bank.play(e["prep"]))
                if big and e["beeps_ok"]:
                    for b in BEEPS_S:
                        self._once(fired, (k, b), dt <= b + LATENCY_S and dt > 0.6, lambda b=b: self.bank.beep(b))
            self._once(fired, (k, "go"), dt <= LATENCY_S, lambda e=e: self.bank.play(e["say"]))

    def _once(self, fired: set, key, cond: bool, fn):
        if cond and key not in fired:
            fired.add(key)
            if not self.held:          # während der Funk-Pause fällt das Kommando aus (statt zu spät zu kommen)
                fn()
