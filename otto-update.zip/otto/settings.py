"""Kleine Einstellungsdatei (settings.json im Projektordner)."""
import json
from pathlib import Path

from .paths import SETTINGS as PATH
DEFAULTS = {
    "auto_record": False,
    "auto_cleanup": True,       # beim Start leere Dateien/Mini-Fehlstarts in den Papierkorb
    "keep_days": 0,             # 0 = alte Sessions nie vorschlagen
    "update_url": "",           # Adresse der Update-Info (JSON), leer = nur Update-Datei
    # Discord (Webhooks – nur schreiben)
    "discord_name": "", "discord_bug_url": "", "discord_best_url": "", "discord_session_url": "",
    "discord_post_best": True, "discord_post_session": True,
    # Coach & Sprache
    "coach_mode": "lehrer",     # "lehrer" = Fahrlehrer-Kommandos | "tipps" = Tipps nach der Kurve | "aus"
    "coach": True, "remind": True, "announce_laps": True, "voice_commands": True, "volume": 90,
    "listen_mode": "always",    # "always" = hört auf das Weckwort | "button" = nur nach Lenkradknopf
    "ptt_button": None,         # {"joy": 0, "button": 5, "name": "..."} – gelernt in den Einstellungen
    # Personalisierung
    "lang": "de",               # Sprache der Ansagen/Befehle: "de" | "en"
    "user_name": "", "assistant_name": "Otto", "voice": "", "rate": 1.1,
    "vibe": "lebendig",         # Betonung der natürlichen Stimmen: "ruhig" | "lebendig" | "energisch"
    "style": "normal",          # "knapp" | "normal" | "motivierend"
    "greeting": True,
    "overlay_opacity": 0.85,    # Deckkraft des ganzen Overlay-Fensters (0.3 = sehr durchsichtig, 1 = deckend)
    "overlay_size": "M",        # S | M | L
    "overlay_lock": False,      # fixiert = Mausklicks gehen ans Spiel, nicht verschiebbar
    "overlay_x": 40, "overlay_y": 40,
    "traffic_alerts": True,     # „Verkehr in 5 Sekunden, GT3“ automatisch ansagen (Multiclass)
    "traffic_same_class": False,  # auch Autos der eigenen Klasse melden
    "cmd_lang": "",             # Sprache der Fahrlehrer-Kommandos: "" = wie die Ansagen | "en" = Renn-Englisch („Brake!“)
    "friend_name": "",          # Kumpel, mit dem man zusammen fährt (Name wie im Spiel)
    "friend_alerts": True,      # Kumpel: Bestzeit, Box, Überholen ansagen
    "flag_alerts": True,        # blaue Flagge ansagen
    "time_alerts": True,        # Rennen auf Zeit: „Noch 10 / 5 Minuten“, „letzte Runde“
    "focus_tips": True,         # nach langsamerer Runde den größten Verlust nennen
    "tyre_alerts": True,        # „Reifen sind auf Temperatur“, „Reifen vorne werden zu heiß“
    "damage_alerts": True,      # Unfall/Schaden melden + nach einer Runde: reparieren ja/nein
    "cut_alerts": True,         # „Kurve geschnitten, Runde ungültig“ (nur wenn LMU die Runde wirklich streicht)
    "race_report": True,       # nach der Zielflagge den Rennbericht ansagen (gespeichert wird er immer)
    "ai_enabled": True,         # KI-Engineer für freie Fragen (nur mit Schlüssel, siehe engineer.py)
    "mic_device": "",           # Mikrofon für Sprachbefehle ("" = Windows-Standard)
    "mic_gain": 1.0,            # Verstärkung (0.5 … 4)
    "mic_sens": 6,              # Empfindlichkeit der Erkennung 1 (streng) … 10 (sehr großzügig)
    "mic_denoise": True,        # Störgeräusch-Filter (Brummen raus, Pausen = Stille)
    "spotter": True,            # „Auto links / rechts / Frei“ (nur LMU)
    "seen_version": "",         # zuletzt gezeigtes „Was ist neu“
}
VOICE_KEYS = ("lang", "coach_mode", "coach", "remind", "announce_laps", "voice_commands", "volume", "user_name", "assistant_name",
              "voice", "rate", "vibe", "style", "greeting", "listen_mode", "ptt_button", "overlay_opacity", "overlay_size", "overlay_lock", "overlay_x", "overlay_y",
              "traffic_alerts", "traffic_same_class", "cmd_lang", "friend_name", "friend_alerts", "flag_alerts", "time_alerts", "focus_tips", "spotter", "tyre_alerts", "damage_alerts", "race_report", "cut_alerts", "ai_enabled", "mic_device", "mic_gain", "mic_sens", "mic_denoise")


def load() -> dict:
    try:
        return {**DEFAULTS, **json.loads(PATH.read_text(encoding="utf-8"))}
    except (OSError, ValueError):
        return dict(DEFAULTS)


_LOCK = __import__("threading").Lock()


def save(data: dict):
    """Erst in eine Hilfsdatei schreiben, dann austauschen – nie eine halb geschriebene settings.json."""
    try:
        with _LOCK:
            tmp = PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
            __import__("os").replace(tmp, PATH)
    except OSError:
        pass
