"""Globale Tastenkombination (funktioniert auch, während das Spiel im Vordergrund ist)."""
import ctypes
import threading
from ctypes import wintypes

MOD_ALT, MOD_CONTROL, MOD_NOREPEAT = 0x0001, 0x0002, 0x4000
WM_HOTKEY = 0x0312
_user32 = ctypes.WinDLL("user32", use_last_error=True)


def register(key: str, callback, mods=MOD_CONTROL | MOD_ALT) -> None:
    """Strg+Alt+<key> ruft callback() auf. Läuft in einem eigenen Thread."""
    def run():
        if not _user32.RegisterHotKey(None, 1, mods | MOD_NOREPEAT, ord(key.upper())):
            print(f"Tastenkombination Strg+Alt+{key.upper()} ist schon belegt.")
            return
        msg = wintypes.MSG()
        while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == WM_HOTKEY:
                try:
                    callback()
                except Exception as e:  # Hotkey darf nie den Thread beenden
                    print("Hotkey-Fehler:", e)
    threading.Thread(target=run, daemon=True).start()
