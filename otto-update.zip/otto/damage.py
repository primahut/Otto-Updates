"""Unfall & Schaden wie ein Renningenieur: erkennen, Zeitverlust messen, Reparatur ja/nein.

LMU (rF2-Plugin) liefert:
  mDentSeverity[8]   Karosserie-Schaden an 8 Stellen rund ums Auto (0 = keiner, 1 = etwas, 2 = stark)
  mOverheating       Motor überhitzt (meist Kühler beschädigt)
  mDetached          ein Teil ist abgefallen
  Rad mFlat/mDetached  Reifenschaden / Rad ab
Was LMU NICHT liefert: Aufhängungs-Schaden und die Reparaturzeit – die schätzen wir.

Ablauf: Unfall erkannt -> sofort kurze Funkmeldung -> nach der ersten vollen Runde danach Zeitverlust pro Runde
gegen das Tempo vorher -> Rechnung „Verlust × Restrunden“ gegen „Boxenstopp + Reparatur“ -> Empfehlung."""
import statistics
import time

REPAIR_S_PER_LEVEL = 7.0      # grobe Schätzung: Reparaturzeit pro Schadensstufe (8 Stellen × 0–2)
PIT_LOSS_DEFAULT = 30.0       # Zeitverlust Boxendurchfahrt + Stand, wenn wir ihn nicht messen konnten


def severity(dents) -> int:
    """0 = kein, 1 = leicht, 2 = mittel, 3 = schwer."""
    total, worst = sum(dents), max(dents, default=0)
    if total == 0:
        return 0
    if total >= 6 or (worst >= 2 and total >= 4):
        return 3
    if worst >= 2 or total >= 3:
        return 2
    return 1


class DamageWatch:
    def __init__(self):
        self.reset()

    def reset(self):
        self.prev = None              # letzter Schadensstand
        self.incident = None          # {"lap", "sev", "base", "dents", "said_verdict"}

    # ------------------------------------------------------------- Erkennen
    def update(self, d: dict | None, lap_no: int | None, laps: list, in_pits: bool) -> list[tuple]:
        """Neuer Schadensstand -> Ereignisse [(art, wert)] zum Ansagen."""
        if not d:
            return []
        ev = []
        p = self.prev
        self.prev = d
        if p is None:
            # Start mit Schaden (Otto später gestartet): merken, aber nicht ansagen
            if sum(d["dents"]) or any(d["flat"]) or any(d["wheel_off"]):
                self._new_incident(d, lap_no, laps)
            return []
        for w in range(4):
            if d["wheel_off"][w] and not p["wheel_off"][w]:
                ev.append(("wheel_off", w))
            elif d["flat"][w] and not p["flat"][w]:
                ev.append(("flat", w))
        if d["overheating"] and not p["overheating"]:
            ev.append(("overheat", None))
        if sum(d["dents"]) > sum(p["dents"]):
            sev = severity(d["dents"])
            ev.append(("dents", sev))
        elif d["detached"] and not p["detached"]:
            ev.append(("parts", None))
        if ev:
            self._new_incident(d, lap_no, laps)
        # repariert (in der Box): alles wieder heil
        if self.incident and not sum(d["dents"]) and not any(d["flat"]) and not any(d["wheel_off"]) \
                and not d["overheating"] and not d["detached"]:
            self.incident = None
            if in_pits:
                ev.append(("repaired", None))
        return ev

    def _new_incident(self, d, lap_no, laps):
        old = self.incident
        before = [l["time_ms"] / 1000 for l in laps if l.get("full", True) and l["lap"] < (lap_no or 0)]
        if old:                       # weiterer Treffer: Basis-Tempo von vor dem ersten Unfall behalten
            base = old["base"]
        else:
            clean = sorted(before[-3:])
            base = clean[len(clean) // 2] if clean else None
        self.incident = {"lap": lap_no, "sev": severity(d["dents"]), "base": base, "dents": list(d["dents"]),
                         "flat": list(d["flat"]), "wheel_off": list(d["wheel_off"]), "overheat": d["overheating"],
                         "said_verdict": False, "said_kind": None, "t": time.time(),
                         "m0": None, "est": None, "offs": old["offs"] if old else 0}

    # ------------------------------------------------------------- Hochrechnung in der laufenden Runde
    def estimate(self, lap: int, pos: float, delta_ms: float | None, laps: list, best_ms: int | None):
        """Schwerer Schaden -> man schafft oft keine ganze Runde. Deshalb schon unterwegs messen: wie schnell wächst
        der Rückstand zur Bestzeit seit dem Unfall? Start 6 s danach (der Dreher/Einschlag selbst zählt nicht)."""
        inc = self.incident
        if not inc or delta_ms is None or pos < 0 or not best_ms:
            return
        now = time.time()
        if inc["m0"] is None:
            if now - inc["t"] >= 6:
                inc["m0"] = (lap, pos, delta_ms, now)
            return
        lap0, pos0, d0, t0 = inc["m0"]
        if lap == lap0:
            frac, loss = pos - pos0, (delta_ms - d0) / 1000
        elif lap == lap0 + 1:                        # über Start/Ziel: Rest der alten Runde + Stück der neuen
            done = next((l for l in laps if l["lap"] == lap0), None)
            if not done:
                return
            frac = (1 - pos0) + pos
            loss = ((done["time_ms"] - best_ms) - d0) / 1000 + delta_ms / 1000
        else:
            return
        if frac >= 0.25 and now - t0 >= 12:
            inc["est"] = loss / frac                 # s pro Runde, hochgerechnet

    # ------------------------------------------------------------- Messen
    def loss(self, laps: list) -> tuple[float | None, int]:
        """(Zeitverlust pro Runde in s, Anzahl gemessener Runden) – nur volle Runden nach der Unfallrunde."""
        inc = self.incident
        if not inc or inc["base"] is None or inc["lap"] is None:
            return None, 0
        after = [l["time_ms"] / 1000 for l in laps if l.get("full", True) and l["lap"] > inc["lap"]][-3:]
        if not after:
            return None, 0
        return statistics.median(after) - inc["base"], len(after)

    def repair_estimate(self, per_level: float | None = None) -> float:
        return (per_level or REPAIR_S_PER_LEVEL) * sum((self.incident or {}).get("dents", []))

    @staticmethod
    def pit_loss(lap_hist: dict) -> float:
        """Was ein Boxenstopp auf dieser Strecke kostet – gemessen an den Stopps aller Autos (Runde mit Box minus Tempo)."""
        diffs = []
        for h in lap_hist.values():
            clean = sorted(t for t, pit in h.get("laps", []) if not pit and t > 0)
            if len(clean) < 2:
                continue
            med = clean[len(clean) // 2]
            diffs += [t - med for t, pit in h["laps"] if pit and t > med + 5]
        return min(90.0, max(15.0, statistics.median(diffs))) if len(diffs) >= 2 else PIT_LOSS_DEFAULT

    def verdict(self, laps: list, left_laps: float | None, stop_needed: bool | None, lap_hist: dict,
                pit_lane: float | None = None, per_level: float | None = None) -> dict:
        """Empfehlung: {"kind": none|wait|box_now|box_next|stay|practice, "loss", "repair", "pit", "gain", "cost"}
        pit_lane / per_level: aus echten eigenen Stopps gelernt (racelog), sonst Schätzung."""
        inc = self.incident
        if not inc:
            return {"kind": "none"}
        if any(inc["wheel_off"]) or any(inc["flat"]):
            return {"kind": "box_now", "why": "wheel"}
        if inc["overheat"]:
            return {"kind": "box_now", "why": "engine"}
        loss, n = self.loss(laps)
        estimated = False
        if loss is None and inc.get("est") is not None:   # noch keine ganze Runde: Hochrechnung nehmen
            loss, estimated = inc["est"], True
        pit = pit_lane + 4.0 if pit_lane else self.pit_loss(lap_hist)        # + kurzes Anhalten
        out = {"loss": loss, "n": n, "repair": self.repair_estimate(per_level), "pit": pit, "sev": inc["sev"],
               "learned": bool(pit_lane or per_level), "estimated": estimated, "offs": inc.get("offs", 0)}
        if loss is None:
            return {**out, "kind": "wait"}
        if inc.get("offs", 0) >= 3 and (left_laps is None or left_laps > 2):   # Auto kaum fahrbar
            return {**out, "kind": "box_now", "why": "handling"}
        if loss < 0.3:
            return {**out, "kind": "stay", "why": "no_loss"}
        if left_laps is None:
            return {**out, "kind": "practice"}
        gain = loss * max(0.0, left_laps - 1)
        if stop_needed:
            cost = out["repair"]
            return {**out, "gain": gain, "cost": cost, "kind": "box_next" if gain > cost else "stay"}
        cost = out["pit"] + out["repair"]
        return {**out, "gain": gain, "cost": cost, "kind": "box_now" if gain > cost * 1.1 else "stay"}
