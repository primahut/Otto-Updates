"""Rennbericht + was Otto aus echten Boxenstopps lernt.

RaceLog beobachtet ein Rennen (1x pro Sekunde): Startplatz, Boxenstopps (Standzeit, reparierter Schaden),
Unfälle. Nach der Zielflagge (oder auf Frage) entsteht daraus der Rennbericht: Plätze, Runden, Bestzeit,
Schnitt, Stints, was die Stopps gekostet haben, Unfälle.

Gelernt und gespeichert (learned.json im Datenordner, bleibt über Updates erhalten):
- Boxengassen-Verlust pro Strecke (Stopp-Zeitverlust minus Standzeit)
- Reparaturzeit pro Schadensstufe (Standzeit mit Reparatur minus Standzeit ohne)"""
import json
import statistics
import time

from .paths import DATA

LEARNED = DATA / "learned.json"
REPORTS = DATA / "reports"


def load_learned() -> dict:
    try:
        return json.loads(LEARNED.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_learned(d: dict):
    try:
        tmp = LEARNED.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, indent=1), encoding="utf-8")
        tmp.replace(LEARNED)
    except OSError:
        pass


def _ema(old, new, a=0.4):
    return new if old is None else old + a * (new - old)


class RaceLog:
    def __init__(self):
        self.learned = load_learned()
        self.reset(None)

    def reset(self, session):
        self.session = session
        self.track = ""
        self.start_place = self.start_overall = None
        self.place = self.overall = None
        self.first_lap = None
        self.pit_laps = set()
        self.stops = []               # {"lap", "still", "dents_in", "dents_out", "loss"}
        self.cur_stop = None
        self.incidents = []           # {"lap", "sev", "loss"}
        self.reported = False
        self._t = None

    # ------------------------------------------------------------- beobachten (1x pro Sekunde)
    def update(self, si: dict, lap: int | None, speed_kmh: float, dents: int, laps: list):
        if si.get("session") != self.session:
            self.reset(si.get("session"))
        if not si.get("race"):
            return
        now = time.time()
        dt = 0.0 if self._t is None else min(2.0, now - self._t)
        self._t = now
        self.track = si.get("track_name") or self.track
        if self.start_place is None and si.get("phase", 5) >= 5 and lap is not None:
            self.start_place, self.start_overall = si.get("class_place"), si.get("place")
            self.first_lap = lap
        self.place, self.overall = si.get("class_place"), si.get("place")
        if si.get("in_pits"):
            if lap is not None:
                self.pit_laps.add(lap)
            if self.cur_stop is None:
                self.cur_stop = {"lap": lap, "still": 0.0, "dents_in": dents, "dents_out": dents, "loss": None}
            if speed_kmh < 3:
                self.cur_stop["still"] += dt
            self.cur_stop["dents_out"] = dents
        elif self.cur_stop is not None:
            if self.cur_stop["still"] > 2:            # Durchfahrt ohne Halt zählt nicht als Stopp
                self.stops.append(self.cur_stop)
            self.cur_stop = None
        self._learn(laps, lap)

    def incident(self, lap, sev):
        self.incidents.append({"lap": lap, "sev": sev, "loss": None})

    def incident_loss(self, loss):
        if self.incidents and self.incidents[-1]["loss"] is None:
            self.incidents[-1]["loss"] = loss

    # ------------------------------------------------------------- messen & lernen
    def _race_laps(self, laps):
        if self.first_lap is None:
            return []
        return [l for l in laps if l["lap"] >= self.first_lap]

    def _clean_median(self, laps):
        clean = sorted(l["time_ms"] / 1000 for l in laps if l["lap"] not in self.pit_laps and l.get("full", True))
        return clean[len(clean) // 2] if len(clean) >= 2 else None

    def _groups(self):
        """Zusammenhängende Box-Runden (Einfahrt-Runde + Ausfahrt-Runde) = ein Stopp."""
        out, cur = [], []
        for l in sorted(self.pit_laps):
            if cur and l != cur[-1] + 1:
                out.append(cur)
                cur = []
            cur.append(l)
        return out + ([cur] if cur else [])

    def _learn(self, laps, lap_now):
        rl = self._race_laps(laps)
        med = self._clean_median(rl)
        if med is None or lap_now is None:
            return
        times = {l["lap"]: l["time_ms"] / 1000 for l in rl}
        groups = self._groups()
        for s in self.stops:
            g = next((g for g in groups if s["lap"] in g), None)
            if g is None or s["loss"] is not None or max(g) >= lap_now or not all(x in times for x in g):
                continue
            s["loss"] = sum(times[x] - med for x in g)
            lane = s["loss"] - s["still"]
            if 5 < lane < 90 and self.track:
                pl = self.learned.setdefault("pit_lane", {})
                pl[self.track] = round(_ema(pl.get(self.track), lane), 1)
            levels = s["dents_in"] - s["dents_out"]
            base = [x["still"] for x in self.stops if x["dents_in"] == x["dents_out"] and x["still"] > 2]
            if levels > 0 and base:
                per = (s["still"] - statistics.median(base)) / levels
                if 0.5 < per < 60:
                    self.learned["repair_per_level"] = round(_ema(self.learned.get("repair_per_level"), per), 1)
            _save_learned(self.learned)

    def learn_wear(self, track: str, cls: str | None, compound: str, per_lap: float):
        """Reifenverschleiß %/Runde pro Strecke + Klasse + Mischung merken (für die Startreifen-Empfehlung)."""
        if not track or not compound or not 0.05 < per_lap < 15:
            return
        w = self.learned.setdefault("wear", {})
        key = f"{track}|{cls or '-'}|{compound}"
        w[key] = round(_ema(w.get(key), per_lap, 0.3), 3)
        _save_learned(self.learned)

    def wear_for(self, track: str, cls: str | None) -> dict:
        pre = f"{track}|{cls or '-'}|"
        return {k[len(pre):]: v for k, v in self.learned.get("wear", {}).items() if k.startswith(pre)}

    def pit_lane(self, track: str) -> float | None:
        return self.learned.get("pit_lane", {}).get(track)

    def repair_per_level(self) -> float | None:
        return self.learned.get("repair_per_level")

    # ------------------------------------------------------------- Bericht
    def report(self, laps: list, T, say_time, final: bool, spoken: bool = True) -> str | None:
        """spoken=False: zum Speichern – Zeiten als „2:00.5“ statt Sprechform."""
        rl = [l for l in self._race_laps(laps) if l.get("full", True)]
        if not rl:
            return None
        if spoken:
            num = lambda x: f"{x:.1f}".replace(".0", "").replace(".", f" {T('point')} ")
        else:
            num = lambda x: f"{x:.1f}"
            say_time = lambda ms: f"{int(ms // 60000)}:{ms % 60000 / 1000:04.1f}"
        parts = [T("rr_head_final") if final else T("rr_head")]
        sp, p = self.start_place, self.place
        if sp and p:
            d = sp - p
            parts.append(T("rr_places", s=sp, p=p, f=T("rr_finish") if final else T("rr_now")) + ", "
                         + (T("rr_gained1") if d == 1 else T("rr_gained", n=d) if d > 0 else T("rr_lost1") if d == -1
                            else T("rr_lost", n=-d) if d < 0 else T("rr_held")) + ".")
        best = min(rl, key=lambda l: l["time_ms"])
        clean = [l["time_ms"] / 1000 for l in rl if l["lap"] not in self.pit_laps and l["time_ms"] <= best["time_ms"] * 1.07]
        txt = T("rr_laps", n=len(rl), b=say_time(best["time_ms"]), l=best["lap"] - self.first_lap + 1)
        if len(clean) >= 2:
            txt += T("rr_avg", a=say_time(statistics.mean(clean) * 1000), s=num(statistics.pstdev(clean)))
        parts.append(txt + ".")
        stops = [s for s in self.stops if s.get("loss") is not None]
        groups = self._groups()
        if groups and len(rl) > 3:
            # Stints zwischen den Stopps: Runden + Schnitt
            bounds = [self.first_lap] + [max(g) + 1 for g in groups] + [10 ** 9]
            st = []
            for a, b in zip(bounds, bounds[1:]):
                ls = [l["time_ms"] / 1000 for l in rl if a <= l["lap"] < b]
                cl = [l["time_ms"] / 1000 for l in rl if a <= l["lap"] < b and l["lap"] not in self.pit_laps
                      and l["time_ms"] <= best["time_ms"] * 1.07]
                if ls:
                    st.append(T("rr_stint", k=len(st) + 1, n=len(ls), a=say_time(statistics.mean(cl) * 1000) if cl else "-"))
            if len(st) > 1:
                parts.append(", ".join(st) + ".")
        if self.stops:
            n = len(self.stops)
            if stops:
                parts.append(T("rr_stops", n=n, s=round(statistics.mean(s["loss"] for s in stops)),
                               st=round(statistics.mean(s["still"] for s in self.stops))))
            else:
                parts.append(T("rr_stops_nol", n=n, st=round(statistics.mean(s["still"] for s in self.stops))))
        for inc in self.incidents[:3]:
            lap_no = (inc["lap"] - self.first_lap + 1) if inc["lap"] is not None else "?"
            parts.append(T("rr_inc_loss", l=lap_no, s=num(inc["loss"])) if inc.get("loss") and inc["loss"] > 0.3
                         else T("rr_inc", l=lap_no))
        return " ".join(parts)

    def save(self, text: str):
        try:
            REPORTS.mkdir(exist_ok=True)
            name = time.strftime("%Y-%m-%d_%H-%M") + "_" + "".join(c for c in self.track if c.isalnum() or c in " -")[:40]
            (REPORTS / f"{name.strip()}.txt").write_text(text + "\n", encoding="utf-8")
        except OSError:
            pass
