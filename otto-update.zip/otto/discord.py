"""Discord-Anbindung über Webhooks (nur SCHREIBEN, kein Bot-Login nötig).

- Bug melden: neuer Beitrag im Forum-Kanal #bug-reports, mit Version, Situation und Protokoll als Anhang.
- Neue persönliche Streckenrekorde -> #bestzeiten
- Zusammenfassung nach jeder Session -> #sessions

Die Webhook-Adressen stehen nur in den lokalen Einstellungen. Zum Weitergeben an Freunde gibt es einen
„Discord-Code“ (alle Adressen in einem kopierbaren Text)."""
import base64
import json
import threading
import time
import urllib.request
import uuid
from . import paths, settings

PURPLE, CYAN, RED, GREY = 0xB65CFF, 0x00E5FF, 0xFF3B5C, 0x66728A
URL_KEYS = ("discord_bug_url", "discord_best_url", "discord_session_url")


def _post(url: str, payload: dict, files: dict[str, bytes] | None = None) -> tuple[bool, str]:
    """Webhook aufrufen; bei Anhängen als multipart/form-data."""
    if not url or not url.startswith("https://discord.com/api/webhooks/") and not url.startswith("https://discordapp.com/api/webhooks/"):
        return False, "Keine gültige Discord-Webhook-Adresse eingetragen."
    headers = {"User-Agent": "Otto-Telemetry (https://github.com, 1.0)"}
    if files:
        boundary = uuid.uuid4().hex
        parts = [f"--{boundary}\r\nContent-Disposition: form-data; name=\"payload_json\"\r\n"
                 f"Content-Type: application/json\r\n\r\n{json.dumps(payload)}\r\n".encode()]
        for i, (name, data) in enumerate(files.items()):
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"files[{i}]\"; filename=\"{name}\"\r\n"
                         f"Content-Type: text/plain\r\n\r\n".encode() + data + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        body = b"".join(parts)
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    else:
        body = json.dumps(payload).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url + ("&" if "?" in url else "?") + "wait=true", data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return 200 <= r.status < 300, "Gesendet ✓"
    except urllib.error.HTTPError as e:
        msg = e.read().decode(errors="ignore")[:200]
        if "thread_name" in msg or "forum" in msg.lower():
            return False, "Das ist ein Forum-Kanal – bitte den Webhook dort erstellen (Otto legt Beiträge selbst an)."
        return False, f"Discord hat abgelehnt ({e.code}): {msg}"
    except Exception as e:
        return False, f"Keine Verbindung zu Discord: {e}"


def _name() -> str:
    st = settings.load()
    return (st.get("discord_name") or st.get("user_name") or "Otto-Fahrer").strip()


def _async(fn, *a):
    threading.Thread(target=fn, args=a, daemon=True).start()


# ---------------------------------------------------------------- Bug melden
def report_bug(title: str, text: str, context: dict, forum: bool = True) -> tuple[bool, str]:
    st = settings.load()
    log = b""
    try:
        lines = paths.LOG.read_text(encoding="utf-8", errors="ignore").splitlines()[-400:]
        log = "\n".join(lines).encode("utf-8")
    except OSError:
        pass
    safe = {k: v for k, v in st.items() if not k.startswith("discord_") and k != "update_url"}
    fields = [{"name": k, "value": str(v)[:1000] or "—", "inline": k in ("Version", "Spiel", "Modus", "Sprache")}
              for k, v in context.items()]
    payload = {
        "username": f"Otto · {_name()}",
        "content": text[:1900] or "(keine Beschreibung)",
        "embeds": [{"title": "Situation", "color": RED, "fields": fields[:20]}],
    }
    if forum:
        payload["thread_name"] = (title or text[:60] or "Bug")[:90]
    files = {"otto.log": log or b"(kein Protokoll)", "einstellungen.json": json.dumps(safe, indent=1, ensure_ascii=False).encode()}
    ok, msg = _post(st.get("discord_bug_url", ""), payload, files)
    if not ok and forum and "Forum" not in msg and "thread_name" not in msg:
        # normaler Text-Kanal statt Forum -> ohne thread_name nochmal
        payload.pop("thread_name", None)
        ok, msg = _post(st.get("discord_bug_url", ""), payload, files)
    return ok, msg


# ---------------------------------------------------------------- Bestzeiten / Sessions
def fmt(ms) -> str:
    s = ms / 1000
    return f"{int(s // 60)}:{s % 60:06.3f}"


def post_record(track: str, car: str, lap_ms: int, old_ms: int | None, sectors: list | None = None):
    st = settings.load()
    if not st.get("discord_post_best"):
        return
    desc = f"**{fmt(lap_ms)}**" + (f"  ({(lap_ms - old_ms) / 1000:+.3f} s)" if old_ms else "")
    if sectors:
        desc += "\n" + "  ".join(f"S{i + 1} {s:.2f}" for i, s in enumerate(sectors) if s)
    payload = {"username": "Otto", "embeds": [{
        "title": f"🏆 Neuer Streckenrekord von {_name()}", "color": PURPLE,
        "description": desc, "fields": [{"name": "Strecke", "value": track or "—", "inline": True},
                                        {"name": "Auto", "value": car or "—", "inline": True}],
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())}]}
    _async(_post, st.get("discord_best_url", ""), payload)


def post_session(track: str, car: str, laps: list[dict], best_ms: int | None, sync: bool = False):
    st = settings.load()
    valid = [l["time_ms"] for l in laps if l.get("valid")]
    if not st.get("discord_post_session") or not valid:
        return
    import statistics
    clean = [t for t in valid if t <= min(valid) * 1.07]
    spread = statistics.pstdev(clean) / 1000 if len(clean) >= 3 else None
    lines = [f"Runden: **{len(laps)}** (gültig {len(valid)})", f"Bestzeit: **{fmt(min(valid))}**"]
    if spread is not None:
        lines.append(f"Konstanz: ±{spread:.2f} s")
    payload = {"username": "Otto", "embeds": [{
        "title": f"📊 Session von {_name()}", "color": CYAN, "description": "\n".join(lines),
        "fields": [{"name": "Strecke", "value": track or "—", "inline": True},
                   {"name": "Auto", "value": car or "—", "inline": True}],
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())}]}
    if sync:                      # beim Schließen von Otto: warten, sonst wird der Thread abgebrochen
        _post(st.get("discord_session_url", ""), payload)
    else:
        _async(_post, st.get("discord_session_url", ""), payload)


def test(kind: str) -> tuple[bool, str]:
    st = settings.load()
    url = st.get({"bug": "discord_bug_url", "best": "discord_best_url", "session": "discord_session_url"}[kind], "")
    payload = {"username": "Otto", "content": f"👋 Test von Otto ({paths.version()}) – {_name()} ist verbunden."}
    if kind == "bug":
        payload["thread_name"] = "Test: Otto ist verbunden"
    ok, msg = _post(url, payload)
    if not ok and kind == "bug" and "Forum" not in msg:
        payload.pop("thread_name")
        ok, msg = _post(url, payload)
    return ok, msg


# ---------------------------------------------------------------- Weitergeben an Freunde
def export_code() -> str:
    st = settings.load()
    data = {k: st.get(k, "") for k in URL_KEYS}
    return "OTTO-DISCORD:" + base64.urlsafe_b64encode(json.dumps(data).encode()).decode()


def import_code(code: str) -> tuple[bool, str]:
    try:
        data = json.loads(base64.urlsafe_b64decode(code.strip().split(":", 1)[1].encode()))
    except Exception:
        return False, "Der Code ist ungültig."
    st = settings.load()
    for k in URL_KEYS:
        if data.get(k):
            st[k] = data[k]
    st.setdefault("discord_post_best", True)
    st.setdefault("discord_post_session", True)
    settings.save(st)
    return True, "Discord ist eingerichtet ✓"
