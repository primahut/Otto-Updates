"""„Was ist neu?“ – wird nach einem Update einmal beim Start gezeigt (und in Einstellungen > System).
Neueste Version oben. Kurz und in Fahrer-Sprache, nicht in Programmierer-Sprache."""
from . import paths

CHANGES = [
    ("2026.10.10.23", "Updates online", [
        "🔄 Updates kommen jetzt online: Otto schaut beim Start nach und zeigt oben „Neues Update verfügbar – Jetzt installieren“. "
        "Oder jederzeit: Einstellungen › System › „Online nach Updates suchen“. Keine Update-Dateien mehr verschicken.",
    ]),
    ("2026.10.10.22", "Hänger-Melder", [
        "🩺 Friert Otto länger als 3 Sekunden ein, schreibt er automatisch auf, was blockiert hat (otto_haenger.log im "
        "Otto-Datenordner) – bitte nach einem Hänger per „Bug melden“ Bescheid geben.",
        "▣ Overlay etwas sparsamer (20 statt 30 Bilder pro Sekunde).",
    ]),
    ("2026.10.10.21", "Fehlerjagd", [
        "🛠 13 Fehler aus einer gründlichen Code-Prüfung behoben, u. a.: Spracherkennung konnte bei belegtem Mikrofon "
        "unbemerkt verstummen; lange Antworten konnten „Auto links“ abschneiden; Ansagen konnten nach einer Frage "
        "für die ganze Session verschwinden; Update-Adresse und Lautstärke wurden manchmal überschrieben; "
        "Einstellungsdatei wird jetzt sicher gespeichert.",
        "🤖 KI-Engineer nennt Zahlen jetzt exakt wie gemessen und antwortet auf Englisch, wenn auf Englisch gefragt.",
        "🎙 Mikro abgesteckt? Otto zeigt es unter Einstellungen › Stimme & Befehle an.",
    ]),
    ("2026.10.10.20", "Update-Datei auswählen repariert", [
        "📦 „Update-Datei installieren…“ öffnet wieder das Fenster zur Dateiauswahl (ging seit dem Wechsel auf die neue "
        "Fenster-Bibliothek gar nicht mehr auf).",
    ]),
    ("2026.10.10.19", "Update-Knopf repariert", [
        "📦 „Otto neu starten“ nach einem Update hat das Update nicht übernommen (die neue Otto startete, solange die alte "
        "noch lief). Jetzt beendet sich Otto erst und startet nach ~8 Sekunden mit der neuen Version neu.",
    ]),
    ("2026.10.10.18", "Reifenwahl, Boxenstopp & besseres Verstehen", [
        "🛞 „Otto, soll ich auf Medium wechseln?“ / „Welche Reifen soll ich nehmen?“ / „Soft oder Medium?“ – "
        "Empfehlung mit Begründung (Restrunden, Streckentemperatur, Regen, Abnutzung, aktuelle Mischung aus LMU).",
        "⛽ „Otto, muss ich in die Box?“ / „Boxenstopp?“ – reicht der Sprit bis ins Ziel, wann spätestens rein, Reifenzustand.",
        "🗣 Über 1100 Sätze: mehr Varianten für „Gap hinten/vorne“ (auch nur „hinten“/„vorne“), „Vorsprung“, „Rückstand“ "
        "– im Hörtest mit echter Sprache 40 von 40 Formulierungen erkannt.",
    ]),
    ("2026.10.10.17", "Funk-Pause", [
        "📻 Sprichst du mit Otto, schweigt der Fahrlehrer – Ottos Antwort kommt sofort (nicht erst in der nächsten Lücke), "
        "danach 1,5 s Ruhe, dann geht's mit den Kommandos weiter. Spotter-Rufe bleiben immer an.",
        "⚡ Lange Antworten kommen Satz für Satz: der erste Satz nach ~1 s statt nach bis zu 15 s Rechenzeit.",
        "🛞 Reifen-Antwort kürzer und knackiger.",
    ]),
    ("2026.10.10.16", "Mikrofon selbst einstellen", [
        "🎙 Mikrofon direkt in Otto wählen (Einstellungen › Stimme & Befehle) – unabhängig vom Windows-Standard.",
        "🔎 Mikro-Test: 3 Sekunden sprechen – Otto zeigt, in welchem Mikrofon deine Stimme ankommt.",
        "🎚 Verstärkung (bis 4×) und Empfindlichkeit einstellbar, Live-Pegel.",
        "🔇 Störgeräusch-Filter: Spielsound/Motorbrummen im Mikro stört die Erkennung nicht mehr "
        "(im Test 20/20 Befehle erkannt statt 15/20).",
    ]),
    ("2026.10.10.15", "Flüssiges Overlay & bessere Erkennung", [
        "▣ Overlay jetzt 30 Bilder pro Sekunde (vorher ~13): Otto schickt die Daten direkt ans Overlay, "
        "der Brems-Countdown läuft flüssig. Spieldaten werden 50x statt 30x pro Sekunde gelesen.",
        "🎤 Spracherkennung großzügiger eingestellt: weniger „nicht verstanden“, lange Sätze werden nicht abgeschnitten.",
        "🎙 Neu unter Einstellungen › Stimme & Befehle: welches Mikrofon Otto hört, Live-Pegel und Warnungen von Windows "
        "(„zu leise“, „kein Signal“) + Knopf zu den Windows-Mikrofoneinstellungen.",
    ]),
    ("2026.10.10.14", "Ruckler im Rennen behoben", [
        "🛠 Großer Fehler behoben: Im Rennen hat Otto bei jeder Platzänderung die Spracherkennung neu aufgebaut "
        "(über 6 Sekunden) – so lange standen Overlay, Live-Coach und Ansagen still. Jetzt dauert das 0,05 s, "
        "passiert nur noch, wenn jemand dem Server beitritt/ihn verlässt, und läuft im Hintergrund.",
        "🎯 Dadurch auch wieder genauere Brems-/Gas-Kommandos und Delta im Rennen.",
    ]),
    ("2026.10.10.13", "Lauter & Overlay-Messung", [
        "🔊 Lautstärke jetzt bis 200 % (Einstellungen › Stimme) – darüber verstärkt Otto selbst, ohne zu übersteuern. "
        "Auch per Sprache: „Otto, lauter“.",
        "▣ Overlay: Hauptfenster bremst nicht mehr mit, während das Spiel im Vordergrund ist; "
        "Einstellungen › Overlay zeigt jetzt Datenrate und Overlay-Bildrate (hilft bei Rucklern – bitte per Bug melden schicken).",
    ]),
    ("2026.10.10.12", "Schneller & Englisch", [
        "⚡ Kurze Fragen („Otto, Reifen“, „Otto, Sprit“) beantwortet Otto immer sofort selbst – "
        "die KI springt nur noch bei längeren, kniffligen Fragen an.",
        "🇬🇧 Englisch: Otto versteht mehr englische Funk-Sätze („how much fuel“, „what's the gap“, „tyre temps“) "
        "und antwortet auf Englisch, wenn du auf Englisch fragst.",
        "🎤 Ist in Windows die englische Spracherkennung installiert, hört Otto Deutsch und Englisch gleichzeitig.",
    ]),
    ("2026.10.10.11", "Bessere Spracherkennung", [
        "🎤 Nach Knopfdruck hört Otto jetzt großzügiger zu (6 Sekunden, auch bei undeutlicher Aussprache).",
        "🔎 Halb verstanden? Otto sucht den ähnlichsten Befehl („wie viel Spritt“ → Sprit) statt aufzugeben.",
        "🤖 Mit Google-Schlüssel hört die KI unklare Aufnahmen ab und erkennt auch Befehle – schneller (unter 1 s).",
        "🛞 Reifen und Bremsen: jetzt alle vier Räder einzeln mit Kommastelle, dazu Druck vorne/hinten.",
        "🗣 Noch mehr Einzelwörter: „Spitze“, „Verfolger“, „Angriff“, „Druck“, „Tank“ …",
    ]),
    ("2026.10.10.10", "Das große Update – alles Neue auf einen Blick", [
        "🎙 Natürliche Stimmen (offline): Einstellungen › Stimme & Befehle › „Thorsten – mit Betonung“ wählen "
        "(einmalig ca. 75 MB). Viele weitere deutsche und englische Stimmen.",
        "🗣 Sprachbefehle verstehen jetzt fast 700 Sätze, freie Sätze („Otto, sag mal, wie viel Sprit hab ich noch?“) "
        "und Renn-Englisch („Gap vorne“, „P 3“, „Last Lap“). Neu: Restzeit, Wetter, Reifen, Bremsen, Zusammenfassung, "
        "nochmal, lauter/leiser. Nicht verstanden? „Bitte wiederholen.“",
        "📻 Race Engineer: „Otto, kann ich ihn noch einholen?“ / „Holt er mich ein?“ – rechnet mit eurem Tempo bis "
        "Rennende und nennt die Zielzeit.",
        "🤖 Optional KI-Engineer (kostenlos, Google-Schlüssel): beantwortet fast jede Rennfrage – Einstellungen › System.",
        "📡 Spotter: „Auto links!“, „Auto rechts!“, „Frei!“ – Overlay leuchtet auf der Seite.",
        "👥 Zusammen fahren: Kumpel eintragen (Einstellungen › Coach) – Ansagen bei seiner Bestzeit, Box, Überholen; "
        "„Otto, wo ist mein Kumpel?“.",
        "🏎 Multiclass: Brems-/Gaspunkte und Rekorde nur aus deiner Klasse; Verkehrs-Ansagen, blaue Flagge, Restzeit-Ansagen.",
        "🛞 Reifen & Bremsen: „Otto, sind die Reifen warm?“ – Otto sagt auch von selbst, wenn sie auf Temperatur sind.",
        "🎯 Lern-Fokus nach langsameren Runden · 🇬🇧 Fahrlehrer optional auf Renn-Englisch („Brake hard!“).",
        "▣ Overlay überarbeitet: Durchsichtigkeit, Größe, Sektoren, Brems-Countdown, ✕ zum Schließen.",
        "🗺 Offizielle Kurvennamen + echte WEC-Zeiten zum Vergleich, neues Replay (Runden vergleichen), "
        "genauere 3D-Ansicht, neues Lenkrad, aufgeräumte Einstellungen, Bug-melden-Knopf.",
    ]),
    ("2026.10.10.9", "KI-Engineer", [
        "📻 Frag Otto, was du willst: „Otto, soll ich auf Medium wechseln?“, „Otto, kann P19 noch P20 einholen?“, "
        "„Otto, how are we looking?“ – ein KI-Engineer (Google Gemini, kostenlos) antwortet mit allen Live-Daten, "
        "auf Deutsch oder Englisch. Einrichten: Einstellungen › System › KI-Engineer.",
        "🛡 Spotter, Fahrlehrer und alle festen Befehle laufen weiter offline – die KI kommt nur bei unbekannten Fragen dazu.",
    ]),
    ("2026.10.10.8", "Race Engineer", [
        "📻 „Otto, kann ich ihn noch einholen?“ – Otto vergleicht dein Tempo mit dem des Vordermanns (deiner Klasse) "
        "und rechnet bis Rennende: „Ganz knapp. Du holst 3 Zehntel pro Runde … halte 1:50,1 oder schneller.“",
        "🛡 „Otto, holt er mich ein?“ – dasselbe nach hinten, mit der Zeit, unter der du bleiben musst. "
        "Auch mit Namen („kann ich Fabian einholen?“) oder „kann ich meinen Kumpel einholen?“.",
        "🎙 Mehr natürliche Stimmen: Karlsson, Pavoque, Ramona, Eva – und auf Englisch u. a. Northern English, Joe, John, Jenny, Amy.",
        "🛞 Reifen & Bremsen wie vom Ingenieur: „Otto, sind die Reifen warm?“ – „Noch kalt, 58 Grad, bei dem Tempo in etwa "
        "einer Runde warm.“ Otto meldet von selbst, wenn sie auf Temperatur sind oder überhitzen. „Otto, Bremsen“ sagt, ob sie im Fenster sind.",
        "🔁 Wenn Otto dich nicht versteht, sagt er „Bitte wiederholen“.",
        "✕ Overlay schließt jetzt mit Otto zusammen und hat ein ✕ (beim Drüberfahren mit der Maus).",
    ]),
    ("2026.10.10.7", "Spotter, Sprachbefehle & Zusammen fahren", [
        "📡 Neu: Spotter – „Auto links!“, „Auto rechts!“, „Drei nebeneinander!“, „Frei!“, sobald jemand neben dir ist. "
        "Im Overlay leuchtet die Seite. (Einstellungen › Coach, nur LMU)",
        "🎯 Lern-Fokus: Nach einer langsameren Runde sagt Otto die eine Stelle, die am meisten gekostet hat – "
        "„Größter Verlust in T11: später bremsen“.",
        "🛞 „Otto, Reifen“: Temperaturen, Druck und Abnutzung.",
        "🗣 Otto versteht viel mehr: freie Sätze („Otto, sag mal, wie viel Sprit hab ich noch?“), viele Varianten "
        "und Renn-Englisch – „Otto, Gap vorne“, „Otto, P 3“, „Otto, Last Lap“, „Otto, Fuel“.",
        "👥 Zusammen fahren: Trag in Einstellungen › Coach deinen Kumpel ein. Otto sagt an, wenn er Bestzeit fährt, "
        "in die Box geht oder ihr euch überholt. „Otto, wo ist mein Kumpel?“ sagt Abstand und Zeitvergleich.",
        "🎧 Fahrlehrer auf Renn-Englisch: „Brake hard!“ … „Power!“ – mit eigener englischer Stimme "
        "(Einstellungen › Coach › Sprache der Kommandos).",
        "⏱ Neue Befehle: „wie lange noch?“, „Wetter“, „Zusammenfassung“, „nochmal“, „lauter“ / „leiser“. "
        "Sprit sagt im Rennen jetzt auch, ob er bis zum Ende reicht.",
        "🏁 Automatisch: blaue Flagge, „Noch 10 / 5 Minuten“ und „Zeit um – letzte Runde“.",
        "🎮 Neues Lenkrad im GT3-Stil in Live, Replay und 3D.",
    ]),
    ("2026.10.10.6", "Natürliche Stimme & Multiclass", [
        "🎙 Natürlich klingende Stimmen (offline): „Thorsten – mit Betonung“ & Co. unter Einstellungen › Stimme. "
        "Mit „Betonung“ klingen Kommandos wie „Bremsen!“ richtig nach Funk.",
        "🏎 Multiclass: Brems- und Gaspunkte, Begrüßung und Rekorde nur noch aus deiner Klasse – "
        "wer GT3 fährt, bekommt keine Hypercar-Bremspunkte mehr.",
        "🗺 Offizielle Kurvennamen für viele WEC-Strecken (Spa, Monza, Interlagos, Fuji …) und echte WEC-Zeiten "
        "deiner Klasse zum Vergleich auf der Fortschrittsseite.",
    ]),
]


def whats_new(st: dict) -> dict:
    """Einträge seit der zuletzt gesehenen Version (bei Erstinstallation nur die neueste).
    st = Einstellungen (die Kopie der Engine, damit nichts überschrieben wird)."""
    seen, cur = st.get("seen_version", ""), paths.version()
    known = [c[0] for c in CHANGES]
    if seen in known:
        entries = CHANGES[:known.index(seen)]
    else:
        entries = CHANGES[:1]
    return {"show": bool(entries) and seen != cur, "version": cur,
            "entries": [{"version": v, "title": t, "items": items} for v, t, items in entries],
            "all": [{"version": v, "title": t, "items": items} for v, t, items in CHANGES]}

