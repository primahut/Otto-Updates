"""Speichert die Fahrt kompakt als gzip-CSV (eine Datei pro Session) – auch ungültige Runden.

Zeilen werden gepuffert und alle paar Sekunden als eigener, abgeschlossener gzip-Block
angehängt. Wird Otto hart beendet, gehen so höchstens die letzten Sekunden verloren –
die Datei bleibt immer lesbar. Stillstand/Pause wird nicht doppelt geschrieben."""
import csv
import gzip
import io
import re
import time
from pathlib import Path
from .sample import Sample

from .paths import SESSIONS
FLUSH_S = 3
MIN_ROWS = 300   # kürzere Aufnahmen (~10 s) sind Fehlstarts und werden verworfen
# Spalte -> Nachkommastellen
COLUMNS = {
    "t": 3, "lap": 0, "lap_time_ms": 0, "lap_pos": 5, "speed_kmh": 1, "throttle": 3, "brake": 3,
    "steering": 4, "steer_range": 0, "gear": 0, "rpm": 0, "x": 2, "y": 2, "z": 2, "yaw": 4,
    "path_lateral": 2, "track_edge": 2,
}


class Recorder:
    def __init__(self, folder: Path | None = None):
        self.folder = folder or SESSIONS
        self.path = None
        self._buf = None
        self._writer = None
        self._rows = 0
        self._t0 = self._last_flush = 0.0
        self._last_key = None
        self._cars_buf = self._cars_writer = None
        self._last_cars_et = None

    def start(self, game: str, info: str):
        self.stop()
        self.folder.mkdir(parents=True, exist_ok=True)
        name = re.sub(r"[^\w@ .-]+", "_", f"{time.strftime('%Y-%m-%d_%H-%M-%S')} {game} {info}").strip()
        self.path = self.folder / f"{name}.csv.gz"
        self._buf = io.StringIO()
        self._writer = csv.writer(self._buf, lineterminator="\n")
        self._writer.writerow(COLUMNS)
        self._rows = 0
        self._cars_buf = self._cars_writer = None
        self._last_cars_et = None
        self._t0 = self._last_flush = time.perf_counter()

    @property
    def active(self) -> bool:
        return self._writer is not None

    def write(self, s: Sample):
        if not self._writer:
            return
        key = (s.lap, s.lap_time_ms, round(s.x, 2), round(s.z, 2))
        if key == self._last_key:      # Spiel pausiert / keine neuen Daten
            return
        self._last_key = key
        now = time.perf_counter()
        vals = {"t": now - self._t0, **{c: getattr(s, c) for c in COLUMNS if c != "t"}}
        self._writer.writerow([round(vals[c], d) if d else int(round(vals[c])) for c, d in COLUMNS.items()])
        self._rows += 1
        if now - self._last_flush > FLUSH_S and self._rows >= MIN_ROWS:
            self._flush()

    def _flush(self):
        data = self._buf.getvalue()
        if data:
            with gzip.open(self.path, "at", encoding="utf-8", newline="") as f:
                f.write(data)
            self._buf.seek(0)
            self._buf.truncate()
        self._flush_cars()
        self._last_flush = time.perf_counter()

    def write_cars(self, et: float, cars: list[dict]):
        """Alle Autos der Session (eigene Datei *.cars.csv.gz), nur bei neuem Scoring-Stand."""
        if not self._writer or et == self._last_cars_et or not cars:
            return
        self._last_cars_et = et
        if self._cars_buf is None:
            self._cars_buf = io.StringIO()
            self._cars_writer = csv.DictWriter(self._cars_buf, fieldnames=["t", "et", *cars[0]], lineterminator="\n")
            self._cars_writer.writeheader()
        t = round(time.perf_counter() - self._t0, 3)
        for c in cars:
            self._cars_writer.writerow({"t": t, "et": round(et, 3), **c})

    def _flush_cars(self):
        if self._cars_buf is not None and self._cars_buf.tell():
            with gzip.open(self.path.with_name(self.path.name.replace(".csv.gz", ".cars.csv.gz")), "at",
                           encoding="utf-8", newline="") as f:
                f.write(self._cars_buf.getvalue())
            self._cars_buf.seek(0)
            self._cars_buf.truncate()

    def stop(self):
        if self._writer and self._rows >= MIN_ROWS:
            self._flush()
        self._buf = self._writer = None
        self._cars_buf = self._cars_writer = None
        self._last_cars_et = None
        self._last_key = None
        self._rows = 0
