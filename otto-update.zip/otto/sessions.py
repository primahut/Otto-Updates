"""Gespeicherte Sessions auflisten und für Replay/Analyse in Runden zerlegen."""
import csv
import gzip
import re
from functools import lru_cache
from pathlib import Path
from .recorder import SESSIONS

NAME_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-\d{2} (\S+) (.*?)(?:\.csv(?:\.gz)?)$")
FIELDS = ["t", "lap_time_ms", "lap_pos", "speed_kmh", "throttle", "brake", "steering",
          "steer_range", "gear", "rpm", "x", "y", "z", "yaw", "path_lateral", "track_edge"]


def is_full_lap(pos: list[float]) -> bool:
    """Von Start/Ziel bis Start/Ziel gefahren? Die ersten Werte dürfen noch kurz
    bei ~100 % der Vorrunde hängen (Verzögerung im Spiel)."""
    if len(pos) < 30 or min(pos) < 0:
        return False
    head = pos[: max(10, len(pos) // 10)]
    return min(head) < 0.05 and max(pos[-30:]) > 0.95


OFF_MIN_M = 1.0      # Fahrzeugmitte so weit hinter dem Rand -> "Track Limit" (Räder draußen)
OFF_INVALID_M = 3.0  # ab hier deutlicher Ausritt -> Runde zählt nicht als Bestzeit/Geist


def find_offtracks(d: dict) -> list[dict]:
    """Stellen, an denen das Auto neben der Strecke war (nur mit LMU-Randdaten)."""
    lat, edge = d["path_lateral"], d["track_edge"]
    offs, cur = [], None
    for i, (a, e) in enumerate(zip(lat, edge)):
        over = abs(a) - abs(e) if abs(e) > 2 else 0
        if over > OFF_MIN_M:
            if cur and i - cur["i1"] <= 5:
                cur["i1"] = i
                if over > cur["max_m"]:
                    cur.update(max_m=over, i_max=i)
            else:
                cur = {"i0": i, "i1": i, "max_m": over, "i_max": i}
                offs.append(cur)
    return [{**o, "max_m": round(o["max_m"], 1), "lap_pos": d["lap_pos"][o["i_max"]],
             "x": d["x"][o["i_max"]], "z": d["z"][o["i_max"]],
             "severe": o["max_m"] >= OFF_INVALID_M} for o in offs]


def class_of(file: str) -> str | None:
    """Fahrzeugklasse dieser Aufnahme („Hypercar“, „LMP2“, „GT3“ …) aus der Datei mit allen Autos.
    None, wenn unbekannt (AC/ACC oder ältere Aufnahme ohne Autodatei)."""
    from .i18n import class_name
    p = SESSIONS / file.replace(".csv.gz", ".cars.csv.gz")
    try:
        with gzip.open(p, "rt", encoding="utf-8", newline="") as f:
            for i, row in enumerate(csv.DictReader(f)):
                if row.get("player") == "1" and row.get("cls"):
                    return class_name(row["cls"])
                if i > 3000:
                    break
    except (OSError, EOFError, csv.Error):
        pass
    return None


def track_of(file: str) -> str:
    """Streckenname aus dem Dateinamen („… <Auto> @ <Strecke>.csv.gz“)."""
    m = NAME_RE.match(file)
    info = m.group(5) if m else file
    return info.partition(" @ ")[2].replace("_", " ").strip()


def list_sessions() -> list[dict]:
    out = []
    for p in sorted(SESSIONS.glob("*.csv*"), reverse=True):
        if ".cars." in p.name:     # Positionen aller Autos gehören zur Haupt-Datei
            continue
        m = NAME_RE.match(p.name)
        if not m or p.stat().st_size < 2000:   # Mini-Dateien (Fehlstarts) ignorieren
            continue
        date, hh, mm, game, info = m.groups()
        out.append({"file": p.name, "date": f"{date} {hh}:{mm}", "game": game,
                    "info": info.replace("_", " "), "size_kb": p.stat().st_size // 1024})
    return out


@lru_cache(maxsize=8)
def _load(file: str, mtime: float) -> list[dict]:
    p = SESSIONS / file
    opener = gzip.open if p.suffix == ".gz" else open
    laps: dict[int, dict] = {}
    with opener(p, "rt", encoding="utf-8", newline="") as f:
        try:
            for row in csv.DictReader(f):
                try:
                    lap = int(float(row["lap"]))
                    vals = [float(row.get(k) or 0) for k in FIELDS]
                except (KeyError, ValueError, TypeError):
                    continue  # abgeschnittene Zeile
                d = laps.setdefault(lap, {k: [] for k in FIELDS})
                for k, v in zip(FIELDS, vals):
                    d[k].append(v)
        except EOFError:
            pass  # Datei wurde nicht sauber abgeschlossen (alte Aufnahmen) – Rest nutzen
    result = []
    for lap, d in sorted(laps.items()):
        if len(d["t"]) < 30:
            continue
        # Outlap aus der Box (Start fast im Stand) zählt nicht als volle Runde
        full = is_full_lap(d["lap_pos"]) and d["speed_kmh"][0] > 40
        offs = find_offtracks(d)
        result.append({"lap": lap, "time_ms": int(d["lap_time_ms"][-1]), "full": full, "data": d,
                       "offs": offs, "valid": full and not any(o["severe"] for o in offs)})
    return result


def lap_info(l: dict) -> dict:
    """Kurzinfo einer Runde für die Oberfläche."""
    return {"lap": l["lap"], "time_ms": l["time_ms"], "full": l["full"], "valid": l["valid"],
            "offs": len(l["offs"]), "severe": sum(1 for o in l["offs"] if o["severe"])}


def load_laps(file: str) -> list[dict]:
    p = SESSIONS / file
    return _load(file, p.stat().st_mtime)


def lap_summary(file: str) -> list[dict]:
    laps = load_laps(file)
    best = min((l["time_ms"] for l in laps if l["valid"]), default=None)
    return [{**lap_info(l), "best": l["valid"] and l["time_ms"] == best} for l in laps]


def lap_data(file: str, lap: int) -> dict | None:
    for l in load_laps(file):
        if l["lap"] == lap:
            return {**lap_info(l), **l["data"], "off_list": l["offs"]}
    return None
