"""Hintergrund-Thread: liest Telemetrie, zeichnet auf, erkennt Runden, berechnet Delta zur Bestzeit."""
import bisect
import re
import threading
import time
from dataclasses import asdict
from .games import ALL_READERS
from .games.fake import FakeReader
from .recorder import Recorder
from .sessions import OFF_INVALID_M, OFF_MIN_M, is_full_lap
from . import discord, i18n, joystick, neural, paths, settings, voice
from . import version as ver
from .i18n import T
from .coach import KEYS as COACH_KEYS, LiveCoach
from .pacenotes import PaceNotes
from .spotter import Spotter
from . import tyres as tyrelib
from .damage import DamageWatch
from .racelog import RaceLog
from .testlog import TestLog
from .engineer import Engineer


def fmt_ms(ms: int) -> str:
    s = ms / 1000
    return f"{int(s // 60)}:{s % 60:06.3f}"

HZ = 50          # Lesungen pro Sekunde (LMU-Telemetrie kommt mit 50 Hz; ein Durchlauf < 0,1 ms)
MIN_LAP_MS = 20000


def _beep(on: bool):
    """Hörbare Rückmeldung (man sieht Otto im Spiel ja nicht): hoch = Start, 2x tief = Stopp."""
    def run():
        try:
            import winsound
            if on:
                winsound.Beep(1200, 150)
            else:
                winsound.Beep(600, 120)
                winsound.Beep(450, 160)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


def _ptt_beep():
    """Kurzer hoher Doppel-Ton: „ich höre zu“."""
    def run():
        try:
            import winsound
            winsound.Beep(1500, 60)
            winsound.Beep(1900, 60)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


class Engine:
    def __init__(self):
        self.lock = threading.Lock()
        self.source = "auto"          # "auto" oder "sim"
        self.recorder = Recorder()
        self.settings = settings.load()
        self.rec_on = self.settings["auto_record"]   # soll gerade aufgenommen werden?
        self._sim = FakeReader()
        self._real = [R() for R in ALL_READERS]
        self.speaker = voice.Speaker()
        self.coach = LiveCoach(self.speaker)
        self.bank = voice.SoundBank(self.speaker)
        self.pace = PaceNotes(self.bank)
        self.spotter = Spotter()
        self.tyre_watch = tyrelib.TyreWatch()
        self.damage_watch = DamageWatch()
        self.race_log = RaceLog()                      # Rennbericht + gelernte Box-/Reparaturzeiten
        self._lap_lmu_invalid = False                  # LMU hat die laufende Runde gestrichen (Track Limits)
        self._off_prev = False                         # war zuletzt neben der Strecke
        self._off_since = None                         # seit wann neben der Strecke
        self._wear_log, self._wear_prev = {}, None     # Verschleiß pro Runde je Mischung (Startreifen-Rechnung)
        self.engineer = Engineer()
        self.ai_view = None           # letzte KI-Antwort (Zeit, Dauer, Fehler) fürs UI
        self._pace_ms = None          # Rundenzeit der aktuellen Fahrlehrer-Vorlage
        self.car_class = None         # Fahrzeugklasse („Hypercar“, „LMP2“, „GT3“ …) – None bei AC/ACC
        self._targets_t, self._targets_sig = 0.0, None
        self._last_ok = 0.0
        self._alltime_ms, self._pb_flash_until = None, 0.0
        self._traffic_t, self._alerted, self.traffic_view = 0.0, {}, []
        self._live, self.friend_view = {"t": 0.0, "friend": None, "blue_t": 0.0, "warned": set()}, None
        self._lap_hist = {}           # Auto-ID -> {"n": Runden, "laps": [(Zeit s, Box?)]}
        self._rate, self.rates = {"ok": 0, "bad": 0, "t": time.time()}, {"data_hz": 0, "drop_pct": 0}
        self.overlay_fps = (None, 0.0)  # Bildrate, die das Overlay selbst meldet
        self._traffic_smooth = {}
        self.speaker.gate = self.pace.quiet_window      # Ansagen nie in Fahrlehrer-Kommandos hinein
        self.listener = voice.Listener(self.handle_command)
        # Funk-Pause: sprichst du mit Otto, schweigt der Fahrlehrer, bis die Antwort durch ist (+1,5 s Ruhe)
        self.listener.on_speech = lambda: self.pace.hold(6)
        self.listener.on_wake = lambda: (self.pace.hold(6), self.bank.play("beep1"))   # „Otto“ … Piep … „Reifen“
        # Test-Protokoll (nur Entwickler-Version): alles mitschreiben, was Otto sagt
        self.testlog = TestLog()
        self._heard_logged = set()
        if self.testlog.enabled:
            say_orig, play_orig = self.speaker.say, self.bank.play
            self.speaker.say = lambda text, *a, **k: (self.testlog.write("sagt", text=text), say_orig(text, *a, **k))[1]
            self.bank.play = lambda code: (self.testlog.write("spotter", code=code) if code in voice.SoundBank.PRIORITY
                                           else None, play_orig(code))[1]
        self.speaker.on_other = lambda dur: self.pace.hold(dur + 1.0) if self.pace.held else None
        self.speaker.on_reply = lambda dur, last=True: (self.pace.release(dur + 1.5) if last else self.pace.hold(dur + 20))
        self.listener.ai_enabled = lambda: bool(self.settings.get("ai_enabled", True)) and self.engineer.ready
        self.learning_button = False
        try:
            self.buttons = joystick.ButtonWatcher(self._on_button)
        except Exception as e:      # kein winmm o. Ä. -> Knopf-Funktion einfach aus
            print("Controller-Knöpfe nicht verfügbar:", e)
        self._reset()
        self.apply_voice_settings()
        threading.Thread(target=self._loop, daemon=True).start()

    # ---------- Sprache / Coach ----------
    def apply_voice_settings(self):
        st = self.settings
        mode = st["coach_mode"]       # "lehrer" | "tipps" | "aus"
        self.pace.enabled = mode == "lehrer"
        self.coach.enabled = mode == "tipps" and st["coach"]
        self.coach.remind = mode == "tipps" and st["remind"]
        self.coach.announce_laps = st["announce_laps"]
        self.coach.focus = st.get("focus_tips", True)
        self.coach.user_name = st["user_name"].strip()
        self.coach.style = st["style"]
        self.speaker.volume = st["volume"]
        self.speaker.voice = st["voice"]
        self.speaker.rate = float(st["rate"])
        self.speaker.vibe = st.get("vibe", "lebendig")
        self.speaker.cmd_lang = st.get("cmd_lang", "") if st.get("cmd_lang", "") != st["lang"] else ""
        i18n.LANG = st["lang"]
        self.listener.set_mic(st.get("mic_device", ""), float(st.get("mic_gain", 1.0)), int(st.get("mic_sens", 6)),
                              bool(st.get("mic_denoise", True)))
        self.listener.configure(st["assistant_name"], st["lang"])
        self.listener.mode = st["listen_mode"]
        v = st["voice"]
        if v.startswith("piper:") and not neural.installed(v[6:]):
            # natürliche Stimme fehlt noch: einmalig laden, bis dahin spricht die Windows-Stimme
            def fetch():
                if neural.download(v[6:]):
                    self.bank.prepare()
                    if self.speaker.voice == v:
                        self.coach.say(T("voice_ready"), max_age=10)
            threading.Thread(target=fetch, daemon=True).start()
        cl = self.speaker.cmd_lang
        if cl and v.startswith("piper:") and not any(neural.installed(x["model"]) for x in neural.CATALOG.get(cl, [])):
            # Renn-Englisch mit natürlicher Stimme: passende englische Stimme einmalig nachladen
            first = neural.CATALOG[cl][0]["model"]
            threading.Thread(target=lambda: neural.download(first) and self.bank.prepare(), daemon=True).start()
        threading.Thread(target=self.bank.prepare, daemon=True).start()   # Kommandos mit neuer Stimme
        if st["voice_commands"]:
            self.listener.start()
        else:
            self.listener.stop()

    def learn_button(self):
        """Nächster Knopfdruck an Lenkrad/Controller wird zur Sprechtaste."""
        self.learning_button = True

    def _on_button(self, joy: int, button: int):
        if self.learning_button:
            self.learning_button = False
            self.set_voice_setting("ptt_button", {"joy": joy, "button": button,
                                                  "name": f"{joystick.device_name(joy)} · Knopf {button + 1}"})
            self.coach.say(T("button_saved"), max_age=3)
            return
        b = self.settings.get("ptt_button")
        if b and b["joy"] == joy and b["button"] == button:
            self.push_to_talk()

    def push_to_talk(self):
        self.pace.hold(8)                            # Funk-Pause, solange du sprichst
        if self.listener.running:
            self.listener.open_window()
            _ptt_beep()

    def set_voice_setting(self, key: str, value):
        if key not in settings.VOICE_KEYS:
            return
        with self.lock:
            if key == "lang" and value != self.settings["lang"]:
                self.settings["voice"] = ""          # passende Stimme der neuen Sprache automatisch wählen
            self.settings[key] = value
            settings.save(self.settings)
        self.apply_voice_settings()

    def handle_command(self, cmd: str, text: str = ""):
        """Sprachbefehl (oder Test-Knopf) ausführen – Antwort in der Sprache der Frage
        („Gap ahead“ -> Englisch, auch wenn Otto sonst Deutsch spricht)."""
        reply = "en" if text and i18n.LANG != "en" and i18n.is_english(text.replace(self.settings["assistant_name"], "")) else None
        i18n._local.lang = reply
        self.testlog.write("befehl", cmd=cmd, gehoert=text)
        self.pace.hold(5)                            # bis die Antwort kommt: keine Fahrlehrer-Kommandos
        try:
            return self._handle_command(cmd, text)
        finally:
            i18n._local.lang = None

    def _say_reply(self, t: str):
        """Antwort auf eine Frage: sofort (Funk-Pause), danach 1,5 s Ruhe, dann wieder Fahrlehrer."""
        lang = getattr(i18n._local, "lang", None)
        self.coach.last_msg = t
        self.coach.history = (getattr(self.coach, "history", []) + [f"{time.strftime('%H:%M:%S')} {t}"])[-12:]
        self.coach._last_say = time.time()
        self.pace.hold(15)                           # hält, bis die Antwort läuft (on_reply setzt das Ende)
        self.speaker.say(t, max_age=8, lang=lang, reply=True)
        # natürliche Stimme aktiv, aber keine in dieser Sprache? Einmalig nachladen (bis dahin Windows-Stimme)
        if self.speaker.voice.startswith("piper:") and lang in neural.CATALOG and \
                not any(neural.installed(v["model"]) for v in neural.CATALOG[lang]):
            first = neural.CATALOG[lang][0]["model"]
            threading.Thread(target=neural.download, args=(first,), daemon=True).start()

    def _handle_command(self, cmd: str, text: str = ""):
        say = self._say_reply
        num = lambda x: f"{x:.1f}".replace(".", f" {T('point')} ")
        with self.lock:
            laps = [l for l in self.laps]
            best, delta, s, reader = self.best_ms, self.delta_ms, self.sample, self.reader
        info = reader.race_info() if reader and hasattr(reader, "race_info") else None
        if cmd == "last_lap":
            if not laps:
                return say(T("no_lap"))
            l = laps[-1]
            extra = "" if not best or l["time_ms"] == best else T("vs_best", d=voice.say_delta(l["time_ms"] - best))
            say(T("last_lap", t=voice.say_time(l["time_ms"])) + extra + ("" if l.get("valid", True) else f", {T('invalid')}"))
        elif cmd == "best":
            say(T("best", t=voice.say_time(best)) if best else T("no_best"))
        elif cmd == "delta":
            say(T("delta", d=voice.say_delta(delta)) if delta is not None else T("no_delta"))
        elif cmd == "where":
            say(self.coach.where_summary())
        elif cmd == "position":
            if not info:
                return say(T("no_pos"))
            t = T("pos", p=info["place"], n=info["cars"])
            if info.get("ahead_s") is not None:
                t += T("ahead", s=num(info["ahead_s"]))
            if info.get("behind_s") is not None:
                t += T("behind", s=num(info["behind_s"]))
            say(t)
        elif cmd == "fuel":
            if not info or info.get("fuel") is None:
                return say(T("no_fuel"))
            per_lap = self._fuel_per_lap()
            t = T("fuel", l=f"{info['fuel']:.0f}")
            if per_lap:
                t += T("fuel_laps", n=f"{info['fuel'] / per_lap:.0f}")
                # Rennen: reicht es bis zum Ende? (Restzeit / typische Rundenzeit, +1 angefangene Runde)
                si = reader.session_info() if hasattr(reader, "session_info") else None
                lap_s = self._typical_lap_s(laps)
                if si and si["race"] and lap_s:
                    if si.get("time_left") is not None and 0 < si["time_left"] < 86400:
                        need_laps = si["time_left"] / lap_s + 1
                    elif si.get("max_laps"):
                        need_laps = si["max_laps"] - si["laps_done"]
                    else:
                        need_laps = None
                    if need_laps:
                        short = need_laps * per_lap - info["fuel"]
                        t += T("fuel_end_ok") if short <= 0 else T("fuel_end_short", l=f"{short:.0f}")
            say(t)
        elif cmd == "rec_start":
            if not self.rec_on:
                self.toggle_recording()
            say(T("rec_on"))
        elif cmd == "rec_stop":
            if self.rec_on:
                self.toggle_recording()
            say(T("rec_off"))
        elif cmd == "coach_on":
            self.set_voice_setting("coach_mode", self.settings.get("coach_mode_prev") or "lehrer")
            say(T("coach_on"))
        elif cmd == "coach_off":
            if self.settings["coach_mode"] != "aus":
                self.settings["coach_mode_prev"] = self.settings["coach_mode"]
            self.set_voice_setting("coach_mode", "aus")
            say(T("coach_off"))
        elif cmd == "help":
            say(T("help", w=self.settings["assistant_name"]))
        elif cmd.startswith("gap:"):
            _, kind, *val = cmd.split(":", 2)
            g = reader.gap_to(kind, val[0] if val else "") if reader and hasattr(reader, "gap_to") else None
            if not g:
                return say(T("gap_unknown"))
            who = T("gap_who", p=g["place"]) + (T("gap_num", n=int(g["number"])) if g["number"] else "")
            if g["race"]:
                if "laps" in g:
                    say(T("gap_laps_behind" if g["laps"] > 0 else "gap_laps_ahead", who=who, n=abs(g["laps"])))
                else:
                    say(T("gap_behind_you" if g["gap_s"] > 0 else "gap_ahead_of_you", who=who, s=num(abs(g["gap_s"]))))
            elif g["their_best"]:
                t = voice.say_time(g["their_best"] * 1000)
                say(T("gap_best", who=who, t=t, d=voice.say_delta((g["my_best"] - g["their_best"]) * 1000))
                    if g["my_best"] else T("gap_best_only", who=who, t=t))
            else:
                say(T("gap_nobest", who=who))
        elif cmd == "traffic":
            try:
                tr = reader.traffic(horizon_s=3600, max_dist=1e9) if reader and hasattr(reader, "traffic") else []
            except TypeError:
                tr = reader.traffic() if reader and hasattr(reader, "traffic") else []
            if not self.settings.get("traffic_same_class"):
                tr = [x for x in tr if not x["same_class"]] or tr
            ahead = [x for x in tr if x["dir"] == "ahead"][:2]
            behind = [x for x in tr if x["dir"] == "behind"][:1]
            if not ahead and not behind:
                return say(T("tr_none"))
            name = lambda x: i18n.class_name(x["cls"]) + (T("tr_num", n=int(x["number"])) if x["number"] else "")
            parts = []
            when = lambda s: T("in_min", m=round(s / 60)) if s >= 90 else T("in_s", s=max(1, round(s)))

            def gap(x):         # Zeitabstand wie im LMU-HUD
                g = x.get("gap", x["t"])
                return T("sec_1") if g < 1.5 else T("sec_n", s=round(g)) if g < 90 else T("in_min", m=round(g / 60)).split(" ", 1)[1]
            if ahead:
                parts.append(T("tr_ahead3", g=gap(ahead[0]), w=when(ahead[0]["t"]), c=name(ahead[0])))
                if len(ahead) > 1:
                    parts[-1] += T("tr_then3", g=gap(ahead[1]), c=name(ahead[1]))
            if behind:
                parts.append(T("tr_behind3", g=gap(behind[0]), w=when(behind[0]["t"]), c=name(behind[0])))
            say(". ".join(parts))
        elif cmd.startswith("catch:"):
            _, kind, *val = cmd.split(":", 2)
            if kind == "friend":
                kind, val = "name", [self.settings.get("friend_name", "")]
                if not val[0]:
                    return say(T("friend_unset"))
            say(self._catch_text(reader, kind, val[0] if val else ""))
        elif cmd == "compound":
            sr = self._session_reader()
            pre = self._pre_race(sr)
            # vor dem Start (Garage, Reifenmenü) oder ohne Fahrdaten: Startreifen-Rechnung fürs ganze Rennen
            if pre and (pre["before_start"] or s is None):
                say(self._start_text(sr, laps, text))
            else:
                say(self._compound_text(reader, laps, text))
        elif cmd == "start_tyres":
            say(self._start_text(self._session_reader(), laps, text))
        elif cmd == "pit":
            dmg = self._damage_text(reader, laps, info) if self.damage_watch.incident else ""
            pit = self._pit_text(reader, laps, info)
            say((dmg + " " + ("" if dmg and pit == T("pit_nodata") else pit)).strip())
        elif cmd == "race_report" or (cmd == "session" and self.race_log.start_place is not None):
            rl = self.race_log
            say(rl.report(laps, T, voice.say_time, final=rl.reported) or T("rr_none"))
        elif cmd == "damage":
            say(self._damage_text(reader, laps, info, always=True))
        elif cmd == "tyres":
            say(self._tyre_text(reader, laps))
        elif cmd in ("ai", "ai_test") and not self.engineer.ready:
            say(T("ai_nokey"))
        elif cmd in ("ai", "ai_test"):
            audio = self.listener.last_audio if cmd == "ai" else None
            self.listener.last_audio = None
            question = None if cmd == "ai" else T("ai_test_q")
            threading.Thread(target=self._ask_engineer, args=(audio, question, getattr(i18n._local, "lang", None)),
                             daemon=True).start()
        elif cmd == "say_again":
            say(T("say_again"))
        elif cmd == "brakes":
            say(self._brake_text(reader))
        elif cmd == "time_left":
            si = reader.session_info() if reader and hasattr(reader, "session_info") else None
            say(self._time_left_text(si, laps) if si else T("no_session"))
        elif cmd == "weather":
            si = reader.session_info() if reader and hasattr(reader, "session_info") else None
            if not si:
                return say(T("no_session"))
            c = (T("w_rain") if si["raining"] > 0.1 else T("w_wet") if si["wet"] > 0.3 else T("w_damp") if si["wet"] > 0.05
                 else T("w_clouds") if si["cloud"] > 0.6 else T("w_dry"))
            say(T("weather", a=round(si["air"]), t=round(si["track"]), c=c))
        elif cmd == "friend":
            name = self.settings.get("friend_name", "").strip()
            if not name:
                return say(T("friend_unset"))
            d = reader.driver_info(name) if reader and hasattr(reader, "driver_info") else None
            if not d:
                return say(T("friend_missing", n=name))
            say(self._friend_text(d))
        elif cmd == "session":
            valid = [l["time_ms"] for l in laps if l.get("valid", True)]
            if not laps or not valid:
                return say(T("no_lap"))
            import statistics
            clean = [t for t in valid if t <= min(valid) * 1.07]
            spread = statistics.pstdev(clean) / 1000 if len(clean) >= 2 else 0
            say(T("session", n=len(laps), v=len(valid), b=voice.say_time(min(valid)),
                  a=voice.say_time(statistics.mean(clean)), s=f"{spread:.1f}".replace(".", f" {T('point')} ") + " " + T("seconds")))
        elif cmd == "repeat":
            say(self.speaker.last_text or T("nothing_said"))
        elif cmd in ("louder", "quieter"):
            v = int(self.settings["volume"]) + (15 if cmd == "louder" else -15)
            self.set_voice_setting("volume", max(10, min(200, v)))
            say(T(cmd))
        elif cmd == "test":
            say(self.coach.hello())
        elif cmd == "test_pace":       # Fahrlehrer-Kommandos probehören
            def demo():
                for code, pause in (("left_out", 1.4), ("beep3", 1), ("beep2", 1), ("beep1", 0.9), ("brake_hard", 2.2), ("gas", 1)):
                    self.bank.play(code)
                    time.sleep(pause)
            threading.Thread(target=demo, daemon=True).start()
    def _pace(self, cid) -> float | None:
        """Aktuelles Renntempo eines Autos (s): Median der letzten sauberen Runden (ohne Box-/Ausreißerrunden)."""
        laps = [t for t, pit in self._lap_hist.get(cid, {}).get("laps", []) if not pit]
        if not laps:
            return None
        best = min(laps)
        laps = sorted(t for t in laps[-4:] if t <= best * 1.05)
        return laps[len(laps) // 2] if laps else None

    def _catch_text(self, reader, kind: str, value: str = "") -> str:
        """Race Engineer: „Kann ich ihn noch einholen?“ / „Holt er mich ein?“ – aus Abstand, Tempo beider
        (letzte Runden) und verbleibender Renndauer. Mit Zielzeit: „Mit 1:50,2 pro Runde schaffst du es.“"""
        if not reader or not hasattr(reader, "rival"):
            return T("no_session")
        rv = reader.rival(kind, value)
        si = reader.session_info() if hasattr(reader, "session_info") else None
        if not rv:
            return T("catch_none_ahead" if kind == "ahead" else "catch_none_behind" if kind == "behind" else "gap_unknown")
        if not rv["race"] or not si:
            return T("catch_norace")
        who = (rv["name"].split()[0] if kind in ("name",) and rv["name"] else
               T("gap_who", p=rv["place"]) + (T("gap_num", n=int(rv["number"])) if rv["number"] else ""))
        if rv["laps_diff"]:
            return T("gap_laps_behind" if rv["laps_diff"] > 0 else "gap_laps_ahead", who=who, n=abs(rv["laps_diff"]))
        mine, his = self._pace(rv["my_id"]), self._pace(rv["id"])
        if not mine or not his:
            return T("catch_nodata")
        # verbleibende Runden (für mich)
        tl = si.get("time_left")
        if si.get("max_laps") and (tl is None or tl > 86400):
            laps_left = max(0.0, si["max_laps"] - si["laps_done"] - 1 + 0.5)
        elif tl is not None and 0 < tl < 86400:
            laps_left = tl / mine + 0.5                  # nach Ablauf der Zeit wird die Runde noch zu Ende gefahren
        elif tl is not None and tl <= 0:
            laps_left = 0.5                              # Zeit um: nur noch die laufende Runde
        else:
            laps_left = 99.0                             # Renndauer unbekannt: nur der Tempo-Vergleich zählt
        if laps_left < 0.3:
            return T("time_over")
        tenth = lambda x: (f"{abs(x) * 10:.0f} {T('tenths')}" if abs(x) < 0.95 else
                           f"{abs(x):.1f}".replace(".", f" {T('point')} ") + " " + T("seconds"))
        secs = lambda x: f"{abs(x):.1f}".replace(".", f" {T('point')} ")
        gap = abs(rv["gap_s"])
        if rv["gap_s"] < 0:                              # er ist vor mir -> kann ich ihn einholen?
            gain = his - mine                            # + = ich bin schneller
            need = his - gap / laps_left                 # so schnell muss ich im Schnitt fahren
            best = min(self._my_lap_times() or [mine])
            if gain <= 0.02:
                if need < best * 0.995:
                    return T("catch_unreal", who=who, c=tenth(gain), t=voice.say_time(need * 1000))
                return T("catch_no", who=who, c=tenth(-gain) if gain < 0 else T("same"), t=voice.say_time(need * 1000))
            n = gap / gain
            if n <= laps_left * 0.8:
                return T("catch_yes", c=tenth(gain), n=max(1, round(n)), who=who)
            if n <= laps_left:
                return T("catch_barely", c=tenth(gain), who=who, t=voice.say_time(need * 1000))
            if need < best * 0.995:                      # nötige Zeit wäre schneller als die eigene Bestzeit
                return T("catch_unreal", who=who, c=tenth(gain), t=voice.say_time(need * 1000))
            return T("catch_short", c=tenth(gain), s=secs(gap - gain * laps_left), t=voice.say_time(need * 1000), who=who)
        # er ist hinter mir -> holt er mich ein?
        gain = mine - his                                # + = er ist schneller
        limit = his + gap / laps_left                    # langsamer als das darf ich im Schnitt nicht fahren
        if gain <= 0.02:
            return T("def_safe", who=who, c=tenth(-gain) if gain < 0 else T("same"))
        n = gap / gain
        if n > laps_left:
            return T("def_ok", who=who, c=tenth(gain), s=secs(gap - gain * laps_left), t=voice.say_time(limit * 1000))
        if n > laps_left * 0.8:
            return T("def_barely", who=who, c=tenth(gain), t=voice.say_time(limit * 1000))
        return T("def_caught", who=who, c=tenth(gain), n=max(1, round(n)), t=voice.say_time(limit * 1000))

    def _ask_engineer(self, audio: bytes | None, question: str | None, reply_lang: str | None = None):
        """Freie Frage an den KI-Engineer. Kurzer Piep = „hab dich gehört“. Antwort geht durch die normale
        Funk-Disziplin (Fahrlehrer-Kommandos und Spotter haben Vorrang); zu späte Antworten werden verworfen."""
        i18n._local.lang = reply_lang            # neuer Thread: Antwortsprache der Frage übernehmen
        self.bank.play("beep1")
        self.pace.hold(10)                           # KI denkt nach -> solange keine Kommandos
        t0 = time.time()
        try:
            ctx = self._engineer_context()
        except Exception as e:
            print("Engineer-Kontext:", e)
            ctx = "(keine Live-Daten)"
        res = self.engineer.ask(ctx, audio_wav=audio, text=question)
        self.ai_view = {"t": time.strftime("%H:%M:%S"), "ms": self.engineer.last_ms, "error": self.engineer.last_error,
                        "answer": res[1] if res else ""}
        self.testlog.write("ki", ms=self.engineer.last_ms, fehler=self.engineer.last_error, antwort=res[1] if res else None)
        if res is None:
            self._say_reply(T("ai_offline"))
            print("KI-Engineer:", self.engineer.last_error)
            return
        lang, text = res
        if lang == "cmd":                            # KI hat einen festen Befehl erkannt -> Otto antwortet exakt
            ok = text in set(i18n.commands("de").values()) | {"gap:place", "gap:number"} or \
                re.fullmatch(r"(gap|catch):(place|number):\d+", text)
            if ok:
                self.ai_view["answer"] = f"→ Befehl {text}"
                i18n._local.lang = None
                return self.handle_command(text, "Otto gap" if lang == "en" else "")   # englisch gefragt -> englisch
            text = "SAY_AGAIN"
        if text == "SAY_AGAIN":
            self._say_reply(T("say_again"))
            return
        if time.time() - t0 > 9:
            return                                   # viel zu spät – passt nicht mehr zur Fahrsituation
        self.coach.last_msg = text
        self.coach.history = (getattr(self.coach, "history", []) + [f"{time.strftime('%H:%M:%S')} [KI] {text}"])[-12:]
        self.pace.hold(15)
        self.speaker.say(text, max_age=8, lang=lang or None, reply=True)

    def _engineer_context(self) -> str:
        """Alle Live-Daten als kompakter Text für die KI – inklusive vorberechneter Werte (Tempo, Aufholen, Sprit),
        damit die KI rechnet nicht selbst rechnen muss."""
        r = self.reader
        with self.lock:
            laps, best, delta, s = list(self.laps), self.best_ms, self.delta_ms, self.sample
        L = []
        add = L.append
        fmt = lambda x: f"{int(x // 60)}:{x % 60:06.3f}" if x else "-"
        add(f"Fahrer: {self.settings.get('user_name') or '-'} · Sprache Otto: {i18n.LANG} · Session: {self._info or '-'} · Klasse: {self.car_class or '-'}")
        si = r.session_info() if r and hasattr(r, "session_info") else None
        if si:
            kind = "Rennen" if si["race"] else ("Qualifying" if 5 <= si["session"] <= 8 else "Training")
            tl = si.get("time_left")
            add(f"Session-Typ: {kind} · Restzeit: {round(tl / 60, 1) if tl is not None and 0 <= tl < 86400 else '-'} min"
                f" · Max. Runden: {si.get('max_laps') or '-'} · meine Runden: {si['laps_done']} · Phase: {si['phase']}"
                f" · Gelbphase-Status: {si['yellow']} · blaue Flagge für mich: {si['blue']} · in Box: {si['in_pits']}")
            add(f"Wetter: Luft {si['air']:.0f} °C, Strecke {si['track']:.0f} °C, Regen {si['raining']:.2f}, "
                f"Nässe {si['wet']:.2f}, Wolken {si['cloud']:.2f}")
        my = [l["time_ms"] / 1000 for l in laps]
        add(f"Meine letzten Runden: {', '.join(fmt(x) for x in my[-6:]) or '-'} · Bestzeit Session: {fmt(best / 1000) if best else '-'}"
            f" · Delta live: {delta / 1000 if delta is not None else '-'} s · aktuelles Tempo (Median sauberer Runden): "
            f"{fmt(self._typical_lap_s(laps)) if self._typical_lap_s(laps) else '-'}")
        info = r.race_info() if r and hasattr(r, "race_info") else None
        if info:
            per = self._fuel_per_lap()
            add(f"Position gesamt: P{info['place']} von {info['cars']} · Sprit: {info['fuel']:.1f} l"
                + (f" · Verbrauch {per:.2f} l/Runde · reicht ca. {info['fuel'] / per:.1f} Runden" if per and info.get('fuel') else ""))
        ty = r.tyres() if r and hasattr(r, "tyres") else None
        if ty:
            w = ty["wheels"]
            ts = self.tyre_watch.status()
            add("Reifen (VL, VR, HL, HR): Temp " + ", ".join(f"{x['temp']:.0f}" for x in w) + " °C · Druck "
                + ", ".join(f"{x['press']:.0f}" for x in w) + " kPa · Abnutzung " + ", ".join(f"{x['wear']:.0f}" for x in w)
                + " % · Bremsen " + ", ".join(f"{x['brake']:.0f}" for x in w) + " °C"
                + f" · Fenster Reifen ca. {tyrelib.TYRE_COLD:.0f}-{tyrelib.TYRE_OK_MAX:.0f} °C"
                + (f" · warm in ca. {ts['eta_s']:.0f} s" if ts and ts.get('eta_s') else ""))
        try:
            sr = self._session_reader()
            pre = self._pre_race(sr)
            if pre and (pre["before_start"] or not laps):
                add(f"VOR DEM RENNEN – Startreifen-Rechnung von Otto: {self._start_text(sr, laps)} · Schätzwerte Reifen-Haltbarkeit "
                    f"(min, normale Temperatur): {tyrelib.LIFE_MIN} · gemessener Verschleiß %/Runde: {self._wear_rates() or '-'}"
                    " · Bei einer anderen genannten Renndauer: mit diesen Werten neu rechnen (Soft schnellster, Hard haltbarster).")
        except Exception:
            pass
        try:
            rr = self.race_log.report(laps, T, voice.say_time, final=self.race_log.reported)
            if rr:
                add("Rennen bisher (Ottos Rennbericht): " + rr)
        except Exception:
            pass
        if self.damage_watch.incident:
            inc = self.damage_watch.incident
            add(f"SCHADEN seit Runde {inc['lap']}: Karosserie {inc['dents']} (8 Stellen, 0-2), Reifenschaden {inc['flat']}, "
                f"Rad ab {inc['wheel_off']}, Motor überhitzt {inc['overheat']} · Engineer-Empfehlung: "
                f"{self._damage_text(r, laps, info) or '-'}")
        # vorberechnete Engineer-Antworten (verlässliche Zahlen)
        for kind, label in (("ahead", "Vordermann (meine Klasse)"), ("behind", "Hintermann (meine Klasse)")):
            try:
                add(f"{label} – Aufhol-Rechnung: {self._catch_text(r, kind)}")
            except Exception:
                pass
        if self.settings.get("friend_name") and self.friend_view:
            add(f"Kumpel ({self.friend_view['name']}): {self._friend_text(self.friend_view)}")
        if getattr(self.coach, "issues", None) or getattr(self.coach, "last_issues", None):
            add("Größte Zeitverluste letzte Runde: " + self.coach.where_summary())
        # Stand aller Autos mit Tempo
        if r and hasattr(r, "rivals_table"):
            rows = r.rivals_table()
            if rows:
                add("Stand (Platz | Klasse | Name | Abstand zur Spitze | Runden zurück | letzte | beste | Tempo | Box | Stopps):")
                for x in rows[:30]:
                    pace = self._pace(x["id"])
                    add(f"P{x['place']} | {x['cls']} | {x['name']}{' (ICH)' if x['me'] else ''} | {x['gap']:.1f}s | {x['laps']}"
                        f" | {fmt(x['last'])} | {fmt(x['best'])} | {fmt(pace)} | {'ja' if x['pits'] else '-'} | {x['stops']}")
        return "\n".join(L)

    def _tyre_text(self, reader, laps) -> str:
        """Renningenieur-Antwort zu den Reifen: Fenster, Erwärmung („in etwa 2 Runden warm“), Druck, Abnutzung."""
        ty = reader.tyres() if reader and hasattr(reader, "tyres") else None
        if not ty:
            return T("no_tyres")
        w = ty["wheels"]
        r1 = lambda k: [None if x.get(k) is None else round(x[k], 1) for x in w]
        print("Reifen-Abfrage · Innenschicht:", r1("inner"), "· Kern:", r1("core"), "· Oberfläche:", r1("surface"))
        f, r = (w[0]["temp"] + w[1]["temp"]) / 2, (w[2]["temp"] + w[3]["temp"]) / 2
        dec = lambda x: f"{x:.1f}".replace(".0", "").replace(".", f" {T('point')} ")
        # voller Satz pro Rad: „Vorne links 75 Grad, vorne rechts 74 Komma 3, …“
        wheels = T("tyres_each", fl=dec(w[0]["temp"]), fr=dec(w[1]["temp"]), rl=dec(w[2]["temp"]), rr=dec(w[3]["temp"]))
        extra = T("tyres_press", pf=dec((w[0]["press"] + w[1]["press"]) / 200), pr=dec((w[2]["press"] + w[3]["press"]) / 200)) \
            + " " + T("tyres_wear2", w=round(max(x["wear"] for x in w)))
        ts = self.tyre_watch.status()
        if min(f, r) < tyrelib.TYRE_COLD:
            txt = T("tyres_cold2") + " " + wheels + " " + T("tyres_grip_from", c=round(tyrelib.TYRE_COLD))
            eta = ts["eta_s"] if ts else None
            if eta:
                lap = self._typical_lap_s(laps) or 0
                txt += " " + (T("eta_laps", n=max(1, round(eta / lap))) if lap > 20 and eta > 75 else T("eta_s", s=max(5, round(eta / 5) * 5)))
            else:
                txt += " " + T("tyres_push")
            return txt
        if max(f, r) > tyrelib.TYRE_HOT:
            return T("tyres_hot2") + " " + wheels + " " + extra
        return T("tyres_ok2") + " " + wheels + " " + extra

    def _stint(self, reader, laps):
        """(Restrunden, Streckentemperatur, nass?, max. Abnutzung %, aktuelle Mischung)"""
        si = reader.session_info() if reader and hasattr(reader, "session_info") else None
        ty = reader.tyres() if reader and hasattr(reader, "tyres") else None
        lap_s = self._typical_lap_s(laps) or (si or {}).get("est_lap") or 0
        left = None
        if si:
            tl = si.get("time_left")
            if si.get("max_laps") and (tl is None or tl > 86400):
                left = max(0, si["max_laps"] - si["laps_done"])
            elif tl is not None and 0 < tl < 86400 and lap_s > 20:
                left = tl / lap_s + 1
        wet = bool(si and (si["raining"] > 0.15 or si["wet"] > 0.35))
        wear = max((w["wear"] for w in ty["wheels"]), default=0) if ty else None
        return left, (si or {}).get("track"), wet, wear, (ty or {}).get("compound", "")

    def _compound_text(self, reader, laps, question: str = "") -> str:
        """Renningenieur-Empfehlung für die Reifenmischung (Soft / Medium / Hard / Wet) mit kurzer Begründung."""
        left, track, wet, wear, cur = self._stint(reader, laps)
        if left is None and track is None:
            return T("no_session")
        n = round(left) if left else None
        if wet:
            rec, why = "Wet", T("why_wet")
        elif cur.lower().startswith("wet") and not wet:
            rec, why = "Medium", T("why_dry")
        elif n is not None and n <= 8:
            rec, why = "Soft", T("why_short", n=n)
        elif track is not None and track > 38:
            rec, why = "Hard", T("why_hot", t=round(track))
        elif n is not None and n > 25:
            rec, why = "Hard", T("why_long", n=n)
        else:
            rec, why = "Medium", T("why_mid", n=n if n else T("some"))
        q = (question or "").lower()
        asked = next((c for c in ("Soft", "Medium", "Hard", "Wet") if c.lower() in q or (c == "Wet" and "regen" in q)), None)
        name = lambda c: T("wet_name") if c == "Wet" else c
        if asked and asked != rec:
            txt = T("comp_not", rec=name(rec), asked=name(asked))
        elif cur and cur.lower().startswith(rec.lower()):
            txt = T("comp_stay", rec=name(rec))
        else:
            txt = T("comp_take", rec=name(rec))
        txt += " " + why
        if wear is not None and wear > 60:
            txt += " " + T("comp_worn", w=round(wear))
        return txt

    def _pit_text(self, reader, laps, info) -> str:
        """Box ja/nein: reicht der Sprit bis ins Ziel, wann spätestens rein, wie sehen die Reifen aus?"""
        left, _, wet, wear, cur = self._stint(reader, laps)
        per = self._fuel_per_lap()
        if not info or info.get("fuel") is None or not per:
            return T("pit_nodata")
        fuel_laps = info["fuel"] / per
        if fuel_laps < 1.5:
            return T("pit_now", n=max(0, int(fuel_laps)))
        if wet and cur and not cur.lower().startswith("wet"):
            return T("pit_wets")
        if left is not None and fuel_laps >= left:
            txt = T("pit_stay_end")
            if wear is not None and wear > 70:
                txt += " " + T("pit_worn", w=round(wear))
            return txt
        return T("pit_later", n=int(fuel_laps))

    def _damage_verdict(self, reader, laps, info) -> dict:
        """Reparieren ja/nein: Zeitverlust pro Runde × Restrunden gegen Boxenstopp + Reparatur."""
        left = self._stint(reader, laps)[0]
        per = self._fuel_per_lap()
        stop_needed = None
        if left is not None and per and info and info.get("fuel") is not None:
            stop_needed = info["fuel"] / per < left
        track = (self._info or "").partition(" @ ")[2]
        return self.damage_watch.verdict(laps, left, stop_needed, self._lap_hist,
                                         self.race_log.pit_lane(track), self.race_log.repair_per_level())

    def _damage_text(self, reader, laps, info, always: bool = False) -> str:
        v = self._damage_verdict(reader, laps, info)
        k = v["kind"]
        inc = self.damage_watch.incident
        if k == "none":
            return T("dmg_none") if always else ""
        if v.get("why") == "wheel":
            w = next(i for i in range(4) if inc["wheel_off"][i] or inc["flat"][i])
            return T("dmg_wheel" if inc["wheel_off"][w] else "dmg_flat", w=T(f"wheel{w}"))
        if v.get("why") == "engine":
            return T("dmg_overheat")
        sev = T(f"sev{max(1, v['sev'])}")
        if k == "wait":
            return T("dmg_wait", s=sev)
        num = lambda x: f"{x:.1f}".replace(".0", "").replace(".", f" {T('point')} ")
        txt = T("dmg_loss_est" if v.get("estimated") else "dmg_loss", s=sev, l=num(max(0.0, v["loss"]))) + " "
        if v.get("why") == "handling":               # oft neben der Strecke seit dem Unfall
            return txt + T("dmg_handling")
        if k == "stay" and v.get("why") == "no_loss":
            return T("dmg_noloss", s=sev)
        if k == "practice":
            return txt + T("dmg_practice")
        g, c = round(v["gain"]), round(v["cost"])
        return txt + {"box_now": T("dmg_box_now", g=g, c=c), "box_next": T("dmg_box_next", g=g, c=c),
                      "stay": T("dmg_stay", g=g, c=c)}[k]

    def _update_damage(self, si):
        """Unfall erkennen und sofort melden; nach der ersten vollen Runde danach: reparieren ja/nein."""
        r, dw = self.reader, self.damage_watch
        d = r.damage() if r and hasattr(r, "damage") else None
        laps = list(self.laps)                      # läuft in der Daten-Schleife, self.lock ist schon gesperrt
        events = dw.update(d, self._last_lap, laps, bool(si and si.get("in_pits")))
        for kind, val in events:
            if kind in ("dents", "flat", "wheel_off"):
                self.race_log.incident(self._last_lap, val if kind == "dents" else 3)
        if not self.settings.get("damage_alerts", True):
            return d
        say = lambda t: self.coach.say(t, max_age=6)
        for kind, val in events[:2]:
            if kind in ("flat", "wheel_off"):
                say(T("dmg_flat" if kind == "flat" else "dmg_wheel", w=T(f"wheel{val}")))
            elif kind == "overheat":
                say(T("dmg_overheat"))
            elif kind == "dents":
                # im Gedränge (Start) nur schweren Schaden sofort melden – leichte Rempler kommen mit der Rechnung
                if val >= 3 or not self.spotter.crowded:
                    say(T(f"dmg_hit{val}"))
            elif kind == "parts":
                say(T("dmg_parts"))
            elif kind == "repaired":
                say(T("dmg_repaired"))
        inc = dw.incident
        s = self.sample
        if inc and s and not (si and si.get("in_pits")):
            dw.estimate(self._last_lap, s.lap_pos, self.delta_ms, laps, self.best_ms)
        measured = dw.loss(laps)[1] >= 1
        # Empfehlung sagen: hochgerechnet schon in der Unfallrunde (schwerer Schaden -> keine ganze Runde mehr),
        # nach der ersten vollen Runde nochmal – aber nur, wenn sich die Empfehlung dadurch ändert
        if inc and (measured or inc.get("est") is not None) and not (si and si.get("in_pits")):
            info = r.race_info() if hasattr(r, "race_info") else None
            v = self._damage_verdict(r, laps, info)
            if v["kind"] not in ("wait", "none") and (not inc["said_verdict"] or (measured and not inc.get("said_measured")
                                                                                  and v["kind"] != inc["said_kind"])):
                inc["said_verdict"], inc["said_kind"] = True, v["kind"]
                inc["said_measured"] = inc.get("said_measured") or measured
                self.race_log.incident_loss(v.get("loss"))
                txt = self._damage_text(r, laps, info)
                if txt:
                    self.coach.say(txt, max_age=15)
            elif measured:
                inc["said_measured"] = True
        return d

    def _testlog_tick(self, si, d):
        """1x pro Sekunde die LMU-Rohwerte ins Test-Protokoll (nur Entwickler-Version, nur beim Fahren)."""
        r, s = self.reader, self.sample
        if not self.testlog.enabled:
            return
        heard = list(getattr(self.listener, "heard", []))          # alles Gehörte, auch nicht Verstandenes
        for h in heard:
            if h not in self._heard_logged:
                self.testlog.write("gehoert", text=h)
        self._heard_logged = set(heard)
        if not s or getattr(r, "no_record", False):              # Simulator: Sprache ja, Fahrdaten nicht
            return
        e = {"runde": self._last_lap, "pos": round(s.lap_pos, 3), "kmh": round(s.speed_kmh)}
        if si:
            tl = si.get("time_left")
            e.update(session=si.get("session"), phase=si.get("phase"), zeit_rest=None if tl is None else round(tl),
                     ziel=si.get("finished"), runden_max=si.get("max_laps"))
            e.update(box=si.get("in_pits"), sektor=si.get("my_sector"), flaggen=si.get("sector_flags"),
                     runde_zaehlt=si.get("count_lap"), platz=si.get("place"), klassenplatz=si.get("class_place"),
                     blau=si.get("blue"), regen=round(si.get("raining", 0), 2))
            if any(f == 1 for f in (si.get("sector_flags") or [])) and hasattr(r, "slow_ahead"):
                e["langsam_voraus_m"] = r.slow_ahead()
        try:
            ty = r.tyres() if hasattr(r, "tyres") else None
            if ty:
                w = ty["wheels"]
                e["reifen"] = {"innen": [None if x.get("inner") is None else round(x["inner"], 1) for x in w],
                               "kern": [None if x.get("core") is None else round(x["core"], 1) for x in w],
                               "oberflaeche": [round(x.get("surface", x["temp"]), 1) for x in w],
                               "otto": [round(x["temp"], 1) for x in w], "mischung": ty.get("compound"),
                               "abnutzung": [round(x["wear"], 1) for x in w], "bremse": [round(x["brake"]) for x in w]}
            ri = r.race_info() if hasattr(r, "race_info") else None
            if ri:
                e["lmu_abstand_vorne"] = None if ri.get("ahead_s") is None else round(ri["ahead_s"], 2)
            e["verkehr"] = [{k: x.get(k) for k in ("cls", "number", "dir", "gap", "t", "dist")} for x in self.traffic_view[:2]]
        except Exception as ex:
            e["fehler"] = str(ex)
        if d and (sum(d["dents"]) or any(d["flat"]) or d["overheating"]):
            e["schaden"] = {k: d[k] for k in ("dents", "flat", "wheel_off", "overheating", "detached")}
        self.testlog.write("daten", **e)

    def _update_race_log(self, si, d):
        """Rennen mitschreiben; nach der Zielflagge den Rennbericht sagen und speichern."""
        if not si:
            return
        rl = self.race_log
        spd = self.sample.speed_kmh if self.sample else 0.0
        rl.update(si, self._last_lap, spd, sum(d["dents"]) if d else 0, self.laps)
        # Zielflagge für mich ODER Session vorbei (Phase 8) – Testfahrt: der Bericht kam am Ende nicht
        over = si.get("finished") or si.get("phase") == 8 or \
            (si.get("in_pits") and si.get("time_left") is not None and si["time_left"] <= 0)   # nach Zeitende in die Box
        if si.get("race") and over and not rl.reported and rl.start_place is not None:
            rl.reported = True
            txt = rl.report(self.laps, T, voice.say_time, final=True)
            if txt:
                rl.save(rl.report(self.laps, T, voice.say_time, final=True, spoken=False))
                if self.settings.get("race_report", True):
                    self.coach.say(txt, max_age=30)

    def _brake_text(self, reader) -> str:
        ty = reader.tyres() if reader and hasattr(reader, "tyres") else None
        if not ty:
            return T("no_tyres")
        w = ty["wheels"]
        b = max(w[0]["brake"], w[1]["brake"])
        each = T("brakes_each", fl=round(w[0]["brake"]), fr=round(w[1]["brake"]), rl=round(w[2]["brake"]), rr=round(w[3]["brake"]))
        kind = tyrelib.brake_kind(self.car_class)
        cold, ok, hot = tyrelib.BRAKES[kind]
        if b < cold:
            return T("brakes_cold", b=round(b), c=round(cold)) + " " + each
        if b > hot:
            return T("brakes_hot", b=round(b)) + " " + each
        if b > ok:
            return T("brakes_warm", b=round(b)) + " " + each
        return T("brakes_ok", b=round(b)) + " " + each

    def _my_lap_times(self) -> list[float]:
        return [l["time_ms"] / 1000 for l in self.laps if l.get("valid", True)]

    def _time_left_text(self, si: dict, laps: list) -> str:
        """„Noch 12 Minuten, etwa 7 Runden“ bzw. „Noch 5 Runden“."""
        if si.get("max_laps") and (si["time_left"] is None or si["time_left"] > 86400):
            return T("laps_left", n=max(0, si["max_laps"] - si["leader_laps"]))
        tl = si.get("time_left")
        if tl is None or tl > 86400:
            return T("no_session")
        if tl <= 0:
            return T("time_over")
        txt = T("time_left", m=round(tl / 60)) if tl >= 90 else T("time_left_s", s=round(tl))
        lap_s = self._typical_lap_s(laps) or (si.get("est_lap") or 0)
        if lap_s > 20:
            txt += T("laps_est", n=int(tl // lap_s) + 1)
        return txt

    def _typical_lap_s(self, laps: list) -> float | None:
        ts = sorted(l["time_ms"] for l in laps[-6:] if l.get("valid", True))
        return ts[len(ts) // 2] / 1000 if ts else None

    def _friend_text(self, d: dict) -> str:
        n = d["name"].split()[0] if d["name"] else "?"
        num = lambda x: f"{x:.1f}".replace(".", f" {T('point')} ")
        if d.get("in_pits"):
            return T("friend_pits", n=n)
        parts = []
        if d["race"] and d.get("gap_s") is not None:
            parts.append(T("gap_behind_you" if d["gap_s"] > 0 else "gap_ahead_of_you", who=n, s=num(abs(d["gap_s"]))))
        elif d["race"] and d.get("laps_diff"):
            parts.append(T("gap_laps_behind" if d["laps_diff"] > 0 else "gap_laps_ahead", who=n, n=abs(d["laps_diff"])))
        elif d.get("track_m") is not None:
            parts.append(T("friend_track", n=n, m=abs(d["track_m"]), w=T("w_ahead") if d["track_m"] > 0 else T("w_behind")))
        if d.get("best"):
            t = voice.say_time(d["best"] * 1000)
            parts.append(T("gap_best", who=n, t=t, d=voice.say_delta((d["my_best"] - d["best"]) * 1000))
                         if d.get("my_best") else T("gap_best_only", who=n, t=t))
        return ". ".join(parts) or T("gap_nobest", who=n)

    @staticmethod
    def _my_sessions(track: str, cls: str | None) -> list[dict]:
        """Eigene Sessions auf dieser Strecke – nur aus der eigenen Fahrzeugklasse (Multiclass!):
        Wer GT3 fährt, darf nie die Bremspunkte oder die Bestzeit eines Hypercars vorgesetzt bekommen.
        Aufnahmen ohne bekannte Klasse zählen nur, wenn auch die aktuelle Klasse unbekannt ist (AC/ACC)."""
        from .progress import overview
        t = next((t for t in overview()["tracks"] if t["track"].strip() == track.strip()), None)
        if not t:
            return []
        return [x for x in t["sessions"] if x.get("cls") == cls and x.get("best_ms")]

    def _load_pace_reference(self, track: str, cls: str | None = None):
        """Fahrlehrer-Vorlage: beste gespeicherte Runde auf dieser Strecke in derselben Fahrzeugklasse."""
        try:
            from .sessions import load_laps
            ss = self._my_sessions(track, cls)
            if not ss:
                return
            s = min(ss, key=lambda s: s["best_ms"])
            lap = min((l for l in load_laps(s["file"]) if l["valid"]), key=lambda l: l["time_ms"])
            with self.lock:
                if self._info.partition(" @ ")[2] != track:
                    return                                   # inzwischen andere Session
                if self._pace_ms is None or lap["time_ms"] < self._pace_ms:
                    self.pace.set_reference(lap["data"], f"Bestzeit {fmt_ms(lap['time_ms'])} vom {s['date'][8:10]}.{s['date'][5:7]}."
                                            + (f" ({cls})" if cls else ""))
                    self._pace_ms = lap["time_ms"]
                if self._alltime_ms is None or lap["time_ms"] < self._alltime_ms:
                    self._alltime_ms = lap["time_ms"]      # bisheriger persönlicher Streckenrekord (in dieser Klasse)
        except Exception as e:
            print("Fahrlehrer-Vorlage nicht geladen:", e)

    def _greet(self, info: str, cls: str | None = None):
        """Begrüßung bei neuer Session, mit bisheriger Bestzeit auf dieser Strecke in dieser Klasse (falls bekannt)."""
        track = info.partition(" @ ")[2] or info
        best = None
        try:
            ss = self._my_sessions(track, cls)
            best = min(x["best_ms"] for x in ss) if ss else None
        except Exception:
            pass
        self.coach.greet(track, best)

    def _update_traffic(self):
        """2x pro Sekunde: Verkehr fürs Overlay + automatische Warnung vor langsameren Klassen
        (bzw. vor schnelleren Klassen, die von hinten kommen)."""
        now = time.time()
        if now - self._traffic_t < 0.5:
            return
        self._traffic_t = now
        r = self.reader
        try:        # weit vorausschauen: angezeigt/gewarnt wird nach Zeitabstand (≤ 8 s), nicht nach Einholzeit
            tr = r.traffic(horizon_s=900, max_dist=1e9) if r and hasattr(r, "traffic") else []
        except TypeError:
            tr = r.traffic()
        if not self.settings["traffic_same_class"]:
            tr = [x for x in tr if not x["same_class"]]
        # Zeiten pro Auto glätten (Tempo schwankt beim Bremsen/Beschleunigen -> Anzeige sprang)
        sm = self._traffic_smooth
        for x in tr:
            x.setdefault("gap", x["t"])
            old = sm.get(x["id"])
            if old is not None and abs(old[0] - x["t"]) < 15 and old[2] == x["dir"]:
                x["t"] = old[0] + 0.3 * (x["t"] - old[0])
                x["gap"] = old[1] + 0.3 * (x["gap"] - old[1])
            sm[x["id"]] = (x["t"], x["gap"], x["dir"])
        for gone in set(sm) - {x["id"] for x in tr}:
            sm.pop(gone)
        # Overlay & Warnung nach Zeitabstand (wie das LMU-HUD: „2 s vor dir“), nicht nach Einholzeit
        tr.sort(key=lambda x: x["gap"])
        self.traffic_view = [{**x, "cls_name": i18n.class_name(x["cls"])} for x in tr[:2] if x["gap"] <= 8]
        if not self.settings["traffic_alerts"]:
            return
        # Gedränge (Start) oder jemand neben dir: das ist Sache des Spotters – keine Verkehrsansage obendrauf
        if self.spotter.crowded or self.spotter.left or self.spotter.right:
            return
        if now - self._alerted.get("_any", 0) < 8:          # nie eine Verkehrsansage nach der anderen
            return
        new = [x for x in tr if 0.6 <= x["gap"] <= 2.5 and now - self._alerted.get(x["id"], 0) >= 45]
        if not new:
            return
        x = min(new, key=lambda y: y["gap"])
        g = round(x["gap"])
        g = T("sec_1") if g <= 1 else T("sec_n", s=g)
        # ein ganzer Pulk von hinten (Testfahrt: 4 Hypercars in 2 s) -> EINE Ansage
        group = [y for y in tr if y["dir"] == x["dir"] and y["gap"] <= x["gap"] + 3]
        for y in group + [x]:
            self._alerted[y["id"]] = now
        self._alerted["_any"] = now
        if x["dir"] == "behind" and len(group) >= 2:
            self.coach.say(T("tr_group_behind", n=len(group), c=i18n.class_name(x["cls"]), t=g), max_age=2.5)
            return
        c = i18n.class_name(x["cls"]) + (T("tr_num", n=int(x["number"])) if x.get("number") else "")
        self.coach.say(T("tr_alert", t=g, c=c) if x["dir"] == "ahead" else T("tr_alert_behind", c=c, t=g), max_age=2.5)

    def _update_spotter(self, s):
        """„Auto links / rechts / Frei“ – sofort aus der Sound-Bank (hat Vorrang vor allem anderen)."""
        r = self.reader
        if not self.settings.get("spotter", True) or not r or not hasattr(r, "nearby"):
            self.spotter.view = {"left": False, "right": False}
            return
        try:
            nb = r.nearby(230.0)          # weiter nach hinten schauen: „schnelles Auto von hinten“
        except TypeError:
            nb = r.nearby()
        except Exception as e:
            print("Spotter:", e)
            nb = None
        # Wiedereinfädeln erkennen – nur dann warnt der Spotter vor schnellen Autos von hinten:
        # neben der Strecke (Kiesbett, Wiese) oder viel langsamer als die Vorlage an dieser Stelle (Dreher, Schaden)
        ref_v = self.pace.ref_speed(s.lap_pos)
        off = abs(s.track_edge) > 2 and abs(s.path_lateral) > abs(s.track_edge) + 0.5
        now = time.time()
        self._off_since = (self._off_since or now) if off else None
        slow = ((ref_v is not None and ref_v > 100 and s.speed_kmh < 0.5 * ref_v) or (ref_v is None and s.speed_kmh < 40)) \
            and s.lap > 1 and not self.spotter.crowded          # Start/erste Runde: alle langsam, kein Dreher
        # nur ein echter Ausflug zählt (Testfahrt: kurz mit zwei Rädern drüber bei vollem Tempo ist ungefährlich):
        # mindestens 1 s neben der Strecke ODER dabei deutlich langsamer als die Vorlage
        real_off = off and (now - self._off_since >= 1.0 or (ref_v is not None and s.speed_kmh < 0.7 * ref_v))
        if real_off or slow:
            self.spotter.rejoin_until = max(self.spotter.rejoin_until, now + (6 if real_off else 4))
        # nach einem Unfall mitzählen, wie oft du neben die Strecke kommst (Auto schwer fahrbar?)
        inc = self.damage_watch.incident
        if off and not self._off_prev and inc and inc.get("m0") is not None:
            inc["offs"] = inc.get("offs", 0) + 1
        self._off_prev = off
        corner = self.pace.next_corner(s.lap_pos, s.speed_kmh)
        events = self.spotter.update(nb[0], nb[1], s.speed_kmh, corner=corner) if nb \
            else self.spotter.update((s.x, s.y, s.z), [], 0)
        for code in events[:1]:
            self.bank.play(code)

    def _update_live_info(self):
        """1x pro Sekunde: Kumpel beobachten (Bestzeit, Box, Überholen), blaue Flagge, Restzeit-Ansagen."""
        now = time.time()
        lv = self._live
        if now - lv["t"] < 1.0:
            return
        lv["t"] = now
        r, st = self.reader, self.settings
        say = lambda t, age=6: self.coach.say(t, max_age=age)
        si = r.session_info() if r and hasattr(r, "session_info") else None
        if si:
            # blaue Flagge (Multiclass: schnellere Klasse will vorbei) – höchstens alle 25 s
            if si["blue"] and st.get("flag_alerts", True) and now - lv["blue_t"] > 25:
                lv["blue_t"] = now
                say(T("blue"), 3)
            # lokale gelbe Flaggen pro Sektor (rF2-Reihenfolge: Index 0 = Sektor 3, 1 = Sektor 1, 2 = Sektor 2)
            # Nur melden, was dich betrifft: Gelb in deinem oder im nächsten Sektor, mindestens 2 s lang,
            # UND wirklich ein langsames/stehendes Auto vor dir (wer nur zurück auf die Strecke fährt, ist keine Gefahr)
            if st.get("flag_alerts", True) and si.get("realtime", True) and not si["in_pits"]:
                flags = list(si.get("sector_flags") or [])
                yel = {n for idx, n in ((1, 1), (2, 2), (0, 3)) if idx < len(flags) and flags[idx] == 1}
                my = {1: 1, 2: 2, 0: 3}.get(si.get("my_sector"), 1)
                mine = {n for n in yel if (n - my) % 3 in (0, 1)}
                if mine:
                    lv["yellow_since"] = lv.get("yellow_since") or now
                else:
                    lv["yellow_since"] = None
                    if lv.get("yellow_said"):
                        lv["yellow_said"] = False
                        say(T("yellow_clear"), 4)
                # Testfahrt 3: Gelb stand 200 s in Sektor 2, aber kein Auto war unter 45 km/h -> Otto sagte nie etwas.
                # Jetzt: immer ansagen (einmal pro Gelbphase), mit Entfernung, wenn ein langsames Auto zu sehen ist
                if mine and now - lv["yellow_since"] >= 2 and not lv.get("yellow_said") and now - lv.get("yellow_t", 0) > 8:
                    dist = r.slow_ahead(slow_kmh=70) if hasattr(r, "slow_ahead") else None
                    lv["yellow_t"], lv["yellow_said"] = now, True
                    n = min(mine, key=lambda x: (x - my) % 3)
                    if dist is not None:
                        say(T("yellow_close") if dist < 150 else T("yellow_dist", m=int(round(dist, -1 if dist < 500 else -2))), 4)
                    else:
                        say(T("yellow_here") if n == my else T("yellow_next", n=n), 4)
            # Rennen auf Zeit: „Noch 10 / 5 Minuten“, „Zeit um – letzte Runde“
            tl = si.get("time_left")
            if lv.get("sess") != si.get("session"):           # neue Session (Training -> Rennen): Ansagen wieder frei
                lv["sess"], lv["warned"] = si.get("session"), set()
            # nur bei grüner Flagge (Testfahrt: vor dem Start kam schon „Die Zeit ist um“)
            if si["race"] and si.get("phase", 5) in (5, 6) and tl is not None and 0 < tl + 5 < 86400 \
                    and st.get("time_alerts", True):
                for mark in (600, 300, 0):
                    if tl <= mark and mark not in lv["warned"]:
                        lv["warned"].add(mark)
                        if tl > mark - 30:                  # nicht nachträglich, wenn man später dazukommt
                            say(T("time_over") if mark == 0 else T("min_warn", m=mark // 60))
                        break
        d = self._update_damage(si)
        self._update_race_log(si, d)
        self._testlog_tick(si, d)
        if si:
            # Boxenausfahrt: die nächsten 12 s empfindlich vor schnellen Autos von hinten warnen
            if lv.get("in_pits") and not si.get("in_pits"):
                self.spotter.rejoin_until = now + 12
            lv["in_pits"] = si.get("in_pits")
            # Track Limits: LMU erklärt die Runde mitten in der Runde für ungültig (mCountLapFlag 2 -> 1/0)
            # Testfahrt 12.10.: LMU setzt das Flag bei einer Track-Limits-Verwarnung nur 1–2 s auf „zählt nicht“ und
            # dann wieder zurück – das ist KEINE gestrichene Runde. Erst wenn es mindestens 3 s so bleibt.
            cl, ln = si.get("count_lap"), si.get("lap_no")
            prev = lv.get("count")
            if cl is not None and prev and prev[1] == ln and prev[0] == 2 and cl < 2 and not si.get("in_pits"):
                lv["count_drop"] = (now, ln)
            drop = lv.get("count_drop")
            if drop and (cl is None or cl >= 2 or ln != drop[1]):
                lv["count_drop"] = None                      # war nur eine Verwarnung
            elif drop and now - drop[0] >= 3 and not self._lap_lmu_invalid:
                self._lap_lmu_invalid = True
                lv["count_drop"] = None
                if st.get("cut_alerts", True):
                    self.bank.play("cut_invalid")
            lv["count"] = (cl, ln)
        # Reifen/Bremsen beobachten: „Reifen sind auf Temperatur“, „vorne zu heiß“
        ty = r.tyres() if r and hasattr(r, "tyres") else None
        spd = self.sample.speed_kmh if self.sample else 0
        tw = self.tyre_watch
        if si and si.get("in_pits"):
            tw.announced_warm = False                # neuer Stint, neue Reifen
        if ty and spd > 30:
            tw.add(ty, now)
            ts = tw.status()
            if ts and st.get("tyre_alerts", True):
                if ts["cold"]:
                    tw.was_cold = True
                elif getattr(tw, "was_cold", False) and not tw.announced_warm:
                    tw.announced_warm, tw.was_cold = True, False
                    say(T("tyres_warm_now"), 8)
                if ts["hot"]:
                    tw.hot_since = tw.hot_since or now
                    if now - tw.hot_since > 20 and now - tw.hot_said > 180:
                        tw.hot_said = now
                        say(T("tyres_hot_alert", t=round(max(ts["front"], ts["rear"])),
                              a=T("front_axle") if ts["front"] >= ts["rear"] else T("rear_axle")), 8)
                else:
                    tw.hot_since = None
        # Rundenzeiten aller Autos merken (Tempo-Vergleich für „Kann ich ihn einholen?“)
        snap = r.lap_snapshot() if r and hasattr(r, "lap_snapshot") else {}
        hist = self._lap_hist
        for cid, (n, last, in_pits) in snap.items():
            h = hist.setdefault(cid, {"n": n, "laps": []})
            if n != h["n"]:
                if last > 0 and n == h["n"] + 1:
                    h["laps"] = (h["laps"] + [(last, in_pits or h.get("pit", False))])[-6:]
                h["n"] = n
                h["pit"] = in_pits
            elif in_pits:
                h["pit"] = True                      # Runde mit Boxenstopp -> zählt nicht fürs Tempo
        # Kumpel
        name = st.get("friend_name", "").strip()
        d = r.driver_info(name) if name and r and hasattr(r, "driver_info") else None
        self.friend_view = d
        prev, lv["friend"] = lv["friend"], d
        if not d or not prev or not st.get("friend_alerts", True):
            return
        n = d["name"].split()[0] if d["name"] else name
        if d["in_pits"] != prev["in_pits"]:
            say(T("friend_pits", n=n) if d["in_pits"] else T("friend_out", n=n))
        elif d["best"] and (not prev["best"] or d["best"] < prev["best"] - 0.001):
            t = T("friend_best", n=n, t=voice.say_time(d["best"] * 1000))
            if d.get("my_best") and d["same_class"]:
                t += T("friend_vs", d=voice.say_delta((d["my_best"] - d["best"]) * 1000))
            say(t, 15)
        elif d["race"] and not d["in_pits"] and d["place"] != prev["place"]:
            was_ahead, is_ahead = prev["place"] < prev["my_place"], d["place"] < d["my_place"]
            if was_ahead and not is_ahead:
                say(T("passed_friend", n=n), 4)
            elif is_ahead and not was_ahead:
                say(T("friend_passed", n=n), 4)

    def _update_sectors(self):
        """F1-Farben: lila = Session-Bestzeit im Sektor, grün = besser als letzte Runde, gelb = langsamer."""
        r = self.reader
        sec = r.sectors() if r and hasattr(r, "sectors") else None
        if not sec:
            self.sector_view = None
            return
        S = self._sec
        if sec["last"] and sec["last"] != S["seen"]:          # Runde abgeschlossen
            S["seen"] = sec["last"]
            S["before"] = S["prev"]                            # Runde davor (Vergleich für die eben beendete)
            S["prev"] = list(sec["last"])
            S["best"] = [x if b is None else min(b, x) for b, x in zip(S["best"], sec["last"])]

        def color(i, t, compare):
            if S["best"][i] is None or t <= S["best"][i] + 1e-6:
                return "purple"
            return "green" if compare and compare[i] and t < compare[i] else "yellow"

        if sec["in"] == 0 and sec["last"] and not sec["cur"][0]:
            # gerade in Sektor 1: die eben beendete Runde komplett zeigen (wie im TV)
            view = [{"t": t, "c": color(i, t, S["before"]), "active": False} for i, t in enumerate(sec["last"])]
        else:
            view = [{"t": t, "c": color(i, t, S["prev"]) if t else None, "active": sec["in"] == i}
                    for i, t in enumerate(sec["cur"][:2] + [None])]
        self.sector_view = view

    def _race_info_cached(self):
        """Platz/Abstände fürs Overlay (aus dem schon gelesenen Scoring, kostet nichts)."""
        r = self.reader
        try:
            return r.race_info() if r and self.sample and hasattr(r, "race_info") else None
        except Exception:
            return None

    def _fuel_now(self):
        info = self.reader.race_info() if self.reader and hasattr(self.reader, "race_info") else None
        return info.get("fuel") if info else None

    def _fuel_per_lap(self):
        f = [x for x in self._fuel_log if x > 0]
        return (sum(f) / len(f)) if f else None

    def set_source(self, source: str):
        with self.lock:
            self.source = source
            self._reset()

    # ---------- Aufnahme Start/Stopp ----------
    def toggle_recording(self) -> bool:
        with self.lock:
            self.rec_on = not self.rec_on
            if not self.rec_on:
                self.recorder.stop()      # Datei abschließen; nächster Start = neue Datei
            on = self.rec_on
        _beep(on)
        return on

    def set_auto_record(self, value: bool):
        with self.lock:
            self.settings["auto_record"] = bool(value)
            settings.save(self.settings)

    def _reset(self):
        self.recorder.stop()
        self.reader = None
        self.sample = None
        self._info = None
        self.laps, self.best_ms, self.best_trace = [], None, None
        self.cur_trace = ([], [])
        self.path = []                # alle Positionen der Session (für die Karte)
        self.delta_ms, self._last_lap, self._last_time = None, None, 0
        self._lap_off_max = 0.0
        self._lap_start_speed = 0.0
        self._cur = {k: [] for k in COACH_KEYS}   # aktuelle Runde komplett (für den Coach)
        self._fuel_log, self._lap_fuel_start = [], None
        self.coach.ref = None
        self.coach.new_lap()
        self._sec = {"seen": None, "prev": [None] * 3, "before": [None] * 3, "best": [None] * 3}
        self.sector_view = None

    def _pick_reader(self):
        if self.source == "sim":
            return self._sim
        if self.source == "devsim":                   # LMU-Simulator der Entwickler-Version (tools/devsim.py)
            return getattr(self, "_devsim", None)
        for r in self._real:
            if r.read():
                return r
        return None

    def _loop(self):
        while True:
            try:
                self._tick()
            except Exception as e:                   # nie still sterben: melden, kurz warten, weiter
                import traceback
                print("Fehler in der Datenschleife:", e)
                traceback.print_exc()
                with self.lock:
                    self.reader, self.sample = None, None
                time.sleep(1.0)

    def _tick(self):
        if True:
            with self.lock:
                if self.reader is None:
                    self.reader = self._pick_reader()
                s = self.reader.read() if self.reader else None
                self._count_rate(s is not None)
                if s:
                    self._process(s)
                    self.sample, self._last_ok = s, time.time()
                elif time.time() - self._last_ok > 0.6:
                    # einzelne verworfene Messungen (Spiel schreibt gerade) nicht als „getrennt“ melden –
                    # erst nach 0,6 s ohne Daten (Pause, Menü, Spiel zu)
                    self.sample = None
                idle = self.reader is None
                reader = self.reader
            # Fahrerliste für „Abstand zu …“-Befehle alle 5 s aktualisieren (nur bei Änderung)
            if reader is not None and hasattr(reader, "drivers") and time.time() - self._targets_t > 5:
                self._targets_t = time.time()
                ds = reader.drivers()
                sig = tuple((d["name"], d["number"], d["place"]) for d in ds)
                if sig != self._targets_sig:
                    self._targets_sig = sig
                    self.listener.set_targets(ds)
            # kein Spiel gefunden -> nur 1x pro Sekunde suchen statt 30x (spart CPU)
            time.sleep(1.0 if idle else 1 / HZ)

    def _count_rate(self, ok: bool):
        """Datenrate fürs Overlay/Bug-Bericht: saubere Datensätze pro Sekunde und Anteil verworfener Lesungen."""
        st = self._rate
        st["ok" if ok else "bad"] += 1
        now = time.time()
        if now - st["t"] >= 2.0:
            n = st["ok"] + st["bad"]
            self.rates = {"data_hz": round(st["ok"] / (now - st["t"]), 1), "drop_pct": round(100 * st["bad"] / n) if n else 0}
            if self.reader is not None and now - st.get("log_t", 0) > 60:
                st["log_t"] = now
                print(f"Daten: {self.rates['data_hz']}/s, verworfen {self.rates['drop_pct']} %")
            st.update(ok=0, bad=0, t=now)

    def _process(self, s):
        info = self.reader.info()
        if info != self._info and info != "?":   # neue Session / anderes Auto / andere Strecke
            self._post_session()                 # vorherige Session nach Discord (falls aktiviert)
            self.laps, self.best_ms, self.best_trace = [], None, None
            self._info = info
            self.coach.track = info.partition(" @ ")[2]
            self.coach.ref, self.coach.pending = None, {}
            self.pace.events, self.pace.source, self._pace_ms, self._alltime_ms = [], "", None, None
            self.pace._ref = None                # sonst zeigt das Overlay Pedal-Markierungen der alten Strecke
            # alles, was zur vorherigen Strecke/Session gehört, zurücksetzen
            self._sec = {"seen": None, "prev": [None] * 3, "before": [None] * 3, "best": [None] * 3}
            self.sector_view, self.delta_ms = None, None
            self._alerted, self._traffic_smooth, self.traffic_view = {}, {}, []
            self._live, self.friend_view = {"t": 0.0, "friend": None, "blue_t": 0.0, "warned": set()}, None
            self._lap_hist = {}
            self.spotter.reset()
            self.tyre_watch.reset()
            self.damage_watch.reset()
            self.cur_trace, self.path = ([], []), []
            self._last_lap = None
            # Fahrzeugklasse (LMU-Multiclass) – Vorlage, Begrüßung und Rekord nur aus derselben Klasse
            cls = self.reader.player_class() if hasattr(self.reader, "player_class") else None
            self.car_class = i18n.class_name(cls) if cls else None
            threading.Thread(target=self._load_pace_reference, args=(self.coach.track, self.car_class), daemon=True).start()
            self.recorder.stop()
            if self.settings["greeting"]:
                threading.Thread(target=self._greet, args=(info, self.car_class), daemon=True).start()
            if self.settings["auto_record"]:
                self.rec_on = True
        if self.rec_on and self._info and not getattr(self.reader, "no_record", False):
            if not self.recorder.active:
                self.recorder.start(self.reader.name, self._info)
            self.recorder.write(s)
            cars = self.reader.cars() if hasattr(self.reader, "cars") else None
            if cars:
                self.recorder.write_cars(*cars)

        if self._last_lap is not None and s.lap != self._last_lap:
            self._finish_lap()
        if s.lap != self._last_lap:
            self._lap_start_speed = s.speed_kmh
            self._lap_lmu_invalid = False
            self._lap_off_max = 0.0
            self._cur = {k: [] for k in COACH_KEYS}
            self.coach.new_lap()
            fuel = self._fuel_now()
            if fuel is not None and self._lap_fuel_start is not None and self._lap_fuel_start > fuel:
                self._fuel_log = (self._fuel_log + [self._lap_fuel_start - fuel])[-5:]
            self._lap_fuel_start = fuel
        for k in COACH_KEYS:
            self._cur[k].append(getattr(s, k))
        self.coach.on_sample(self._cur, s.lap_pos, s.speed_kmh)
        self.pace.on_sample(s.lap_pos, s.speed_kmh)
        self._update_sectors()
        self._update_traffic()
        self._update_live_info()
        self._update_spotter(s)
        if abs(s.track_edge) > 2:   # wie weit über den Streckenrand (nur LMU)
            self._lap_off_max = max(self._lap_off_max, abs(s.path_lateral) - abs(s.track_edge))
        self._last_lap = s.lap
        self._last_time = s.lap_time_ms
        if s.lap_pos >= 0:
            self.cur_trace[0].append(s.lap_pos)
            self.cur_trace[1].append(s.lap_time_ms)
        if not self.path or (s.x - self.path[-1][0]) ** 2 + (s.z - self.path[-1][1]) ** 2 > 16:
            self.path.append((s.x, s.z))
            if len(self.path) > 6000:
                del self.path[:1000]
        d = self._delta(s)
        # leicht glätten, damit die Anzeige ruhig bleibt
        self.delta_ms = d if d is None or self.delta_ms is None else self.delta_ms + 0.2 * (d - self.delta_ms)

    def _finish_lap(self):
        pos, times = self.cur_trace
        t = self._last_time
        if t >= MIN_LAP_MS:
            # "vollständig" = von Start/Ziel bis Start/Ziel gefahren (nicht aus der Box gestartet)
            full = is_full_lap(pos) and self._lap_start_speed > 40
            if full:  # Hänger vom Rundenanfang entfernen, damit das Delta sauber sortiert ist
                k = next(i for i, p in enumerate(pos) if p < 0.5)
                pos, times = pos[k:], times[k:]
            # gültig: eigene Prüfung (Streckenrand) UND LMU hat die Runde nicht gestrichen
            valid = full and self._lap_off_max < OFF_INVALID_M and not self._lap_lmu_invalid
            prev_best = self.best_ms
            is_best = valid and (self.best_ms is None or t < self.best_ms)
            if is_best:
                # nur vorwärts laufende Punkte – kleine Rücksprünge der Position machten die
                # Delta-Suche (bisect) falsch und ließen das Delta springen
                mp, mt, last = [], [], -1.0
                for p_, t_ in zip(pos, times):
                    if p_ > last:
                        mp.append(p_); mt.append(t_); last = p_
                self.best_ms, self.best_trace = t, (mp, mt)
                self.coach.set_reference(self._cur)
                if self._pace_ms is None or t < self._pace_ms:      # schneller als die Vorlage -> neue Vorlage
                    self.pace.set_reference(dict(self._cur), f"deine Bestzeit heute ({fmt_ms(t)})")
                    self._pace_ms = t
            self.coach.on_lap_done(t, valid, prev_best, self._lap_off_max >= OFF_MIN_M)
            # Überraschung: schneller als alles, was je auf dieser Strecke gefahren wurde -> Fanfare
            if valid and self._alltime_ms is not None and t < self._alltime_ms:
                car, _, track = (self._info or "").partition(" @ ")
                if not getattr(self.reader, "no_record", False):      # Simulator: nichts nach Discord
                    discord.post_record(track, car.split(" #")[0], t, self._alltime_ms,
                                        [x["t"] for x in self.sector_view] if self.sector_view else None)
                self._alltime_ms = t
                self._pb_flash_until = time.time() + 8
                self.bank.play("fanfare")
                self.coach.say(T("pb", name=self.coach._name()), max_age=10)
            self.laps.append({"lap": self._last_lap, "time_ms": t, "best": is_best, "full": full,
                              "valid": valid, "off": self._lap_off_max >= OFF_MIN_M})
            self._log_wear()
        self.cur_trace = ([], [])

    def _log_wear(self):
        """Reifenverschleiß pro Runde je Mischung merken (für die Startreifen-Empfehlung)."""
        ty = self.reader.tyres() if self.reader and hasattr(self.reader, "tyres") else None
        if not ty:
            return
        c = (ty.get("compound") or "").split()[0].capitalize() if ty.get("compound") else ""
        w = max(x["wear"] for x in ty["wheels"])
        prev = self._wear_prev
        if prev and prev[0] == c and 0 < w - prev[1] < 15:
            log = self._wear_log.setdefault(c, [])
            log[:] = (log + [w - prev[1]])[-8:]
            if len(log) >= 3:              # dauerhaft merken (Strecke + Klasse + Mischung)
                self.race_log.learn_wear(self._track(), self.car_class, c, sorted(log)[len(log) // 2])
        self._wear_prev = (c, w)

    def _track(self) -> str:
        return (self._info or "").partition(" @ ")[2]

    def _wear_rates(self, track: str | None = None, cls: str | None = None) -> dict:
        """Verschleiß %/Runde je Mischung: heute gemessen, sonst aus früheren Sessions auf dieser Strecke."""
        rates = self.race_log.wear_for(track or self._track(), cls or self.car_class)
        rates.update({c: sorted(v)[len(v) // 2] for c, v in self._wear_log.items() if len(v) >= 3})
        return rates

    def _session_reader(self):
        """Reader für Session-Fragen – auch in der Garage/im Menü, wenn noch keine Fahrdaten kommen."""
        if self.reader is not None:
            return self.reader
        with self.lock:
            for r in self._real:
                if hasattr(r, "pre_race_info"):
                    try:
                        r._read_scoring()
                        if r.pre_race_info():
                            return r
                    except Exception:
                        pass
        return None

    def _pre_race(self, reader) -> dict | None:
        """Session-Daten, wenn wir vor dem Start stehen (Garage, Startaufstellung, noch keine Runde im Rennen)."""
        pi = reader.pre_race_info() if reader and hasattr(reader, "pre_race_info") else None
        if not pi:
            return None
        pi["before_start"] = pi["race"] and (pi["phase"] < 5 or (pi["laps_done"] == 0 and pi["in_pits"]))
        return pi

    def _start_text(self, reader, laps, question: str = "") -> str:
        """„Mit welchen Reifen starte ich?“ – aus Renndauer, Rundenzeit, Tankreichweite, Strecke, Wetter."""
        pi = self._pre_race(reader)
        if not pi:
            return T("no_session")
        race_s, race_laps = (pi["time_left"], pi["max_laps"]) if pi["race"] else (None, None)
        if race_s is not None and race_s < 120:
            race_s = None                         # Testfahrt: vor dem Start meldet LMU ~0 s Restzeit -> unbekannt
        if race_s:
            race_laps = None                      # Zeitrennen (Rundenlimit ist dann meist nur ein Platzhalter)
        # Dauer aus der Frage („… für 45 Minuten / 1 Stunde / 20 Runden“) hat Vorrang
        q = question.lower().replace("anderthalb", "1.5").replace("eine stunde", "1 stunde").replace("an hour", "1 hour")
        m = re.search(r"(\d+(?:[.,]\d+)?)\s*(min|minute|minuten|minutes|h|std|stunde|stunden|hour|hours|runden|laps|lap)\b", q)
        if m:
            n = float(m.group(1).replace(",", "."))
            u = m.group(2)
            race_s, race_laps = ((n * 60, None) if u.startswith("min") else (None, int(n)) if u in ("runden", "laps", "lap")
                                 else (n * 3600, None))
        if not race_s and not race_laps:
            return T("st_unknown")
        lap_s = self._typical_lap_s(laps)
        if not lap_s and pi.get("class_best"):
            lap_s = pi["class_best"] * 1.01
        if not lap_s:
            try:
                ss = self._my_sessions(pi["track_name"], self.car_class)
                lap_s = min(x["best_ms"] for x in ss) / 1000 * 1.02 if ss else None
            except Exception:
                lap_s = None
        lap_s = lap_s or pi.get("est_lap")
        if not lap_s:
            return T("st_nolap")
        per = self._fuel_per_lap()
        fuel_laps = pi["fuel_cap"] / per if per and pi.get("fuel_cap") else None
        wet = pi["raining"] > 0.15 or pi["wet"] > 0.35
        cls = self.car_class or (i18n.class_name(pi["cls"]) if pi.get("cls") else None)
        plan = tyrelib.start_plan(race_s, race_laps, lap_s, fuel_laps, pi.get("track"), wet,
                                  self._wear_rates(pi.get("track_name"), cls))
        if not plan:
            return T("st_unknown")
        if plan["rec"] == "Wet":
            return T("st_wet")
        dur = T("st_dur_min", m=round(race_s / 60)) if race_s else T("st_dur_laps", n=plan["laps"])
        txt = T("st_rec", c=plan["rec"]) + " " + dur + (T("st_laps", n=plan["laps"]) if race_s else "") + "."
        stops = plan["stints"] - 1
        txt += " " + (T("st_nostop") if not stops else T("st_stops1", s=plan["stint_laps"]) if stops == 1
                      else T("st_stops", n=stops, s=plan["stint_laps"]))
        life = plan["life"][plan["rec"]]
        harder = {"Soft": "Medium", "Medium": "Hard"}.get(plan["rec"], "Medium")
        txt += " " + {"all": T("st_why_all", c=plan["rec"]), "double": T("st_why_double", c=plan["rec"], k=plan["k"]),
                      "short": T("st_why_short"), "only": T("st_why_only", c=plan["rec"]), "fast_stint": T("st_why_fast", c=plan["rec"], n=life, h=harder),
                      "cold": T("st_why_cold", t=round(pi["track"] or 0))}[plan["why"]]
        if not fuel_laps and plan["stints"] > 1:
            txt += " " + T("st_fuel_guess")
        return txt

    def _delta(self, s):
        if not self.best_trace or s.lap_pos < 0:
            return None
        pos, times = self.best_trace
        i = bisect.bisect_left(pos, s.lap_pos)
        if i <= 0 or i >= len(pos):
            return None
        f = (s.lap_pos - pos[i - 1]) / ((pos[i] - pos[i - 1]) or 1)
        return s.lap_time_ms - (times[i - 1] + f * (times[i] - times[i - 1]))

    def _mic_name(self) -> str:
        if time.time() - getattr(self, "_mic_t", 0) > 5:          # nicht bei jeder Abfrage Windows fragen
            self._mic_t, self._mic = time.time(), voice.default_mic()
        return self._mic

    def overlay_state(self) -> dict:
        """Nur was das Overlay anzeigt (klein -> schnell übertragen, 20x pro Sekunde)."""
        with self.lock:
            s = self.sample
            fr = self.friend_view
            return {
                "t": time.time(),
                "s": {"lap_time_ms": s.lap_time_ms, "brake": round(s.brake, 3), "throttle": round(s.throttle, 3)} if s else None,
                "delta_ms": self.delta_ms,
                "pb": time.time() < self._pb_flash_until,
                "ref": self.pace.ref_pedals(s.lap_pos) if s else None,
                "race": self._race_info_cached(),
                "sectors": self.sector_view,
                "traffic": (self.traffic_view[:1] if s else []),
                "friend": ({k: fr.get(k) for k in ("name", "in_pits", "gap_s", "track_m")} if fr else None),
                "spot": dict(self.spotter.view),
                "pace": ({**self.pace.next, "text": T(self.pace.next["code"])} if self.pace.next and s else None),
                "rates": dict(self.rates),
                "lock": bool(self.settings.get("overlay_lock")),
            }

    def state(self) -> dict:
        with self.lock:
            return {
                "connected": self.sample is not None,
                "game": self.reader.name if self.reader else None,
                "info": self._info,
                "source": self.source,
                "sample": asdict(self.sample) if self.sample else None,
                "delta_ms": self.delta_ms,
                "best_ms": self.best_ms,
                "laps": self.laps[-30:],
                "rec_on": self.rec_on,
                "recording": self.recorder.path.name if self.recorder.active else None,
                "auto_record": self.settings["auto_record"],
                "coach_msg": self.coach.last_msg,
                "heard": self.listener.last,
                "mic": {"device": self.settings.get("mic_device") or self._mic_name(),
                        "level": self.listener.mic_level() if self.listener.running else 0,
                        "note": ((self.listener.capture.error if self.listener.capture is not None and self.listener.capture.error else "")
                                 or (getattr(self.listener, "signal_note", "") if time.time() - getattr(self.listener, "_signal_t", 0) < 8 else "")),
                        "heard": list(getattr(self.listener, "heard", [])[-3:])},
                "listening": self.listener.running,
                "learning_button": self.learning_button,
                "pace_next": ({**self.pace.next, "text": T(self.pace.next["code"])} if self.pace.next else None),
                "race": self._race_info_cached(),
                "sectors": self.sector_view,
                "traffic": self.traffic_view if self.sample else [],
                "ref_pedals": self.pace.ref_pedals(self.sample.lap_pos) if self.sample else None,
                "overlay_opacity": self.settings.get("overlay_opacity", 0.8),
                "pb_flash": time.time() < self._pb_flash_until,
                "pace_source": self.pace.source,
                "pace_events": len(self.pace.events),
                "voice_error": self.listener.error or self.listener.note,
                "voice": {k: self.settings[k] for k in settings.VOICE_KEYS},
                "voice_dl": dict(neural.DL),          # Download einer natürlichen Stimme (Fortschritt/Fehler)
                "friend": self.friend_view,
                "spot": dict(self.spotter.view),
                "rates": {**self.rates, "overlay_fps": self.overlay_fps[0] if time.time() - self.overlay_fps[1] < 6 else None},
                "ai": self.ai_view, "ai_ready": self.engineer.ready,      # Spotter fürs Overlay: Auto links/rechts neben dir           # Kumpel live (Platz, Abstand, Bestzeit) – oder None
                "drivers": [d["name"] for d in (self.reader.drivers() if self.reader and hasattr(self.reader, "drivers") else [])
                            if not d["player"] and d["name"]][:60],
                "voice_natural": self.speaker.voice.startswith("piper:") and neural.installed(self.speaker.voice[6:]),
            }

    def _post_session(self, sync: bool = False):
        if self._info and self.laps and not getattr(self.reader, "no_record", False):
            car, _, track = self._info.partition(" @ ")
            discord.post_session(track, car.split(" #")[0], list(self.laps), self.best_ms, sync=sync)

    def bug_context(self) -> dict:
        """Was ein Bug-Bericht automatisch mitschickt (keine persönlichen Daten außer dem Anzeigenamen)."""
        st = self.settings
        return {
            "Version": f"{ver.display()} (Build {paths.version()})", "Spiel": self.reader.name if self.reader else "—",
            "Modus": st["coach_mode"], "Sprache": st["lang"],
            "Session": self._info or "—", "Hören": f"{st['listen_mode']} · Weckwort „{st['assistant_name']}“"
                                                  + (f" · {self.listener.note}" if self.listener.note else ""),
            "Letzte Ansagen": "\n".join(getattr(self.coach, "history", [])[-8:]) or "—",
            "Zuletzt verstanden": "\n".join(getattr(self.listener, "heard", [])[-6:]) or "—",
            "Datenrate": f"{self.rates['data_hz']}/s, verworfen {self.rates['drop_pct']} %, Overlay {self.overlay_fps[0]}/s",
        }

    def shutdown(self):
        try:
            self.listener.stop()                     # Spracherkennung sauber beenden (sonst .NET-Fehler beim Schließen)
        except Exception:
            pass
        with self.lock:
            self.recorder.stop()
        t = threading.Thread(target=self._post_session, args=(True,))   # Session-Zusammenfassung beim Schließen
        t.start()
        t.join(6)

    def track_data(self) -> dict:
        with self.lock:
            p = self.path
            step = max(1, len(p) // 1500)
            return {"track": [(round(x, 1), round(z, 1)) for x, z in p[::step]]}
