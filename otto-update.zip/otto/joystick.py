"""Lenkrad-/Controller-Knöpfe lesen (Windows-Joystick-API winmm, bis 32 Knöpfe pro Gerät).
Wird für „Knopf drücken, dann sprechen“ benutzt. Funktioniert parallel zum Spiel (nur lesen)."""
import ctypes
import threading
import time
from ctypes import wintypes

_winmm = ctypes.WinDLL("winmm")
JOY_RETURNBUTTONS = 0x80
JOYERR_NOERROR = 0


class JOYINFOEX(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("dwXpos", wintypes.DWORD), ("dwYpos", wintypes.DWORD), ("dwZpos", wintypes.DWORD),
                ("dwRpos", wintypes.DWORD), ("dwUpos", wintypes.DWORD), ("dwVpos", wintypes.DWORD),
                ("dwButtons", wintypes.DWORD), ("dwButtonNumber", wintypes.DWORD),
                ("dwPOV", wintypes.DWORD), ("dwReserved1", wintypes.DWORD), ("dwReserved2", wintypes.DWORD)]


class JOYCAPSW(ctypes.Structure):
    _fields_ = [("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("szPname", wintypes.WCHAR * 32),
                ("_rest", ctypes.c_byte * 600)]   # Rest der Struktur wird nicht gebraucht


def device_name(joy: int) -> str:
    caps = JOYCAPSW()
    if _winmm.joyGetDevCapsW(joy, ctypes.byref(caps), ctypes.sizeof(caps)) == JOYERR_NOERROR:
        return caps.szPname or f"Gerät {joy + 1}"
    return f"Gerät {joy + 1}"


def _buttons(joy: int) -> int | None:
    info = JOYINFOEX()
    info.dwSize = ctypes.sizeof(info)
    info.dwFlags = JOY_RETURNBUTTONS
    return info.dwButtons if _winmm.joyGetPosEx(joy, ctypes.byref(info)) == JOYERR_NOERROR else None


class ButtonWatcher:
    """Meldet jeden neuen Knopfdruck aller angeschlossenen Controller an on_press(joy, button)."""

    def __init__(self, on_press):
        self.on_press = on_press
        self._prev: dict[int, int] = {}
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        devices, last_scan = [], 0.0
        while True:
            now = time.time()
            if now - last_scan > 3:          # alle 3 s nach neuen Geräten suchen
                devices = [j for j in range(16) if _buttons(j) is not None]
                last_scan = now
            for j in devices:
                b = _buttons(j)
                if b is None:
                    continue
                new = b & ~self._prev.get(j, 0)
                self._prev[j] = b
                for i in range(32):
                    if new & (1 << i):
                        try:
                            self.on_press(j, i)
                        except Exception as e:
                            print("Knopf-Fehler:", e)
            time.sleep(0.02)
