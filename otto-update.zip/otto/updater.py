"""Updates für die installierte Otto.exe.

Aufbau der Installation:
    Otto\\Otto.exe        Starter (Python, Fenster, Sprache – ändert sich praktisch nie)
    Otto\\app\\           der eigentliche Otto-Code (wird per Update ersetzt)
    Otto\\app_update\\    vorbereitetes Update (wird beim nächsten Start übernommen)
Nutzerdaten liegen woanders (%LOCALAPPDATA%\\Otto) und werden nie angefasst.

Zwei Wege: Update-Datei (otto-update-<version>.zip) auswählen, oder online prüfen (update_url zeigt
auf eine kleine JSON-Datei: {"version": "...", "url": "...zip", "sha256": "...", "notes": "..."})."""
import hashlib
import json
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path
from .paths import CODE, version

FROZEN = getattr(sys, "frozen", False) or CODE.name == "app"
DEFAULT_URL = "https://raw.githubusercontent.com/primahut/otto-updates/main/otto-update.json"
ROOT = CODE.parent                      # Installationsordner (neben Otto.exe)
STAGE = ROOT / "app_update"


def _ver(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except ValueError:
        return (0,)


def _check_zip(zf: zipfile.ZipFile) -> str:
    names = set(zf.namelist())
    if "VERSION" not in names or "app.py" not in names or not any(n.startswith("otto/") for n in names):
        raise ValueError("Das ist keine Otto-Update-Datei.")
    return zf.read("VERSION").decode().strip()


def stage_zip(path: str) -> dict:
    """Update-Datei prüfen und für den nächsten Start bereitlegen."""
    if not FROZEN:
        return {"ok": False, "msg": "Updates gibt es nur in der installierten Otto.exe (hier läuft die Entwickler-Version)."}
    with zipfile.ZipFile(path) as zf:
        new = _check_zip(zf)
        if _ver(new) <= _ver(version()):
            return {"ok": False, "msg": f"Version {new} ist nicht neuer als die installierte ({version()})."}
        shutil.rmtree(STAGE, ignore_errors=True)
        zf.extractall(STAGE)
    return {"ok": True, "version": new, "msg": f"Update auf {new} ist bereit – Otto neu starten."}


def check_online(url: str, install: bool = True) -> dict:
    """Online nach neuer Version schauen und (optional) herunterladen + bereitlegen."""
    url = url or DEFAULT_URL
    with urllib.request.urlopen(url + ("&" if "?" in url else "?") + "t=" + str(int(__import__("time").time())),
                                timeout=8) as r:                   # ?t=… -> nie eine alte, zwischengespeicherte Info
        info = json.loads(r.read().decode("utf-8"))
    if _ver(info["version"]) <= _ver(version()):
        return {"ok": True, "latest": True, "msg": f"Otto ist aktuell ({version()})."}
    if not install:
        name, notes = info.get("name") or info["version"], info.get("notes", "")
        if notes.startswith(f"Otto {name} – "):          # steht für alte Otto-Versionen vorne drin
            notes = notes[len(f"Otto {name} – "):]
        return {"ok": True, "latest": False, "version": name, "notes": notes}
    tmp = ROOT / "update_download.zip"
    with urllib.request.urlopen(info["url"], timeout=60) as r:
        tmp.write_bytes(r.read())
    if info.get("sha256") and hashlib.sha256(tmp.read_bytes()).hexdigest() != info["sha256"].lower():
        tmp.unlink(missing_ok=True)
        return {"ok": False, "msg": "Download beschädigt (Prüfsumme falsch) – nichts installiert."}
    res = stage_zip(str(tmp))
    tmp.unlink(missing_ok=True)
    if res["ok"]:
        res["notes"] = info.get("notes", "")
    return res

# Übernommen wird ein bereitgelegtes Update vom Starter (tools/otto_launcher.py) beim nächsten Start.
