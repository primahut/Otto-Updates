"""Spotter: „Auto links!“ / „Auto rechts!“ / „Drei nebeneinander!“ / „Frei!“ – wie ein Spotter am Funk.

Aus den Weltpositionen aller Autos (LMU-Telemetrie, ~30x pro Sekunde abgefragt):
- Fahrtrichtung = eigene Bewegung der letzten Zehntelsekunde (unabhängig davon, wie das Spiel seine
  Drehmatrix speichert).
- Links/rechts: In LMU zeigt „links“ in Weltkoordinaten (x, z) auf (-f.z, f.x) – aus eigenen Aufnahmen
  bestimmt (in Linkskurven dreht die Fahrtrichtung immer in diese Richtung).
- Werte angelehnt an CrewChief (bewährter Spotter für rFactor 2 / LMU): Autolänge ~4,5–5 m, seitlich
  mindestens eine Autobreite (sonst fährt es genau vor/hinter dir), Annäherung unter 12 m/s
  (schnelle Multiclass-Überholer meldet die Verkehrs-Ansage), Brücken über Höhenunterschied raus.
Ansagen nur bei Änderungen, mit kurzer Bestätigungszeit gegen Fehlalarme.

Dazu wie ein echter Spotter:
- „Immer noch da“ alle paar Sekunden, solange jemand neben dir bleibt
- „Auto direkt hinter dir“, wenn einer an deinem Heck klebt
- „Achtung, schnelles Auto von hinten“ – nur beim Wiedereinfädeln (Boxenausfahrt, nach einem Ausflug
  ins Kiesbett, nach einem Dreher), wenn von hinten einer mit viel Tempo kommt
- Mann gegen Mann vor einer Kurve: „Er ist innen, bleib außen“ / „Du bist innen, lass außen Platz“
  (Kurvenrichtung aus der Vorlage der Pace-Notes, auch wenn der Fahrlehrer aus ist)
- Gedränge (Start, erste Kurve: 3+ Autos im Umkreis von 30 m): nur noch links/rechts/drei breit/frei"""
import math
import time

CAR_LEN = 4.8        # m – Überlappung in Längsrichtung (Hypercar ~5,0 m, GT3 ~4,6 m)
CLEAR_LEN = 5.4      # m – erst ab hier gilt ein Auto wieder als „nicht mehr neben dir“ (Hysterese)
CAR_WIDTH = 1.7      # m – seitlich näher = fährt genau vor/hinter dir
LAT_MAX = 6.0        # m – weiter seitlich = andere Spur / anderer Streckenteil
MAX_DY = 3.0         # m – Höhenunterschied (Brücken, übereinanderliegende Streckenteile)
MAX_CLOSING = 12.0   # m/s – schnellere Annäherung = Überholvorgang einer anderen Klasse
CONFIRM_S = 0.08     # so lange muss ein Auto neben dir sein, bevor Otto es ansagt
CLEAR_S = 0.5        # so lange muss alles frei sein, bevor „Frei“ kommt
CLEAR_CROWD_S = 0.9  # ... im Gedränge länger (sonst „Frei – Auto links – Frei“ im Sekundentakt)
MIN_SPEED = 36       # km/h – darunter (Box, Start, Dreher) schweigt der Spotter für links/rechts
STILL_FIRST = 1.8    # „Immer noch da“ zum ersten Mal so lange nach „Auto links/rechts“ (Testfahrt: 3,5 s war zu spät)
STILL_S = 2.5        # ... danach alle 2,5 s, solange jemand neben dir ist
CROWD_N, CROWD_R = 3, 30.0   # so viele Autos im Umkreis von 30 m = Gedränge (Start, erste Kurve)
CROWD_HOLD = 4.0     # s – Gedränge-Modus hält noch so lange nach
BEHIND_LON = (-11.0, -4.6)   # m – „klebt am Heck“: so weit hinter dir, genau in deiner Spur
BEHIND_S = 1.2       # ... so lange schon
BEHIND_EVERY = 40.0  # s – höchstens so oft pro Auto
FAST_RANGE = 220.0   # m – so weit nach hinten schauen für „schnelles Auto von hinten“
FAST_LAT = 7.0       # m – seitlich näher = auf deiner Linie bzw. Strecke
FAST_TTC = 5.0       # s – warnen, wenn es in weniger als 5 s bei dir ist (Testfahrt: 3,5 s kam zu spät)
FAST_REJOIN = 6.0    # m/s Annäherung, die beim Wiedereinfädeln reicht (Box, Kiesbett, Dreher, viel zu langsam)
# Im normalen Rennen gibt es KEINE „schnelles Auto“-Warnung mehr: Testfahrt 12.10. – beim Anbremsen jeder Kurve
# kommt der Hintermann schnell näher, das war nur Lärm. Die Engine setzt rejoin_until, wenn du wirklich wieder
# auf die Strecke kommst (Boxenausfahrt, neben der Strecke, Dreher / weit unter dem Tempo der Vorlage).
TACTIC_WINDOW = (0.8, 3.5)   # s vor dem Bremspunkt: Tipp für nebeneinander in die Kurve


class Spotter:
    def __init__(self):
        self.reset()

    def reset(self):
        self._hist = []                       # eigene Positionen (t, x, z) der letzten ~0,3 s
        self._prev = {}                       # Auto-ID -> (t, Längsabstand) für die Annäherungsgeschwindigkeit
        self._over = {}                       # Auto-ID -> (Seite, Längsabstand), solange es neben mir ist
        self.left = self.right = False        # zuletzt angesagter Zustand
        self._since = {"left": None, "right": None, "none": None}
        self.view = {"left": False, "right": False}   # fürs Overlay (ohne Verzögerung)
        self._f = None                        # letzte bekannte Fahrtrichtung (auch wenn ich fast stehe)
        self._rate = {}                       # Auto-ID -> (t, Längsabstand, Annäherung m/s geglättet)
        self._behind_since, self._behind_said = {}, {}
        self._fast_said, self._fast_any = {}, 0.0
        self._still_t = None                  # wann zuletzt „Auto links/rechts/Immer noch da“ kam
        self._tactic_done = None              # Kurve, für die der Nebeneinander-Tipp schon kam
        self.rejoin_until = 0.0               # Engine: Boxenausfahrt / Ausflug neben die Strecke -> empfindlicher
        self.crowd_until = 0.0                # Gedränge: nur noch das Wichtigste (links/rechts/drei breit/frei)
        self._last_msg_t = 0.0                # wann zuletzt irgendeine Spotter-Meldung kam

    @property
    def crowded(self) -> bool:
        return time.time() < self.crowd_until

    def _forward(self, t: float, x: float, z: float):
        self._hist = [h for h in self._hist if t - h[0] < 0.3] + [(t, x, z)]
        t0, x0, z0 = self._hist[0]
        dx, dz = x - x0, z - z0
        d = math.hypot(dx, dz)
        return (dx / d, dz / d) if d > 1.0 else None

    def update(self, me: tuple, others: list[tuple], speed_kmh: float, t: float | None = None,
               corner: tuple | None = None) -> list[str]:
        """me = (x, y, z), others = [(id, x, y, z), …] der Autos in der Nähe.
        corner = (Kennung, Sekunden bis zum Bremspunkt, "left"/"right") der nächsten Kurve oder None.
        Ergebnis: Ansage-Codes („car_left“, „still_there“, „fast_behind“ …) – meist leer."""
        t = time.time() if t is None else t
        f = self._forward(t, me[0], me[2])
        if f is not None:
            self._f = f
        near = sum(1 for _, ox, oy, oz in others if (ox - me[0]) ** 2 + (oz - me[2]) ** 2 < CROWD_R ** 2)
        if near >= CROWD_N:
            self.crowd_until = t + CROWD_HOLD
        crowd = t < self.crowd_until
        out = []
        if self._f is not None and others:
            out += self._behind_checks(t, me, others, speed_kmh, crowd)
        if f is None or speed_kmh < MIN_SPEED:
            self._over.clear()
            self.view = {"left": False, "right": False}
            return self._stamp(t, out + self._decide(t, False, False, crowd))
        lx, lz = -f[1], f[0]                  # Einheitsvektor nach links
        seen = set()
        for cid, ox, oy, oz in others:
            seen.add(cid)
            rx, rz = ox - me[0], oz - me[2]
            lon = rx * f[0] + rz * f[1]       # + = vor mir
            lat = rx * lx + rz * lz           # + = links
            prev = self._prev.get(cid)
            self._prev[cid] = (t, lon)
            closing = abs(lon - prev[1]) / (t - prev[0]) if prev and t - prev[0] > 0.01 else 0.0
            side = "left" if lat > 0 else "right"
            ok_lat = CAR_WIDTH < abs(lat) < LAT_MAX and abs(oy - me[1]) < MAX_DY
            if cid in self._over:             # war schon neben mir: bleibt es, bis es klar vorbei ist
                if ok_lat and abs(lon) < CLEAR_LEN:
                    self._over[cid] = (side, lon)
                else:
                    self._over.pop(cid)
            elif ok_lat and -CAR_LEN - 0.4 < lon < CAR_LEN and closing < MAX_CLOSING:
                self._over[cid] = (side, lon)
        for gone in set(self._over) - seen:
            self._over.pop(gone)
        for gone in [k for k, v in self._prev.items() if t - v[0] > 2]:
            self._prev.pop(gone)
        sides = [s for s, _ in self._over.values()]
        left, right = "left" in sides, "right" in sides
        self.view = {"left": left, "right": right}
        out += self._decide(t, left, right, crowd)
        if crowd and not out:
            out += self._crowd_tactic(t, me, others, f, corner)
        out += self._still_and_tactics(t, out, corner, crowd)
        return self._stamp(t, out)

    def _crowd_tactic(self, t, me, others, f, corner) -> list[str]:
        """Gedränge vor einer Kurve (Start!): wo sind die anderen – innen oder außen? Zur freieren Seite raten."""
        if not corner or t - self._last_msg_t < 1.0:
            return []
        cid, dt, direction = corner
        if not 1.0 < dt < 4.5 or self._tactic_done == cid:
            return []
        lx, lz = -f[1], f[0]
        inside = outside = 0
        for _, ox, oy, oz in others:
            rx, rz = ox - me[0], oz - me[2]
            lon, lat = rx * f[0] + rz * f[1], rx * lx + rz * lz
            if -6 < lon < 35 and 1.2 < abs(lat) < 12 and abs(oy - me[1]) < MAX_DY:
                if (lat > 0) == (direction == "left"):
                    inside += 1
                else:
                    outside += 1
        if inside + outside < 2:
            return []
        self._tactic_done = cid
        if inside >= outside + 2:
            return ["crowd_outside"]
        if outside >= inside + 2:
            return ["crowd_inside"]
        return ["crowd_careful"]

    def _stamp(self, t, out: list[str]) -> list[str]:
        if out:
            self._last_msg_t = t
        return out

    def _behind_checks(self, t, me, others, speed_kmh, crowd=False) -> list[str]:
        """„Auto direkt hinter dir“ und „schnelles Auto von hinten“ (funktioniert auch, wenn ich fast stehe)."""
        f = self._f
        lx, lz = -f[1], f[0]
        out, seen = [], set()
        rejoin = t < self.rejoin_until            # nur beim Wiedereinfädeln vor schnellen Autos warnen
        for cid, ox, oy, oz in others:
            seen.add(cid)
            rx, rz = ox - me[0], oz - me[2]
            lon, lat = rx * f[0] + rz * f[1], rx * lx + rz * lz
            same_level = abs(oy - me[1]) < MAX_DY
            # Annäherung über mindestens 0,15 s gemessen (sonst rauscht es bei 50 Messungen pro Sekunde)
            r = self._rate.get(cid)
            if r is None or t - r[0] > 1.0:
                self._rate[cid] = (t, lon, 0.0, ox, oz, True)
                continue
            if t - r[0] >= 0.15:
                v = (lon - r[1]) / (t - r[0])             # + = kommt näher (von hinten)
                # fährt es in meine Richtung? (Gegengerade / Haarnadel daneben: Gegenrichtung -> kein Alarm)
                mx, mz = ox - r[3], oz - r[4]
                d = math.hypot(mx, mz)
                same_dir = d < 0.5 or (mx * f[0] + mz * f[1]) / d > 0.3
                self._rate[cid] = (t, lon, v if r[2] == 0.0 else r[2] + 0.5 * (v - r[2]), ox, oz, same_dir)
            rate, same_dir = self._rate[cid][2], self._rate[cid][5]
            # schnelles Auto von hinten (seitlich etwas Spielraum je weiter weg: es kann noch in der Kurve hinter mir sein)
            # weit neben der Strecke (Kiesbett) liegt die Strecke selbst 10–20 m seitlich -> viel Spielraum
            if rejoin and same_level and same_dir and -FAST_RANGE < lon < -6 and abs(lat) < 18 + 0.12 * -lon \
                    and rate > FAST_REJOIN:
                if -lon / rate < FAST_TTC and t - self._fast_said.get(cid, -99) > 20 and t - self._fast_any > 6:
                    self._fast_said[cid], self._fast_any = t, t
                    out.append("fast_behind")
            # klebt am Heck (genau in meiner Spur, nicht daneben) – nicht im Gedränge, da klebt jeder an jedem
            if not crowd and same_level and speed_kmh > 60 and BEHIND_LON[0] < lon < BEHIND_LON[1] and abs(lat) < CAR_WIDTH:
                since = self._behind_since.setdefault(cid, t)
                last = self._behind_said.get(cid)             # (wann zuletzt, wie oft „immer noch“)
                if t - since >= BEHIND_S and "fast_behind" not in out and t - self._last_msg_t > 1.2:
                    if last is None or t - last[0] > BEHIND_EVERY:
                        self._behind_said[cid] = (t, 0)
                        out.append("car_behind")
                    elif last[1] < 3 and t - last[0] >= 6 and t - since >= 6:
                        self._behind_said[cid] = (t, last[1] + 1)
                        out.append("still_behind")
            else:
                self._behind_since.pop(cid, None)
        for gone in [k for k, v in self._rate.items() if t - v[0] > 2 and k not in seen]:
            self._rate.pop(gone)
        return out[:1]

    def _still_and_tactics(self, t, said: list, corner, crowd=False) -> list[str]:
        if not (self.left or self.right):
            self._still_t = None
            return []
        if said:
            if any(c in said for c in ("car_left", "car_right", "three_wide")):
                self._still_t, self._still_n = t, 0
            return []
        if t - self._last_msg_t < 1.2:            # nie zwei Meldungen direkt hintereinander
            return []
        # nebeneinander auf eine Kurve zu: einmal pro Kurve ein Tipp – nur Mann gegen Mann, nicht im Gedränge
        if corner and self._over and not crowd and len(self._over) == 1:
            cid, dt, direction = corner
            if TACTIC_WINDOW[0] < dt < TACTIC_WINDOW[1] and self._tactic_done != cid:
                self._tactic_done = cid
                self._still_t = t
                side = next(iter(self._over.values()))[0]
                return ["stay_outside" if side == direction else "hold_inside"]
        if self._still_t is not None:
            wait = STILL_FIRST if getattr(self, "_still_n", 0) == 0 else STILL_S
            if t - self._still_t >= wait:
                self._still_t, self._still_n = t, getattr(self, "_still_n", 0) + 1
                return ["still_there"]
        return []

    def _decide(self, t: float, left: bool, right: bool, crowd: bool = False) -> list[str]:
        out = []
        for side, now in (("left", left), ("right", right)):
            if now:
                self._since[side] = self._since[side] or t
            else:
                self._since[side] = None
        conf_l = left and t - self._since["left"] >= CONFIRM_S
        conf_r = right and t - self._since["right"] >= CONFIRM_S
        if conf_l and conf_r and not (self.left and self.right):
            out.append("three_wide")
        elif conf_l and not self.left and not conf_r:
            out.append("car_left")
        elif conf_r and not self.right and not conf_l:
            out.append("car_right")
        if conf_l or conf_r:
            self.left, self.right = self.left or conf_l, self.right or conf_r
            self._since["none"] = None
        if not left and not right and (self.left or self.right):
            self._since["none"] = self._since["none"] or t
            if t - self._since["none"] >= (CLEAR_CROWD_S if crowd else CLEAR_S):
                out.append("clear")
                self.left = self.right = False
                self._since["none"] = None
        elif not left and self.left and right:
            self.left = False                 # links frei geworden, rechts noch jemand – kein „Frei“
        elif not right and self.right and left:
            self.right = False
        return out
