"""Spotter: „Auto links!“ / „Auto rechts!“ / „Drei nebeneinander!“ / „Frei!“ – wie ein Spotter am Funk.

Aus den Weltpositionen aller Autos (LMU-Telemetrie, ~30x pro Sekunde abgefragt):
- Fahrtrichtung = eigene Bewegung der letzten Zehntelsekunde (unabhängig davon, wie das Spiel seine
  Drehmatrix speichert).
- Links/rechts: In LMU zeigt „links“ in Weltkoordinaten (x, z) auf (-f.z, f.x) – aus eigenen Aufnahmen
  bestimmt (in Linkskurven dreht die Fahrtrichtung immer in diese Richtung).
- Werte angelehnt an CrewChief (bewährter Spotter für rFactor 2 / LMU): Autolänge ~4,5–5 m, seitlich
  mindestens eine Autobreite (sonst fährt es genau vor/hinter dir), Annäherung unter 12 m/s
  (schnelle Multiclass-Überholer meldet die Verkehrs-Ansage), Brücken über Höhenunterschied raus.
Ansagen nur bei Änderungen, mit kurzer Bestätigungszeit gegen Fehlalarme."""
import math
import time

CAR_LEN = 4.8        # m – Überlappung in Längsrichtung (Hypercar ~5,0 m, GT3 ~4,6 m)
CLEAR_LEN = 5.4      # m – erst ab hier gilt ein Auto wieder als „nicht mehr neben dir“ (Hysterese)
CAR_WIDTH = 1.7      # m – seitlich näher = fährt genau vor/hinter dir
LAT_MAX = 6.0        # m – weiter seitlich = andere Spur / anderer Streckenteil
MAX_DY = 3.0         # m – Höhenunterschied (Brücken, übereinanderliegende Streckenteile)
MAX_CLOSING = 12.0   # m/s – schnellere Annäherung = Überholvorgang einer anderen Klasse
CONFIRM_S = 0.08     # so lange muss ein Auto neben dir sein, bevor Otto es ansagt
CLEAR_S = 0.35       # so lange muss alles frei sein, bevor „Frei“ kommt
MIN_SPEED = 36       # km/h – darunter (Box, Start, Dreher) schweigt der Spotter


class Spotter:
    def __init__(self):
        self.reset()

    def reset(self):
        self._hist = []                       # eigene Positionen (t, x, z) der letzten ~0,3 s
        self._prev = {}                       # Auto-ID -> (t, Längsabstand) für die Annäherungsgeschwindigkeit
        self._over = {}                       # Auto-ID -> Seite ("left"/"right"), solange es neben mir ist
        self.left = self.right = False        # zuletzt angesagter Zustand
        self._since = {"left": None, "right": None, "none": None}
        self.view = {"left": False, "right": False}   # fürs Overlay (ohne Verzögerung)

    def _forward(self, t: float, x: float, z: float):
        self._hist = [h for h in self._hist if t - h[0] < 0.3] + [(t, x, z)]
        t0, x0, z0 = self._hist[0]
        dx, dz = x - x0, z - z0
        d = math.hypot(dx, dz)
        return (dx / d, dz / d) if d > 1.0 else None

    def update(self, me: tuple, others: list[tuple], speed_kmh: float, t: float | None = None) -> list[str]:
        """me = (x, y, z), others = [(id, x, y, z), …] der Autos in der Nähe.
        Ergebnis: Ansage-Codes („car_left“, „car_right“, „three_wide“, „clear“) – meist leer."""
        t = time.time() if t is None else t
        f = self._forward(t, me[0], me[2])
        if f is None or speed_kmh < MIN_SPEED:
            self._over.clear()
            self.view = {"left": False, "right": False}
            return self._decide(t, False, False)
        lx, lz = -f[1], f[0]                  # Einheitsvektor nach links
        seen = set()
        for cid, ox, oy, oz in others:
            seen.add(cid)
            rx, rz = ox - me[0], oz - me[2]
            lon = rx * f[0] + rz * f[1]       # + = vor mir
            lat = rx * lx + rz * lz           # + = links
            prev = self._prev.get(cid)
            self._prev[cid] = (t, lon)
            closing = abs(lon - prev[1]) / (t - prev[0]) if prev and t - prev[0] > 0.01 else 0.0
            side = "left" if lat > 0 else "right"
            ok_lat = CAR_WIDTH < abs(lat) < LAT_MAX and abs(oy - me[1]) < MAX_DY
            if cid in self._over:             # war schon neben mir: bleibt es, bis es klar vorbei ist
                if ok_lat and abs(lon) < CLEAR_LEN:
                    self._over[cid] = side
                else:
                    self._over.pop(cid)
            elif ok_lat and -CAR_LEN - 0.4 < lon < CAR_LEN and closing < MAX_CLOSING:
                self._over[cid] = side
        for gone in set(self._over) - seen:
            self._over.pop(gone)
        for gone in [k for k, v in self._prev.items() if t - v[0] > 2]:
            self._prev.pop(gone)
        left = "left" in self._over.values()
        right = "right" in self._over.values()
        self.view = {"left": left, "right": right}
        return self._decide(t, left, right)

    def _decide(self, t: float, left: bool, right: bool) -> list[str]:
        out = []
        for side, now in (("left", left), ("right", right)):
            if now:
                self._since[side] = self._since[side] or t
            else:
                self._since[side] = None
        conf_l = left and t - self._since["left"] >= CONFIRM_S
        conf_r = right and t - self._since["right"] >= CONFIRM_S
        if conf_l and conf_r and not (self.left and self.right):
            out.append("three_wide")
        elif conf_l and not self.left and not conf_r:
            out.append("car_left")
        elif conf_r and not self.right and not conf_l:
            out.append("car_right")
        if conf_l or conf_r:
            self.left, self.right = self.left or conf_l, self.right or conf_r
            self._since["none"] = None
        if not left and not right and (self.left or self.right):
            self._since["none"] = self._since["none"] or t
            if t - self._since["none"] >= CLEAR_S:
                out.append("clear")
                self.left = self.right = False
                self._since["none"] = None
        elif not left and self.left and right:
            self.left = False                 # links frei geworden, rechts noch jemand – kein „Frei“
        elif not right and self.right and left:
            self.right = False
        return out
