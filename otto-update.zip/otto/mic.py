"""Eigene Mikrofon-Aufnahme für die Spracherkennung (Windows waveIn, ohne Zusatzbibliotheken).

Warum selbst aufnehmen statt „Windows-Standardmikrofon“?
- Mikrofon direkt in Otto wählbar (SteelSeries Sonar, Headset, Steam-Mikro …) – unabhängig von Windows.
- Verstärkung (zu leises Mikro), eigener Pegel-Messer.
Die Daten gehen über eine Pipe als 16 kHz / 16 Bit / Mono an System.Speech (SetInputToAudioStream)."""
import ctypes
import threading
import time
from ctypes import wintypes

winmm = ctypes.windll.winmm
RATE, CHUNK_MS = 16000, 50
WHDR_DONE = 1


class WAVEFORMATEX(ctypes.Structure):
    _fields_ = [("wFormatTag", wintypes.WORD), ("nChannels", wintypes.WORD), ("nSamplesPerSec", wintypes.DWORD),
                ("nAvgBytesPerSec", wintypes.DWORD), ("nBlockAlign", wintypes.WORD), ("wBitsPerSample", wintypes.WORD),
                ("cbSize", wintypes.WORD)]


class WAVEHDR(ctypes.Structure):
    pass


WAVEHDR._fields_ = [("lpData", ctypes.c_void_p), ("dwBufferLength", wintypes.DWORD), ("dwBytesRecorded", wintypes.DWORD),
                    ("dwUser", ctypes.c_size_t), ("dwFlags", wintypes.DWORD), ("dwLoops", wintypes.DWORD),
                    ("lpNext", ctypes.POINTER(WAVEHDR)), ("reserved", ctypes.c_size_t)]


class WAVEINCAPSW(ctypes.Structure):
    _fields_ = [("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("vDriverVersion", wintypes.UINT),
                ("szPname", ctypes.c_wchar * 32), ("dwFormats", wintypes.DWORD), ("wChannels", wintypes.WORD),
                ("wReserved1", wintypes.WORD)]


def devices() -> list[str]:
    """Alle Aufnahmegeräte (Index = waveIn-Gerätenummer). Namen kürzt Windows auf 31 Zeichen."""
    out = []
    for i in range(winmm.waveInGetNumDevs()):
        caps = WAVEINCAPSW()
        out.append(caps.szPname if winmm.waveInGetDevCapsW(i, ctypes.byref(caps), ctypes.sizeof(caps)) == 0 else f"Gerät {i}")
    return out


def find(name: str) -> int | None:
    """Gerät per (gespeichertem) Namen finden; "" = Windows-Standard (None)."""
    if not name:
        return None
    devs = devices()
    if name in devs:
        return devs.index(name)
    return next((i for i, d in enumerate(devs) if d.startswith(name[:20]) or name.startswith(d[:20])), None)


class Capture:
    """Nimmt fortlaufend auf, verstärkt, misst den Pegel und gibt die Daten an einen Empfänger weiter."""

    def __init__(self, device: int | None, gain: float = 1.0, sink=None):
        self.device = 0xFFFFFFFF if device is None else device       # WAVE_MAPPER = Windows-Standard
        self.gain = gain
        self.sink = sink                                                # sink(bytes)
        self.level = 0                                                  # 0..100
        self.peak_t = 0.0
        self.running = False
        self.error = ""
        self.denoise = True          # Störgeräusch-Filter (Brummen raus, Pausen zwischen Wörtern = echte Stille)
        self.gate_factor = 2.2       # (getestet: 20/20 auch bei lautem Spielsound) so viel lauter als das Grundrauschen muss Sprache sein
        self._nf = None              # gelerntes Grundrauschen (RMS)
        self._open_until = 0.0
        self._hp = (0.0, 0.0)        # Zustand Hochpass

    def process(self, data: bytes) -> bytes:
        """Verstärkung, Hochpass gegen Motorbrummen, Rausch-Tor, Pegel messen. Gibt die Daten für die Erkennung zurück."""
        import numpy as np
        x = np.frombuffer(data, dtype="<i2").astype(np.float32)
        if not len(x):
            return data
        if self.gain != 1.0:
            x = x * self.gain
        if self.denoise:
            # Hochpass 1. Ordnung (~150 Hz): Brummen/Rumpeln vom Spiel raus, Stimme bleibt
            a = 0.944
            y = np.empty_like(x)
            px, py = self._hp
            for i in range(len(x)):          # 800 Werte pro 50 ms – schnell genug
                py = a * (py + x[i] - px)
                px = x[i]
                y[i] = py
            self._hp = (px, py)
            x = y
        rms = float(np.sqrt(np.mean((x / 32768.0) ** 2)))
        lvl = int(min(100, max(0, (20 * np.log10(rms + 1e-6) + 60) / 60 * 100)))   # -60 dB..0 dB -> 0..100
        if lvl >= self.level or time.time() - self.peak_t > 0.8:
            self.level, self.peak_t = lvl, time.time()
        if self.denoise:
            nf = self._nf
            if nf is None:
                nf = rms
            elif rms < nf:
                nf += (rms - nf) * 0.3           # leiser geworden: schnell anpassen
            else:
                nf += (rms - nf) * 0.004         # lauter: nur langsam (Sprache soll das Grundrauschen nicht anheben)
            self._nf = max(nf, 1e-5)
            now = time.time()
            if rms > self._nf * self.gate_factor and rms > 0.002:
                self._open_until = now + 0.35    # kurz offen halten, damit Wortenden nicht abgeschnitten werden
            if now > self._open_until:
                x = x * 0.0                      # Pause -> echte Stille, damit Windows das Satzende erkennt
        return np.clip(x, -32768, 32767).astype("<i2").tobytes()

    def start(self) -> bool:
        fmt = WAVEFORMATEX(1, 1, RATE, RATE * 2, 2, 16, 0)
        self.hwi = wintypes.HANDLE()
        rc = winmm.waveInOpen(ctypes.byref(self.hwi), self.device, ctypes.byref(fmt), 0, 0, 0)
        if rc != 0:
            self.error = f"Mikrofon ließ sich nicht öffnen (Code {rc})"
            return False
        n = RATE * 2 * CHUNK_MS // 1000
        self.bufs = [ctypes.create_string_buffer(n) for _ in range(8)]
        self.hdrs = []
        for b in self.bufs:
            h = WAVEHDR(ctypes.cast(b, ctypes.c_void_p), n, 0, 0, 0, 0, None, 0)
            winmm.waveInPrepareHeader(self.hwi, ctypes.byref(h), ctypes.sizeof(h))
            winmm.waveInAddBuffer(self.hwi, ctypes.byref(h), ctypes.sizeof(h))
            self.hdrs.append(h)
        winmm.waveInStart(self.hwi)
        self.running, self._opened = True, True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def _run(self):
        import numpy as np
        k = 0
        while self.running:
            h = self.hdrs[k]
            if not h.dwFlags & WHDR_DONE:
                time.sleep(0.005)
                continue
            data = ctypes.string_at(h.lpData, h.dwBytesRecorded)
            if not self.running:
                break
            rc = winmm.waveInAddBuffer(self.hwi, ctypes.byref(h), ctypes.sizeof(h))   # Puffer sofort wieder füllen
            if rc != 0:                                 # z. B. Headset abgesteckt
                self.error = f"Mikrofon-Aufnahme unterbrochen (Code {rc}) – Mikrofon abgesteckt?"
                self.running = False
                break
            k = (k + 1) % len(self.hdrs)
            if not data:
                time.sleep(0.005)
                continue
            data = self.process(data)
            if self.sink:
                try:
                    self.sink(data)
                except Exception as e:
                    self.error = str(e)
                    self.running = False

    def stop(self):
        if not getattr(self, "_opened", False):
            return
        self._opened = False
        self.running = False
        t = getattr(self, "_thread", None)
        if t is not None and t is not threading.current_thread():
            t.join(1.0)                                 # Aufnahme-Thread erst fertig werden lassen
        try:
            winmm.waveInStop(self.hwi)
            winmm.waveInReset(self.hwi)
            for h in self.hdrs:
                winmm.waveInUnprepareHeader(self.hwi, ctypes.byref(h), ctypes.sizeof(h))
            winmm.waveInClose(self.hwi)
        except Exception:
            pass


_CS = r"""
using System; using System.IO; using System.Collections.Generic; using System.Threading;
public class OttoAudioStream : Stream {
    readonly Queue<byte[]> q = new Queue<byte[]>(); byte[] cur; int pos; bool closed; long total;
    public void Push(byte[] d) { lock (q) { q.Enqueue(d); while (q.Count > 200) q.Dequeue(); Monitor.PulseAll(q); } }
    public void Finish() { lock (q) { closed = true; Monitor.PulseAll(q); } }
    public override int Read(byte[] buf, int off, int count) {
        // Windows-Spracherkennung hält „weniger Bytes als angefragt“ für das Ende -> Puffer immer ganz füllen
        int done = 0;
        while (done < count) {
            if (cur == null || pos >= cur.Length) {
                lock (q) { while (q.Count == 0 && !closed) Monitor.Wait(q); if (q.Count == 0) break; cur = q.Dequeue(); pos = 0; }
            }
            int n = Math.Min(count - done, cur.Length - pos);
            Buffer.BlockCopy(cur, pos, buf, off + done, n); pos += n; done += n; total += n;
        }
        return done;
    }
    public override bool CanRead { get { return true; } }
    public override bool CanSeek { get { return false; } }
    public override bool CanWrite { get { return false; } }
    public override long Length { get { return long.MaxValue; } }
    public override long Position { get { return total; } set { } }
    public override void Flush() { }
    public override long Seek(long o, SeekOrigin s) { return 0; }
    public override void SetLength(long v) { }
    public override void Write(byte[] b, int o, int c) { throw new NotSupportedException(); }
}"""
_STREAM_TYPE = None


def audio_stream():
    """Endlos-Datenstrom für System.Speech (verlangt eine Länge, die eine Live-Aufnahme nicht hat).
    Wird einmal zur Laufzeit mit dem in Windows eingebauten C#-Compiler übersetzt."""
    global _STREAM_TYPE
    if _STREAM_TYPE is None:
        import clr
        clr.AddReference("System")
        from Microsoft.CSharp import CSharpCodeProvider
        from System.CodeDom.Compiler import CompilerParameters
        p = CompilerParameters()
        p.GenerateInMemory = True
        p.ReferencedAssemblies.Add("System.dll")
        res = CSharpCodeProvider().CompileAssemblyFromSource(p, _CS)
        if res.Errors.HasErrors:
            raise RuntimeError(str(res.Errors[0]))
        _STREAM_TYPE = res.CompiledAssembly.GetType("OttoAudioStream")
    from System import Activator
    return Activator.CreateInstance(_STREAM_TYPE)


def probe(seconds: float = 1.5) -> list[tuple[str, int]]:
    """Kurz in jedes Mikrofon hineinhören: (Name, höchster Pegel) – zeigt, wo überhaupt Signal ankommt."""
    out = []
    for i, name in enumerate(devices()):
        c = Capture(i)
        peak = 0
        if c.start():
            t_end = time.time() + seconds
            while time.time() < t_end:
                peak = max(peak, c.level)
                time.sleep(0.05)
            c.stop()
        out.append((name, peak if c.error == "" else -1))
    return out
