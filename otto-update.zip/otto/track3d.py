"""Daten für die 3D-Ansicht: Streckengeometrie (Mitte, Breite, Curbs) + Runden zum Abspielen.

Streckenränder: LMU liefert pro Messung den seitlichen Abstand zur Streckenmitte (path_lateral)
und den Abstand Mitte -> Rand (track_edge). Daraus wird die echte Streckenmitte/-breite berechnet.
Ohne diese Daten (AC/ACC, ältere Aufnahmen) wird die gefahrene Linie mit geschätzter Breite benutzt.
Curbs kommen nicht aus dem Spiel – sie werden an den erkannten Kurven angedeutet."""
import csv
import gzip
import math
from . import analysis
from .analysis import STEP_M, _path_length, _resample, _smooth, find_corners
from .recorder import SESSIONS
from .sessions import lap_info, load_laps

DEFAULT_HALF = 7.0
EXTRA = ["y", "path_lateral", "track_edge"]


def _normals(xs, zs):
    n = len(xs)
    out = []
    for i in range(n):
        a, b = max(0, i - 2), min(n - 1, i + 2)
        dx, dz = xs[b] - xs[a], zs[b] - zs[a]
        l = math.hypot(dx, dz) or 1
        out.append((-dz / l, dx / l))   # "linke" Normale (Vorzeichen wird kalibriert)
    return out


def _centerline(r, sign):
    nrm = _normals(r["x"], r["z"])
    cx = [x - sign * lat * nx for x, lat, (nx, _) in zip(r["x"], r["path_lateral"], nrm)]
    cz = [z - sign * lat * nz for z, lat, (_, nz) in zip(r["z"], r["path_lateral"], nrm)]
    return cx, cz


def _has_lateral(r) -> bool:
    edges = [abs(e) for e in r["track_edge"]]
    return sum(1 for e in edges if e > 2) > 0.6 * len(edges)


def _geometry(rs: list[dict]) -> dict:
    ref = rs[0]
    n = min(len(r["x"]) for r in rs)
    if _has_lateral(ref):
        # Vorzeichen so wählen, dass die Streckenmitte aus mehreren Runden übereinanderliegt
        sign = 1
        if len(rs) > 1 and _has_lateral(rs[1]):
            def spread(s):
                a, b = _centerline(rs[0], s), _centerline(rs[1], s)
                return sum(math.hypot(a[0][i] - b[0][i], a[1][i] - b[1][i]) for i in range(0, n, 5))
            sign = 1 if spread(1) <= spread(-1) else -1
        cx, cz = _centerline(ref, sign)
        cx, cz = _smooth(cx, 3), _smooth(cz, 3)
        half = [max(4.0, min(25.0, abs(e))) for e in ref["track_edge"]]
        half = _smooth(half, 10)
        cy, bank = _banking([r for r in rs if _has_lateral(r)], sign, n)
        source = "lmu"
    else:
        cx, cz = _smooth(ref["x"], 3), _smooth(ref["z"], 3)
        half = [DEFAULT_HALF] * len(cx)
        cy, bank = _smooth(ref["y"], 3), [0.0] * len(cx)
        source = "estimated"
    return {"x": cx, "y": cy[:len(cx)], "z": cz, "half": half, "bank": bank[:len(cx)], "source": source}


def _banking(rs: list[dict], sign: int, n: int, win: int = 10) -> tuple[list, list]:
    """Querneigung der Fahrbahn: Höhe des Autos gegen seitlichen Abstand zur Mitte, über alle
    Runden in einem ±40-m-Fenster (lineare Regression). Ergibt Höhe der Mitte + Steigung pro Meter
    in Richtung der 'linken' Normale. Daytona: ~0,5 (≈27°) in den Steilkurven, ~0,3 im Tri-Oval."""
    # Pro Stelle den Mittelwert aller Runden abziehen -> Steigung/Gefälle entlang der Strecke
    # fällt raus, übrig bleibt nur: "wer weiter außen fuhr, war wie viel höher"
    m_lat = [sum(sign * r["path_lateral"][k] for r in rs) / len(rs) for k in range(n)]
    m_y = [sum(r["y"][k] for r in rs) / len(rs) for k in range(n)]
    ys, banks = [], []
    for i in range(n):
        sxy = sxx = 0.0
        for r in rs:
            for k in range(max(0, i - win), min(n, i + win + 1)):
                dx = sign * r["path_lateral"][k] - m_lat[k]
                sxy += dx * (r["y"][k] - m_y[k])
                sxx += dx * dx
        cnt = len(rs) * (min(n, i + win + 1) - max(0, i - win))
        b = sxy / sxx if len(rs) > 1 and sxx / cnt > 0.3 else 0.0
        b = max(-0.65, min(0.65, b))              # max. ~33°
        banks.append(b)
        ys.append(m_y[i] - b * m_lat[i])          # Höhe an der Streckenmitte
    banks = _smooth(_smooth(banks, 6), 6)
    ys = _smooth(ys, 4)
    return ys, banks


def _curbs(geo, ref) -> list[dict]:
    """Curbs andeuten: innen am Scheitel, außen am Ein- und Ausgang."""
    xs, zs, n = geo["x"], geo["z"], len(geo["x"])
    curbs = []
    for c in find_corners(ref):
        a = c["apex"]
        i0, i1 = max(2, a - 8), min(n - 3, a + 8)
        # Kurvenrichtung: Kreuzprodukt der Fahrtrichtung vor/nach dem Scheitel
        ax, az = xs[a] - xs[i0], zs[a] - zs[i0]
        bx, bz = xs[i1] - xs[a], zs[i1] - zs[a]
        inside = 1 if ax * bz - az * bx > 0 else -1          # +1 = Seite der "linken" Normale
        curbs.append({"side": inside, "from": max(0, a - 6), "to": min(n - 1, a + 6)})
        curbs.append({"side": -inside, "from": max(0, a - 26), "to": max(0, a - 14)})
        curbs.append({"side": -inside, "from": min(n - 1, a + 10), "to": min(n - 1, a + 24)})
    return curbs


def _lap_payload(l) -> dict:
    d = l["data"]
    keys = ["t", "lap_time_ms", "lap_pos", "x", "y", "z", "speed_kmh", "throttle", "brake", "steering",
            "steer_range", "gear", "path_lateral", "track_edge"]
    k0 = next((i for i, p in enumerate(d["lap_pos"]) if p < 0.5), 0) if l["full"] else 0
    return {"lap": l["lap"], "time_ms": l["time_ms"], "full": l["full"],
            **{k: [round(v, 3) for v in d[k][k0:]] for k in keys}}


def build(file: str, lap_no: int | None = None, ghost_no: int | None = None) -> dict:
    laps = load_laps(file)
    all_full = [l for l in laps if l["full"]]
    if not all_full:
        # keine volle Runde (z. B. nur Outlap) -> trotzdem die längste Fahrt zeigen
        longest = max(laps, key=lambda l: len(l["data"]["t"]), default=None)
        if not longest or len(longest["data"]["t"]) < 300:
            return {"error": "Diese Session ist zu kurz für die 3D-Ansicht."}
        all_full = [longest]
    full = [l for l in all_full if l["valid"]] or all_full
    best = min(full, key=lambda l: l["time_ms"])
    lap = next((l for l in laps if l["lap"] == lap_no), best)
    ghost = next((l for l in all_full if l["lap"] == ghost_no), None) if ghost_no is not None else None

    track_len = sorted(_path_length(l["data"]) for l in all_full)[len(all_full) // 2]
    rs = [_resample(l["data"], track_len, EXTRA) for l in [best] + [l for l in full if l is not best][:2]]
    geo = _geometry(rs)
    return {
        "track": geo,                       # alle 4 m
        "track_len": track_len,
        "step_m": STEP_M,
        "lesson": _lesson(file, lap["lap"], (ghost or best)["lap"]),
        "curbs": _curbs(geo, rs[0]),
        "lap": _lap_payload(lap),
        "offs": [{k: o[k] for k in ("x", "z", "max_m", "severe")} for o in lap["offs"]],
        "ghost": _lap_payload(ghost) if ghost else None,
        "cars": _other_cars(file, lap),
        "laps": [lap_info(l) for l in laps],
        "best_lap": best["lap"],
    }


def _lesson(file: str, lap_no: int, ref_no: int) -> dict:
    """Kurven-Lehrmodus: pro Kurve Brems-/Gas-Punkte beider Runden + der Tipp aus der Analyse."""
    a = analysis.analyse(file, lap_no, ref_no)
    if a.get("error"):
        return {"corners": []}
    advice = {t["name"]: t for t in a["coach"]["top"]}
    out = []
    for c in a["corners"]:
        t = advice.get(c["name"])
        out.append({
            "name": c["name"], "label": c["label"], "nick": c["nick"], "start": c["start"], "end": c["end"], "apex": c["apex"], "loss_ms": round(c["loss_ms"]),
            "lap": {k: c["lap"][k] for k in ("brake_m", "throttle_m", "apex_m", "min_speed", "exit_speed")},
            "ref": {k: c["ref"][k] for k in ("brake_m", "throttle_m", "apex_m", "min_speed", "exit_speed")},
            "title": t["title"] if t else None, "text": t["text"] if t else None, "off_m": c.get("off_m", 0),
        })
    return {"ref_lap": ref_no, "corners": out}


def _other_cars(file: str, lap) -> list[dict]:
    """Andere Autos während dieser Runde (aus *.cars.csv.gz), Zeitbasis = Aufnahme-Zeit t."""
    p = SESSIONS / file.replace(".csv.gz", ".cars.csv.gz")
    if not p.exists():
        return []
    t0, t1 = lap["data"]["t"][0] - 1, lap["data"]["t"][-1] + 1
    cars: dict[str, dict] = {}
    try:
        with gzip.open(p, "rt", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                try:
                    t = float(row["t"])
                    if t < t0 or t > t1 or row["player"] == "1":
                        continue
                    c = cars.setdefault(row["id"], {"id": row["id"], "car": row["car"], "cls": row["cls"],
                                                    "t": [], "x": [], "y": [], "z": [], "speed_kmh": [],
                                                    "lap_dist": [], "place": []})
                    c["t"].append(t)
                    for k in ("x", "y", "z", "speed_kmh", "lap_dist"):
                        c[k].append(float(row[k]))
                    c["place"].append(int(row["place"]))
                except (KeyError, ValueError):
                    continue
    except (OSError, EOFError):
        pass
    return [c for c in cars.values() if len(c["t"]) > 5]
