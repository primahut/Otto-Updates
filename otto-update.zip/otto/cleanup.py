"""Aufräumen: unbrauchbare Aufnahmen (keine einzige volle Runde, z. B. nur Box/Menü) und auf Wunsch
alte Sessions. Alles wandert in den WINDOWS-PAPIERKORB – nichts wird endgültig gelöscht."""
import ctypes
import time
from ctypes import wintypes
from .recorder import SESSIONS
from .sessions import list_sessions, load_laps

FO_DELETE, FOF_ALLOWUNDO, FOF_NOCONFIRMATION, FOF_SILENT, FOF_NOERRORUI = 3, 0x40, 0x10, 0x4, 0x400


class SHFILEOPSTRUCTW(ctypes.Structure):
    _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]


def to_recycle_bin(paths) -> bool:
    paths = [str(p) for p in paths if p.exists()]
    if not paths:
        return True
    op = SHFILEOPSTRUCTW(wFunc=FO_DELETE, pFrom="\0".join(paths) + "\0\0",
                         fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI)
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0


def candidates(keep_days: int = 0) -> list[dict]:
    """Was würde aufgeräumt? keep_days > 0: zusätzlich alles, was älter ist."""
    out, now = [], time.time()
    for s in list_sessions():
        p = SESSIONS / s["file"]
        age_days = (now - p.stat().st_mtime) / 86400
        if age_days < 0.02:                 # gerade erst aufgenommen / läuft evtl. noch
            continue
        try:
            full = sum(1 for l in load_laps(s["file"]) if l["full"])
        except Exception:
            full = 0
        reason = None
        if full == 0:
            reason = "keine vollständige Runde"
        elif keep_days and age_days > keep_days:
            reason = f"älter als {keep_days} Tage"
        if reason:
            # automatisch nur Winzlinge (< ~1 min Fahrt); alles andere entscheidet der Nutzer
            out.append({**s, "reason": reason, "full_laps": full, "auto": full == 0 and s["size_kb"] < 60})
    # zu kleine Fehlstart-Dateien, die gar nicht erst in der Liste auftauchen
    for p in SESSIONS.glob("*.csv*"):
        if p.stat().st_size < 2000 and now - p.stat().st_mtime > 600 and not any(c["file"] == p.name for c in out):
            out.append({"file": p.name, "date": "", "info": p.name, "size_kb": 0, "reason": "leere Datei", "full_laps": 0, "auto": True})
    return out


def auto_clean() -> int:
    """Beim Start: nur leere Dateien und Mini-Fehlstarts in den Papierkorb."""
    return clean([c["file"] for c in candidates() if c["auto"]])


def clean(files: list[str]) -> int:
    paths = []
    for f in files:
        p = SESSIONS / f
        paths.append(p)
        paths.append(p.with_name(p.name.replace(".csv.gz", ".cars.csv.gz")))
    to_recycle_bin(paths)
    return sum(1 for f in files if not (SESSIONS / f).exists())
