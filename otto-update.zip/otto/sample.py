"""Einheitliches Telemetrie-Format für alle Spiele."""
from dataclasses import dataclass


@dataclass
class Sample:
    game: str
    speed_kmh: float
    throttle: float      # 0..1
    brake: float         # 0..1
    steering: float      # -1..1 (Anteil vom vollen Lenkeinschlag)
    gear: int            # -1 = R, 0 = N
    rpm: float
    lap: int
    lap_time_ms: int     # laufende Rundenzeit
    lap_pos: float       # 0..1 Streckenfortschritt (falls verfügbar, sonst -1)
    x: float
    y: float
    z: float
    steer_range: float = 0.0   # voller Lenkradbereich in Grad (0 = unbekannt)
    yaw: float = 0.0           # Fahrtrichtung in rad
    path_lateral: float = 0.0  # seitlicher Abstand zur Streckenmitte in m (LMU)
    track_edge: float = 0.0    # Abstand Streckenmitte -> Rand in m (LMU, 0 = unbekannt)

    @property
    def steer_deg(self) -> float:
        return self.steering * self.steer_range / 2
