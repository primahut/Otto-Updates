"""Live-Coach: vergleicht jede Kurve sofort nach dem Ausgang mit der Bestrunde der Session
und sagt kurz an, was zu ändern ist. In der nächsten Runde erinnert er ~3 s VOR der Kurve
daran („Kurve 11: später bremsen“) und lobt, wenn es danach besser lief.
Nach jeder Runde: Rundenzeit + Abstand zur Bestzeit."""
import time
from . import tracknames
from .analysis import STEP_M, _advice, _corner_metrics, _path_length, _resample, corner_labels, find_corners
from .i18n import T
from .voice import say_delta, say_time

MIN_LOSS_MS = 150      # erst ab so viel Zeitverlust in einer Kurve wird etwas gesagt
FIXED_MS = 50          # so wenig Verlust = Problem behoben
MIN_GAP_S = 4.0        # Mindestabstand zwischen zwei Ansagen
LEAD_S = 3.2           # so viele Sekunden vor dem Bremspunkt kommt die Erinnerung
KEYS = ["lap_pos", "lap_time_ms", "speed_kmh", "throttle", "brake", "steering", "x", "z", "gear",
        "path_lateral", "track_edge"]


def action(kind: str, m: dict, r: dict, loss_ms: float) -> str:
    """Was zu tun ist – ohne Kurvenname, sehr kurz (man hört nur 2–3 Sekunden zu)."""
    bp = (r["brake_m"] - m["brake_m"]) if m["brake_m"] is not None and r["brake_m"] is not None else 0
    dv = r["min_speed"] - m["min_speed"]
    if kind in ("brake_later", "brake_earlier", "carry_speed", "throttle_earlier", "exit"):
        return T("a_" + kind, m=f"{bp:.0f}", v=f"{dv:.0f}")
    return T("a_line", z=round(loss_ms / 100))


def reminder(kind: str) -> str:
    """Kurzform für die Erinnerung vor der Kurve."""
    return T("r_" + kind) if kind in ("brake_later", "brake_earlier", "carry_speed", "throttle_earlier", "exit") else ""


class LiveCoach:
    def __init__(self, speaker):
        self.speaker = speaker
        self.enabled = True          # Kurven-Tipps nach der Kurve
        self.remind = True           # Erinnerung vor der Kurve
        self.announce_laps = True    # Rundenzeiten ansagen
        self.focus = True            # nach langsamerer Runde: größter Verlust („Größter Verlust: T11, später bremsen“)
        self.track = ""
        self.ref = None              # {"L", "corners", "metrics", "labels", "approach"}
        self.pending = {}            # Kurven-Index -> {"kind", "label"} (Problem aus vorheriger Runde)
        self.next_corner = 0
        self.issues = []             # Probleme der aktuellen Runde (für „wo verliere ich Zeit“)
        self.last_issues = []
        self.last_msg = ""
        self._last_say = 0.0
        self._reminded = set()
        self.user_name = ""
        self.style = "normal"        # knapp | normal | motivierend

    # ---------- Persönlichkeit ----------
    def _name(self, prefix=", ") -> str:
        return f"{prefix}{self.user_name}" if self.user_name else ""

    def hello(self) -> str:
        return T("hello", name=self._name(" "))

    def greet(self, track: str, best_ms: int | None):
        if self.style == "knapp":
            text = track + (f", {T('best', t=say_time(best_ms))}" if best_ms else "")
        else:
            text = T("greet", name=self._name(" "), track=track)
            text += T("greet_best", t=say_time(best_ms)) if best_ms else T("greet_new")
        self.say(text, max_age=15)

    # ---------- Referenz ----------
    def set_reference(self, lap: dict):
        """lap: Spalten-Dict einer vollständigen, gültigen Bestrunde."""
        try:
            L = _path_length(lap)
            grid = _resample(lap, L)
            corners = [c for c in find_corners(grid) if c["end"] < len(grid["dist"])]
            metrics = [_corner_metrics(grid, c) for c in corners]
            labels = [tracknames.spoken(nm["label"]).replace("Kurve", T("corner", n="").strip())
                      for nm in corner_labels(self.track, grid, corners, L)]
            approach = [(m["brake_m"] if m["brake_m"] is not None else c["start"] * STEP_M) for c, m in zip(corners, metrics)]
            self.ref = {"L": L, "corners": corners, "metrics": metrics, "labels": labels, "approach": approach}
        except Exception as e:      # Coach darf die Aufnahme nie stören
            print("Coach-Referenz fehlgeschlagen:", e)

    def new_lap(self):
        self.next_corner = 0
        self._reminded = set()
        self.last_issues, self.issues = self.issues, []

    # ---------- während der Fahrt ----------
    def on_sample(self, cur: dict, lap_pos: float, speed_kmh: float = 0.0):
        if not self.ref or lap_pos < 0:
            return
        L = self.ref["L"]
        d = lap_pos * L
        self._maybe_remind(d, speed_kmh)
        if len(cur["lap_pos"]) < 30:
            return
        corners = self.ref["corners"]
        if self.next_corner >= len(corners):
            return
        k = self.next_corner
        c = corners[k]
        # erst auswerten, wenn der Kurvenabschnitt komplett gefahren ist
        if d < c["end"] * STEP_M + 10:
            return
        self.next_corner += 1
        try:
            grid = _resample(cur, L)
            if c["end"] >= len(grid["dist"]):
                return
            m, r = _corner_metrics(grid, c), self.ref["metrics"][k]
        except Exception:
            return
        loss = m["time"] - r["time"]
        label = self.ref["labels"][k]
        if loss < FIXED_MS and k in self.pending:          # Problem aus der Vorrunde gelöst
            self.pending.pop(k)
            if (self.enabled or self.remind) and self.style != "knapp" and self._can_say():
                self.say(T("better", c=label) + (T("good_so") if self.style == "motivierend" else ""), max_age=3)
            return
        if loss < MIN_LOSS_MS:
            return
        kind = _advice(m, r)["kind"]
        tip = f"{label}: {action(kind, m, r, loss)}"
        self.pending[k] = {"kind": kind, "label": label}
        self.issues.append({"name": c["name"], "label": label, "loss_ms": loss, "tip": tip})
        if self.enabled and self._can_say():
            self.say(tip, max_age=3)

    def _maybe_remind(self, d: float, speed_kmh: float):
        if not self.remind or not self.pending:
            return
        lead = max(60.0, speed_kmh / 3.6 * LEAD_S)
        for k, p in self.pending.items():
            if k in self._reminded or not reminder(p["kind"]):   # „Linie“ ist als Kurz-Erinnerung zu vage
                continue
            a = self.ref["approach"][k]
            if a - lead <= d <= a - lead + 50:
                self._reminded.add(k)
                if self._can_say(gap=2.5):
                    self.say(f"{p['label']}: {reminder(p['kind'])}", max_age=1.5)
                return

    def on_lap_done(self, lap_ms: int, valid: bool, prev_best: int | None, off: bool):
        if not self.announce_laps:
            return
        text = T("lap", t=say_time(lap_ms)) if self.style != "knapp" else say_time(lap_ms)
        if not valid:
            text += f", {T('invalid')}" if off else ""
        elif prev_best is None:
            text += f", {T('first_best')}"
        elif lap_ms < prev_best:
            gain = prev_best - lap_ms
            text += f", {T('new_best')}, " + (T("just") if gain < 50 else say_delta(-gain))
            if self.style == "motivierend":
                text += ". " + T("strong", name=self._name())
        else:
            text += f", {say_delta(lap_ms - prev_best)}"
            if self.style == "motivierend" and lap_ms - prev_best < 300:
                text += ". " + T("close")
            # Lern-Fokus: die eine Stelle, die am meisten gekostet hat – damit man weiß, worauf man achten soll
            top = max(self.issues, key=lambda i: i["loss_ms"]) if self.issues else None
            if self.focus and self.style != "knapp" and top and top["loss_ms"] >= 200 and lap_ms - prev_best >= 250:
                text += ". " + T("focus", t=top["tip"])
        self.say(text, max_age=6)

    # ---------- Ausgabe ----------
    def _can_say(self, gap: float = MIN_GAP_S) -> bool:
        return time.time() - self._last_say > gap

    def say(self, text: str, max_age: float = 4.0):
        self.last_msg = text
        self.history = (getattr(self, "history", []) + [f"{time.strftime('%H:%M:%S')} {text}"])[-12:]   # für Bug-Berichte
        self._last_say = time.time()
        self.speaker.say(text, max_age)

    def where_summary(self) -> str:
        issues = self.issues or self.last_issues
        if not self.ref:
            return T("need_ref")
        if not issues:
            return T("no_issues")
        top = sorted(issues, key=lambda i: -i["loss_ms"])[:2]
        return ". ".join(f"{i['tip']}, {T('costs')} {say_delta(i['loss_ms']).replace(' ' + T('slower'), '')}" for i in top)
