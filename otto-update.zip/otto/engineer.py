"""KI-Engineer: beantwortet freie Fragen am Funk („Otto, soll ich auf Medium wechseln?“) mit Google Gemini.

- Nur für Fragen, die Otto nicht als festen Befehl kennt – Spotter, Fahrlehrer & Co. bleiben offline.
- Gemini bekommt die Sprachaufnahme direkt (versteht Deutsch und Englisch) plus alle Live-Daten als Text.
  Rechnungen (Tempo, Aufholen, Sprit) macht Otto vorher selbst – die KI formuliert und kombiniert nur.
- Der Schlüssel liegt nur lokal in <Datenordner>/engineer_key.txt (nie in Einstellungen, Bug-Berichten
  oder Update-Dateien)."""
import base64
import json
import time
import urllib.error
import urllib.request
from . import paths

KEY_FILE = paths.DATA / "engineer_key.txt"
URL = "https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent"
# schnell (~0,5 s) statt besonders schlau: am Funk zählt die Zeit. Google benennt Modelle öfter um -> mehrere probieren.
MODELS = ["gemini-3.5-flash-lite", "gemini-flash-lite-latest", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite"]
TIMEOUT_S = 8.0          # gesamt
PER_MODEL_S = 3.0       # ein überlastetes Modell hält nicht alles auf -> nach 3 s das nächste

SYSTEM = """Du bist der Renningenieur ("race engineer") eines Sim-Racing-Fahrers in Le Mans Ultimate, am Funk während der Fahrt.
Regeln:
- SPRACHE: Antworte in der Sprache, in der der FAHRER fragt – nicht in der Sprache der Live-Daten (die sind immer deutsch).
  Englische Frage -> komplett englische Antwort mit "en|" davor. Deutsche Frage -> komplett deutsche Antwort mit "de|" davor.
  Niemals mischen. Beispiel: "Should I pit?" -> "en|Stay out. Fifteen minutes left, tyres are fine."
- Extrem kurz wie am Teamfunk: höchstens 2 kurze Sätze (max. ca. 30 Wörter). Kein Smalltalk, keine Aufzählungen, kein Markdown.
- Stil: ruhig, direkt, menschlich, wie ein F1/WEC-Ingenieur ("Copy.", "Barely.", "Push now.", "Ja, das reicht knapp.").
- Nutze NUR die gelieferten Live-Daten. Erfinde keine Zahlen. Bereits berechnete Werte (Tempo, Aufholen, Sprit) direkt verwenden.
- Wenn die Daten für eine Antwort fehlen, sag das kurz und ehrlich ("Dafür hab ich keine Daten." / "No data on that.").
- ZAHLEN: immer als Ziffern und EXAKT so wie in den Live-Daten (62 bleibt 62, nie als Wort ausschreiben, nie runden oder ändern).
  Dezimalstellen mit Komma (de) bzw. Punkt (en): "2,3 Sekunden", Rundenzeit "1:50,2".
- Wenn die Aufnahme unverständlich ist oder keine Frage an dich enthält, antworte genau: "SAY_AGAIN".
- Wenn die Frage GENAU einem dieser Standardbefehle entspricht, antworte nur mit "CMD|<kennung>" (Otto beantwortet ihn
  dann selbst mit exakten Daten): last_lap (letzte Runde), best (Bestzeit), delta (Delta/Pace), where (wo verliere ich Zeit),
  position (Platz), fuel (Sprit), gap:ahead (Abstand vorne), gap:behind (Abstand hinten), gap:leader (Abstand Spitze),
  gap:place:<Zahl> (Abstand zu Platz X), traffic (Verkehr), time_left (Restzeit), weather (Wetter), tyres (Reifen),
  brakes (Bremsen), compound (welche Reifen/Mischung, Soft/Medium/Hard/Regen), pit (Boxenstopp ja/nein), start_tyres (mit welchen Reifen ins Rennen starten – nur ohne genannte Renndauer), damage (Schaden / reparieren ja-nein), catch:ahead (kann ich ihn einholen), catch:behind (holt er mich ein), friend (wo ist mein Kumpel),
  session (Zusammenfassung), race_report (Rennbericht: Plätze, Stints, Stopps), repeat (nochmal), louder, quieter, help.
  Alles andere (Strategie, Vergleiche, Mischfragen) beantwortest du selbst.
- Reifenmischungen in LMU: Soft, Medium, Hard, Wet. Wechsel-Empfehlungen aus Restzeit, Abnutzung, Temperaturen, Wetter und Tempo ableiten.
"""


def load_key() -> str:
    try:
        return KEY_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def save_key(key: str):
    key = (key or "").strip()
    if key:
        KEY_FILE.write_text(key, encoding="utf-8")
    else:
        KEY_FILE.unlink(missing_ok=True)


def masked() -> str:
    k = load_key()
    return ("…" + k[-3:]) if len(k) > 10 else ("gesetzt" if k else "")


class Engineer:
    def __init__(self):
        self.model = None            # zuletzt funktionierendes Modell
        self.last_error = ""
        self.last_ms = None          # Antwortzeit der letzten Frage

    @property
    def ready(self) -> bool:
        return bool(load_key())

    def ask(self, context: str, audio_wav: bytes | None = None, text: str | None = None) -> tuple[str, str] | None:
        """-> (Sprache, Antwort) | ("", "SAY_AGAIN") | None (Fehler/Zeitüberschreitung)."""
        key = load_key()
        if not key:
            self.last_error = "Kein Schlüssel eingetragen."
            return None
        parts = []
        if audio_wav:
            parts.append({"inline_data": {"mime_type": "audio/wav", "data": base64.b64encode(audio_wav).decode()}})
        parts.append({"text": ("FRAGE (Text): " + text + "\n\n" if text else "Die Frage ist in der Sprachaufnahme.\n\n")
                      + "LIVE-DATEN:\n" + context})
        body = {"system_instruction": {"parts": [{"text": SYSTEM}]},
                "contents": [{"role": "user", "parts": parts}],
                "generationConfig": {"maxOutputTokens": 200, "temperature": 0.5}}
        t0 = time.time()
        for m in ([self.model] if self.model else []) + [x for x in MODELS if x != self.model]:
            for thinking in (True, False):
                b = dict(body)
                if thinking:            # möglichst wenig „Nachdenken“ = schnellere Antwort
                    tc = {"thinkingBudget": 0} if m.startswith("gemini-2.") else {"thinkingLevel": "minimal"}
                    b["generationConfig"] = {**body["generationConfig"], "thinkingConfig": tc}
                left = min(PER_MODEL_S, TIMEOUT_S - (time.time() - t0))
                if left < 1:
                    self.last_error = "Zeitüberschreitung"
                    return None
                try:
                    req = urllib.request.Request(URL.format(m=m), data=json.dumps(b).encode(), method="POST",
                                                 headers={"Content-Type": "application/json", "x-goog-api-key": key})
                    with urllib.request.urlopen(req, timeout=left) as r:
                        data = json.loads(r.read())
                    cand = (data.get("candidates") or [{}])[0]
                    txt = "".join(p.get("text", "") for p in (cand.get("content") or {}).get("parts", [])).strip()
                    if not txt or txt.strip() == "CMD|":
                        self.last_error = f"Leere Antwort von {m} ({cand.get('finishReason', '?')})"
                        break                    # nächstes Modell probieren
                    self.model, self.last_error = m, ""
                    self.last_ms = round((time.time() - t0) * 1000)
                    return _parse(txt)
                except urllib.error.HTTPError as e:
                    msg = e.read().decode(errors="ignore")[:300]
                    if e.code in (401, 403) or "API_KEY_INVALID" in msg or "API key not valid" in msg:
                        self.last_error = "Schlüssel ungültig oder nicht freigeschaltet."
                        return None
                    if e.code == 404:
                        break                    # Modell gibt es nicht (mehr) -> gleich das nächste
                    if e.code == 429:
                        self.last_error = "Gratis-Limit gerade erreicht – kurz warten."
                        return None
                    self.last_error = f"HTTP {e.code}: {msg}"
                    continue                     # anderes Modell / ohne thinkingConfig probieren
                except (TimeoutError, OSError) as e:
                    self.last_error = f"Nicht erreichbar: {e}"
                    if "timed out" in str(e):
                        break                    # zu langsam -> nächstes Modell
                    return None                  # kein Internet o. Ä.
                except Exception as e:
                    self.last_error = f"Fehler: {e}"
                    return None
        return None


def _parse(txt: str) -> tuple[str, str]:
    if "SAY_AGAIN" in txt:
        return "", "SAY_AGAIN"
    if "CMD|" in txt:
        return "cmd", txt.split("CMD|", 1)[1].strip().split()[0].strip(".,")
    lang, _, rest = txt.partition("|")
    if lang.strip().lower() in ("de", "en") and rest.strip():
        return lang.strip().lower(), _clean(rest)
    return "", _clean(txt)


def _clean(t: str) -> str:
    return " ".join(t.replace("*", "").replace("#", "").split())
