"""Streckendatenbank (otto/data/tracks.json): offizielle Kurvennamen, Längen, echte Vergleichszeiten.

Kurvennamen für Strecken, die noch nie von Hand zugeordnet wurden, ordnet Otto automatisch zu:
Otto kennt aus der Datenbank Reihenfolge, Richtung (L/R) und ungefähre Lage (Anteil der Runde) jeder
offiziellen Kurve. Die LMU-Start/Ziel-Linie liegt nicht immer genau an der offiziellen Stelle – deshalb
wird die beste Verschiebung gesucht und dann jede erkannte Kurve der passenden offiziellen zugeordnet."""
import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data" / "tracks.json"


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return "".join(ch for ch in s if ch.isalnum())


@lru_cache(maxsize=1)
def _db() -> dict:
    try:
        return json.loads(DATA.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def find(track: str) -> dict | None:
    """Strecke anhand des Namens aus dem Spiel finden (auch „Circuit de Spa-Francorchamps“ vs. „Spa“)."""
    t = _norm(track)
    if not t:
        return None
    best, best_len = None, 0
    for name, info in _db().items():
        for alias in [name] + info.get("aliases", []):
            a = _norm(alias)
            if a and (a == t or a in t or t in a) and len(a) > best_len:
                best, best_len = {**info, "name": name}, len(a)
    return best


def ref_times(track: str) -> dict:
    info = find(track)
    return info.get("times", {}) if info else {}


def auto_labels(track: str, apexes: list[tuple[float, int]], lap_len: float) -> list[dict | None]:
    """apexes: [(Position in m, Richtung -1 = links / +1 = rechts / 0 = unklar)].
    Ergebnis pro Kurve: {"label", "nick"} oder None (keine sichere Zuordnung)."""
    info = find(track)
    if not info or not info.get("corners") or lap_len <= 0:
        return [None] * len(apexes)
    off_corners = [(c["frac"], {"L": -1, "R": 1}.get(c.get("dir"), 0), c) for c in info["corners"]]
    tol = 0.025                                         # max. 2,5 % der Runde daneben
    det = [(m / lap_len, d) for m, d in apexes]
    n, k = len(det), len(off_corners)

    def pair_score(i, j, shift):
        f, d = det[i]
        of, odir, _ = off_corners[j]
        dist = abs(((f - (of + shift)) + 0.5) % 1.0 - 0.5)
        if dist > tol:
            return None
        s = 1 - dist / tol * 0.5
        if d and odir and d != odir:
            s -= 0.3           # Richtung passt nicht: Abzug statt Ausschluss (Schikanen sind L-R oder R-L)
        return s if s > 0 else None

    def match(shift):
        """Reihenfolge-treue Zuordnung (wie beim Vergleichen zweier Listen): jede offizielle Kurve
        höchstens einmal, keine Überkreuzungen, beliebige Lücken auf beiden Seiten erlaubt."""
        best = [[0.0] * (k + 1) for _ in range(n + 1)]
        move = [[0] * (k + 1) for _ in range(n + 1)]
        for i in range(1, n + 1):
            for j in range(1, k + 1):
                opts = [(best[i - 1][j], 1), (best[i][j - 1], 2)]
                ps = pair_score(i - 1, j - 1, shift)
                if ps is not None:
                    opts.append((best[i - 1][j - 1] + ps, 3))
                best[i][j], move[i][j] = max(opts)
        out, i, j = [None] * n, n, k
        while i > 0 and j > 0:
            m = move[i][j]
            if m == 3:
                out[i - 1] = off_corners[j - 1][2]
                i, j = i - 1, j - 1
            elif m == 1:
                i -= 1
            else:
                j -= 1
        return best[n][k], out

    best_score, best_out = -1.0, [None] * len(det)
    steps = 64
    for st in range(-steps, steps + 1):                  # Verschiebung bis ±8 % der Runde testen
        s, out = match(st * 0.08 / steps)
        if s > best_score:
            best_score, best_out = s, out
    # nur übernehmen, wenn die Zuordnung insgesamt überzeugt (mind. die Hälfte der Kurven passt)
    if sum(1 for o in best_out if o) < max(2, len(det) // 2):
        return [None] * len(det)
    return [_short(c) if c else None for c in best_out]


def _short(c: dict) -> dict:
    """Kurzer Name für Karte/Overlay/Ansage + Zusatz.
    „Mulsanne Chicane 1 (Hunaudieres, …)“ -> „Mulsanne Chicane 1“ · „Porsche Curves - Virage du Pont“ -> „Virage du Pont“."""
    m = re.match(r"^(.*?)(?: \((.*?)\))?(?: - (.*))?$", c["name"].strip())
    base, paren, part = m.group(1), m.group(2) or "", m.group(3) or ""
    side = {"left": "links", "right": "rechts"}.get(part.lower())
    if side:                                   # „Esses (…) - left“ -> „Esses links“
        name, nick = f"{base} {side}", paren
    elif part:                                 # „Porsche Curves - Virage du Pont“ -> „Virage du Pont“
        name, nick = part, ", ".join(x for x in (base, paren) if x)
    else:
        name, nick = base, paren
    if c.get("turn"):
        # mit offizieller Nummer: „T11“ als Name, der Rest als Zusatz (außer er sagt nur „Turn 11“)
        same = lambda x: x.strip().lower().replace("turn ", "t") == c["turn"].lower()
        parts = [name] + [p for p in nick.split(", ")]
        return {"label": c["turn"], "nick": ", ".join(p for p in parts if p and not same(p))}
    return {"label": name, "nick": nick}
