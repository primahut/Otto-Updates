"""Anzeige-Version (wie bei richtigen Apps) – getrennt von der internen Build-Nummer.

- VERSION-Datei (z. B. 2026.10.12.5) = Build-Nummer: daran erkennt der Updater, was neuer ist. Bleibt Datum-basiert,
  damit auch alte Otto-Versionen (die nur Zahlen vergleichen) das Update finden. Steht klein unter Einstellungen › Update.
- NAME hier = was der Fahrer sieht: MAJOR.MINOR.PATCH
    PATCH (0.6.1, 0.6.2 …)  kleine Bugfixes
    MINOR (0.7, 0.8 …)      große Updates (neue Bereiche, große UI-Änderungen)
    1.0                     Vollversion

Fahrplan bis 1.0 (Stand 12.10.2026):
    0.6  Live-Coach als Renningenieur (Spotter, Schaden, Reifen, Strategie, Rennbericht)  <- jetzt, Beta
    0.7  Replay & 3D-Ansicht deiner Runden
    0.8  App-Überarbeitung (Oberfläche, Auswertung, Fortschritt)
    0.9  Feinschliff / Release-Kandidat (alles stabil, wenig neue Funktionen)
    1.0  Vollversion
"""
NAME = "0.6.0"
CHANNEL = "Beta"          # "" = fertige Version

# Build-Nummer -> Anzeige-Version (für „Was ist neu“ und das Update-Banner)
NAMES = {
    "2026.10.12.5": "0.6.0 Beta",
}


def display() -> str:
    return f"{NAME} {CHANNEL}".strip()


def name_of(build: str) -> str:
    return NAMES.get(build, build)
