"""Offizielle Kurvennamen pro Strecke. Ottos Kurvenerkennung findet Bremszonen; hier wird jeder
erkannten Kurve (über die Position auf der Runde) ein offizieller Name zugeordnet.

Positionen = Meter ab der LMU-Start/Ziel-Linie (Scheitelpunkt). Vorbelegt für COTA und Daytona,
anhand von Streckenkarten + Lenkrichtung abgeglichen – nicht jede Zuordnung ist sicher, deshalb
kann jeder Name in der Analyse angeklickt und geändert werden (gespeichert in tracknames.json)."""
import json
from pathlib import Path

from .paths import TRACKNAMES as PATH
MATCH_M = 90   # so nah muss eine erkannte Kurve am hinterlegten Punkt liegen

DEFAULTS = {
    "Circuit of the Americas": [
        {"pos": 652, "name": "T1", "nick": "Bergauf-Haarnadel"},
        {"pos": 812, "name": "T2"},
        {"pos": 904, "name": "T3", "nick": "Esses"},
        {"pos": 1128, "name": "T4–5", "nick": "Esses"},
        {"pos": 1432, "name": "T6", "nick": "Esses"},
        {"pos": 1508, "name": "T7"},
        {"pos": 1708, "name": "T9"},
        {"pos": 1956, "name": "T10"},
        {"pos": 2572, "name": "T11", "nick": "Haarnadel vor der Gegengeraden"},
        {"pos": 3716, "name": "T12", "nick": "Bremszone nach der Gegengeraden"},
        {"pos": 3960, "name": "T13"},
        {"pos": 4224, "name": "T15"},
        {"pos": 4528, "name": "T16", "nick": "lange Rechts"},
        {"pos": 4640, "name": "T17", "nick": "lange Rechts"},
        {"pos": 4816, "name": "T18"},
        {"pos": 4964, "name": "T19"},
        {"pos": 5252, "name": "T20", "nick": "letzte Kurve"},
    ],
    "Daytona International Speedway Road Course": [
        {"pos": 456, "name": "T1", "nick": "Infield-Haarnadel"},
        {"pos": 928, "name": "T3", "nick": "International Horseshoe"},
        {"pos": 1432, "name": "T4"},
        {"pos": 1756, "name": "T5"},
        {"pos": 2136, "name": "T6", "nick": "auf die Steilkurve"},
        {"pos": 3832, "name": "Bus Stop", "nick": "Schikane Einfahrt"},
        {"pos": 3960, "name": "Bus Stop 2", "nick": "Schikane Ausfahrt"},
    ],
    "Circuit de la Sarthe": [
        {"pos": 596, "name": "Dunlop", "nick": "Dunlop-Kurve"},
        {"pos": 912, "name": "Dunlop-Schikane"},
        {"pos": 1272, "name": "Esses"},
        {"pos": 1460, "name": "Esses 2"},
        {"pos": 1600, "name": "Esses 3"},
        {"pos": 1916, "name": "Tertre Rouge"},
        {"pos": 4084, "name": "Schikane 1", "nick": "erste Hunaudières-Schikane"},
        {"pos": 6096, "name": "Schikane 2", "nick": "zweite Hunaudières-Schikane"},
        {"pos": 7688, "name": "Mulsanne"},
        {"pos": 9600, "name": "Indianapolis"},
        {"pos": 9776, "name": "Indianapolis 2"},
        {"pos": 10104, "name": "Arnage"},
        {"pos": 11476, "name": "Porsche", "nick": "Porsche-Kurven"},
        {"pos": 11696, "name": "Porsche 2"},
        {"pos": 12204, "name": "Corvette"},
        {"pos": 12312, "name": "Corvette 2"},
        {"pos": 13372, "name": "Ford-Schikane"},
    ],
}


def _load() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def names(track: str) -> list[dict]:
    track = (track or "").strip()
    return _load().get(track) or DEFAULTS.get(track, [])


def label(track: str, apex_m: float, fallback: str) -> dict:
    """Offizieller Name zur Kurve an Position apex_m (oder Ottos eigener Name)."""
    best = min(names(track), key=lambda n: abs(n["pos"] - apex_m), default=None)
    if best and abs(best["pos"] - apex_m) <= MATCH_M:
        return {"label": best["name"], "nick": best.get("nick", ""), "official": True}
    return {"label": f"Kurve {fallback[1:]}", "nick": "", "official": False}


def labels(track: str, apexes: list[tuple[float, int]], fallbacks: list[str], lap_len: float) -> list[dict]:
    """Namen für alle Kurven einer Runde auf einmal. Reihenfolge: eigene Umbenennungen / handgeprüfte
    Namen (tracknames.json bzw. DEFAULTS) -> automatische Zuordnung aus der Streckendatenbank -> „Kurve N“.
    apexes: [(Position m, Richtung -1 links / +1 rechts / 0)]"""
    from . import trackdb
    manual = [label(track, m, fb) for (m, _), fb in zip(apexes, fallbacks)]
    if names(track):
        return manual                                  # Strecke ist von Hand gepflegt -> nur diese Namen
    auto = trackdb.auto_labels(track, apexes, lap_len)
    out = []
    for mnl, a in zip(manual, auto):
        if mnl["official"] or not a:
            out.append(mnl)
        else:
            out.append({"label": a["label"], "nick": a.get("nick", ""), "official": True, "auto": True})
    return out


def rename(track: str, apex_m: float, name: str, nick: str = ""):
    """Namen einer Kurve setzen (ersetzt einen Eintrag in der Nähe oder legt einen neuen an)."""
    track = track.strip()
    data = _load()
    lst = [n for n in (data.get(track) or [dict(n) for n in DEFAULTS.get(track, [])])
           if abs(n["pos"] - apex_m) > MATCH_M]
    if name.strip():
        lst.append({"pos": round(apex_m), "name": name.strip(), "nick": nick.strip()})
    data[track] = sorted(lst, key=lambda n: n["pos"])
    PATH.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")


def spoken(lbl: str) -> str:
    """„T11“ -> „Kurve 11“ für die Sprachausgabe; „Bus Stop“ bleibt."""
    if lbl.startswith("T") and lbl[1:2].isdigit():
        return "Kurve " + lbl[1:].replace("–", " bis ")
    return lbl
