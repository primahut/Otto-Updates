"""Assetto Corsa & ACC: beide nutzen dieselben Mapping-Namen und denselben Struct-Anfang.
Wir lesen nur den gemeinsamen Präfix der Structs, der in beiden Spielen identisch ist."""
import ctypes
from ..shm import SharedMemory
from ..sample import Sample


class Physics(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("packetId", ctypes.c_int),
        ("gas", ctypes.c_float),
        ("brake", ctypes.c_float),
        ("fuel", ctypes.c_float),
        ("gear", ctypes.c_int),          # 0 = R, 1 = N, 2 = 1. Gang
        ("rpms", ctypes.c_int),
        ("steerAngle", ctypes.c_float),
        ("speedKmh", ctypes.c_float),
        ("velocity", ctypes.c_float * 3),
        ("accG", ctypes.c_float * 3),
    ]


class Graphics(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("packetId", ctypes.c_int),
        ("status", ctypes.c_int),        # 0 off, 1 replay, 2 live, 3 pause
        ("session", ctypes.c_int),
        ("currentTime", ctypes.c_wchar * 15),
        ("lastTime", ctypes.c_wchar * 15),
        ("bestTime", ctypes.c_wchar * 15),
        ("split", ctypes.c_wchar * 15),
        ("completedLaps", ctypes.c_int),
        ("position", ctypes.c_int),
        ("iCurrentTime", ctypes.c_int),
        ("iLastTime", ctypes.c_int),
        ("iBestTime", ctypes.c_int),
        ("sessionTimeLeft", ctypes.c_float),
        ("distanceTraveled", ctypes.c_float),
        ("isInPit", ctypes.c_int),
        ("currentSectorIndex", ctypes.c_int),
        ("lastSectorTime", ctypes.c_int),
        ("numberOfLaps", ctypes.c_int),
        ("tyreCompound", ctypes.c_wchar * 33),
        ("replayTimeMultiplier", ctypes.c_float),
        ("normalizedCarPosition", ctypes.c_float),
    ]


class Static(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("smVersion", ctypes.c_wchar * 15),
        ("acVersion", ctypes.c_wchar * 15),
        ("numberOfSessions", ctypes.c_int),
        ("numCars", ctypes.c_int),
        ("carModel", ctypes.c_wchar * 33),
        ("track", ctypes.c_wchar * 33),
    ]


class ACReader:
    name = "AC/ACC"

    def __init__(self):
        self.phys = SharedMemory("Local\\acpmf_physics", Physics)
        self.gfx = SharedMemory("Local\\acpmf_graphics", Graphics)
        self.static = SharedMemory("Local\\acpmf_static", Static)

    def info(self) -> str:
        s = self.static.read()
        return f"{s.carModel} @ {s.track}" if s else "?"

    def read(self) -> Sample | None:
        p, g = self.phys.read(), self.gfx.read()
        if not p or not g or g.status != 2:
            return None
        return Sample(
            game=self.name, speed_kmh=p.speedKmh, throttle=p.gas, brake=p.brake,
            steering=p.steerAngle, gear=p.gear - 1, rpm=p.rpms,
            lap=g.completedLaps + 1, lap_time_ms=g.iCurrentTime,
            lap_pos=g.normalizedCarPosition, x=0.0, y=0.0, z=0.0,
        )
