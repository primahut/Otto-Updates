"""Simulator: fährt eine erfundene Strecke ab, damit man ohne Spiel entwickeln/testen kann."""
import math
import random
import time
from ..sample import Sample

N = 1500             # Stützpunkte der Strecke
LENGTH_M = 4200.0    # Streckenlänge
A_LAT = 18.0         # max. Querbeschleunigung m/s²
A_BRAKE = 22.0
A_ACC = 7.0
V_MAX = 290 / 3.6


def _build_track():
    pts = []
    for i in range(N):
        th = 2 * math.pi * i / N
        r = 1 + 0.28 * math.sin(2 * th) + 0.14 * math.sin(3 * th + 1) + 0.08 * math.cos(5 * th)
        pts.append((r * math.cos(th), r * math.sin(th)))
    seg = [math.dist(pts[i], pts[(i + 1) % N]) for i in range(N)]
    scale = LENGTH_M / sum(seg)
    pts = [(x * scale, y * scale) for x, y in pts]
    ds = LENGTH_M / N
    # Krümmung aus drei Punkten
    curv = []
    for i in range(N):
        a, b, c = pts[i - 1], pts[i], pts[(i + 1) % N]
        area2 = abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))
        d = math.dist(a, b) * math.dist(b, c) * math.dist(a, c)
        curv.append(2 * area2 / d if d else 0)
    return pts, curv, ds


class FakeReader:
    name = "Simulator"

    def __init__(self):
        self.pts, self.curv, self.ds = _build_track()
        self.lap = 0
        self._new_lap()

    def info(self) -> str:
        return "Testwagen @ Otto-Ring"

    def _new_lap(self):
        """Geschwindigkeitsprofil für eine Runde – mit zufälligen Fahrfehlern."""
        self.lap += 1
        brake = A_BRAKE * random.uniform(0.85, 1.0)
        v = [min(V_MAX, math.sqrt(A_LAT * random.uniform(0.92, 1.0) / max(k, 1e-6))) for k in self.curv]
        for _ in range(2):  # zweimal wegen Rundenübergang
            for i in range(N - 1, -1, -1):
                v[i] = min(v[i], math.sqrt(v[(i + 1) % N] ** 2 + 2 * brake * self.ds))
            for i in range(N):
                v[i] = min(v[i], math.sqrt(v[i - 1] ** 2 + 2 * A_ACC * self.ds))
        self.v = v
        self.t_at = [0.0]
        for i in range(N - 1):
            self.t_at.append(self.t_at[-1] + self.ds / ((v[i] + v[i + 1]) / 2))
        self.lap_time = self.t_at[-1] + self.ds / v[-1]
        self.lap_start = time.perf_counter()

    def read(self) -> Sample:
        t = time.perf_counter() - self.lap_start
        if t >= self.lap_time:
            self._new_lap()
            t = 0.0
        # Index per Binärsuche
        lo, hi = 0, N - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.t_at[mid] <= t:
                lo = mid
            else:
                hi = mid - 1
        i, j = lo, (lo + 1) % N
        dv = self.v[j] - self.v[i]
        throttle = 1.0 if dv > 0.01 else (0.35 if abs(dv) <= 0.01 else 0.0)
        brk = min(1.0, -dv * 6) if dv < -0.01 else 0.0
        speed = self.v[i] * 3.6
        gear = max(1, min(7, int(speed / 42) + 1))
        x, y = self.pts[i]
        return Sample(
            game=self.name, speed_kmh=speed, throttle=throttle, brake=brk,
            steering=max(-1, min(1, self.curv[i] * 40)), gear=gear,
            rpm=4000 + (speed % 42) / 42 * 4500, lap=self.lap,
            lap_time_ms=int(t * 1000), lap_pos=i / N, x=x, y=0.0, z=y,
            steer_range=540.0,
            yaw=math.atan2(self.pts[j][0] - x, self.pts[j][1] - y),
        )
