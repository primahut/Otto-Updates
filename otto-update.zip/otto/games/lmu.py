"""Le Mans Ultimate über das rFactor-2-Shared-Memory-Plugin (rFactor2SharedMemoryMapPlugin64.dll).

- Scoring-Buffer: wer ist der Spieler, Auto/Strecke, Streckenposition (Lap Distance).
- Telemetrie-Buffer: Gas/Bremse/Speed usw. Wir kennen nur den Anfang des Fahrzeug-Structs
  sicher; die Gesamtgröße pro Fahrzeug (Stride) wird daher zur Laufzeit ermittelt.
"""
import ctypes
import math
import re
import struct
import time
from ..shm import SharedMemory
from ..sample import Sample

HEADER = 16  # VersionBegin, VersionEnd, BytesUpdatedHint, NumVehicles (Telemetrie)


class Vec3(ctypes.Structure):
    _pack_ = 4
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double), ("z", ctypes.c_double)]


class VehicleTelemetryHead(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("mID", ctypes.c_int),
        ("mDeltaTime", ctypes.c_double),
        ("mElapsedTime", ctypes.c_double),
        ("mLapNumber", ctypes.c_int),
        ("mLapStartET", ctypes.c_double),
        ("mVehicleName", ctypes.c_char * 64),
        ("mTrackName", ctypes.c_char * 64),
        ("mPos", Vec3),
        ("mLocalVel", Vec3),
        ("mLocalAccel", Vec3),
        ("mOri", Vec3 * 3),
        ("mLocalRot", Vec3),
        ("mLocalRotAccel", Vec3),
        ("mGear", ctypes.c_int),
        ("mEngineRPM", ctypes.c_double),
        ("mEngineWaterTemp", ctypes.c_double),
        ("mEngineOilTemp", ctypes.c_double),
        ("mClutchRPM", ctypes.c_double),
        ("mUnfilteredThrottle", ctypes.c_double),
        ("mUnfilteredBrake", ctypes.c_double),
        ("mUnfilteredSteering", ctypes.c_double),
        ("mUnfilteredClutch", ctypes.c_double),
        ("mFilteredThrottle", ctypes.c_double),
        ("mFilteredBrake", ctypes.c_double),
        ("mFilteredSteering", ctypes.c_double),
        ("mFilteredClutch", ctypes.c_double),
        ("_misc1", ctypes.c_double * 11),        # SteeringShaftTorque … EngineMaxRPM
        ("_flags1", ctypes.c_ubyte * 4),
        ("mDentSeverity", ctypes.c_ubyte * 8),
        ("mLastImpactET", ctypes.c_double),
        ("mLastImpactMagnitude", ctypes.c_double),
        ("mLastImpactPos", Vec3),
        ("mEngineTorque", ctypes.c_double),
        ("mCurrentSector", ctypes.c_int),
        ("_flags2", ctypes.c_ubyte * 4),
        ("mFuelCapacity", ctypes.c_double),
        ("_flags3", ctypes.c_ubyte * 4),
        ("mFrontTireCompoundName", ctypes.c_char * 18),
        ("mRearTireCompoundName", ctypes.c_char * 18),
        ("_flags4", ctypes.c_ubyte * 4),
        ("mVisualSteeringWheelRange", ctypes.c_float),  # z. B. 719° beim Alpine
    ]


class ScoringInfo(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("mTrackName", ctypes.c_char * 64),
        ("mSession", ctypes.c_int),
        ("mCurrentET", ctypes.c_double),
        ("mEndET", ctypes.c_double),
        ("mMaxLaps", ctypes.c_int),
        ("mLapDist", ctypes.c_double),
        ("pointer1", ctypes.c_ubyte * 8),
        ("mNumVehicles", ctypes.c_int),
        ("mGamePhase", ctypes.c_ubyte),
        ("mYellowFlagState", ctypes.c_byte),
        ("mSectorFlag", ctypes.c_byte * 3),
        ("mStartLight", ctypes.c_ubyte),
        ("mNumRedLights", ctypes.c_ubyte),
        ("mInRealtime", ctypes.c_ubyte),
        ("mPlayerName", ctypes.c_char * 32),
        ("mPlrFileName", ctypes.c_char * 64),
        ("mDarkCloud", ctypes.c_double),
        ("mRaining", ctypes.c_double),
        ("mAmbientTemp", ctypes.c_double),
        ("mTrackTemp", ctypes.c_double),
        ("mWind", Vec3),
        ("mMinPathWetness", ctypes.c_double),
        ("mMaxPathWetness", ctypes.c_double),
        ("mGameMode", ctypes.c_ubyte),
        ("mIsPasswordProtected", ctypes.c_ubyte),
        ("mServerPort", ctypes.c_ushort),
        ("mServerPublicIP", ctypes.c_uint),
        ("mMaxPlayers", ctypes.c_int),
        ("mServerName", ctypes.c_char * 32),
        ("mStartET", ctypes.c_float),
        ("mAvgPathWetness", ctypes.c_double),
        ("mExpansion", ctypes.c_ubyte * 200),
        ("pointer2", ctypes.c_ubyte * 8),
    ]


class VehicleScoring(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("mID", ctypes.c_int),
        ("mDriverName", ctypes.c_char * 32),
        ("mVehicleName", ctypes.c_char * 64),
        ("mTotalLaps", ctypes.c_short),
        ("mSector", ctypes.c_byte),
        ("mFinishStatus", ctypes.c_byte),
        ("mLapDist", ctypes.c_double),
        ("mPathLateral", ctypes.c_double),
        ("mTrackEdge", ctypes.c_double),
        ("mBestSector1", ctypes.c_double),
        ("mBestSector2", ctypes.c_double),
        ("mBestLapTime", ctypes.c_double),
        ("mLastSector1", ctypes.c_double),
        ("mLastSector2", ctypes.c_double),
        ("mLastLapTime", ctypes.c_double),
        ("mCurSector1", ctypes.c_double),
        ("mCurSector2", ctypes.c_double),
        ("mNumPitstops", ctypes.c_short),
        ("mNumPenalties", ctypes.c_short),
        ("mIsPlayer", ctypes.c_ubyte),
        ("mControl", ctypes.c_byte),
        ("mInPits", ctypes.c_ubyte),
        ("mPlace", ctypes.c_ubyte),
        ("mVehicleClass", ctypes.c_char * 32),
        ("mTimeBehindNext", ctypes.c_double),
        ("mLapsBehindNext", ctypes.c_int),
        ("mTimeBehindLeader", ctypes.c_double),
        ("mLapsBehindLeader", ctypes.c_int),
        ("mLapStartET", ctypes.c_double),
        ("mPos", Vec3),
        ("mLocalVel", Vec3),
        ("mLocalAccel", Vec3),
        ("mOri", Vec3 * 3),
        ("mLocalRot", Vec3),
        ("mLocalRotAccel", Vec3),
        ("mHeadlights", ctypes.c_ubyte),
        ("mPitState", ctypes.c_ubyte),
        ("mServerScored", ctypes.c_ubyte),
        ("mIndividualPhase", ctypes.c_ubyte),
        ("mQualification", ctypes.c_int),
        ("mTimeIntoLap", ctypes.c_double),
        ("mEstimatedLapTime", ctypes.c_double),
        ("mPitGroup", ctypes.c_char * 24),
        ("mFlag", ctypes.c_ubyte),
        ("mUnderYellow", ctypes.c_ubyte),
        ("mCountLapFlag", ctypes.c_ubyte),
        ("mInGarageStall", ctypes.c_ubyte),
        ("mUpgradePack", ctypes.c_ubyte * 16),
        ("mPitLapDist", ctypes.c_float),
        ("mBestLapSector1", ctypes.c_float),
        ("mBestLapSector2", ctypes.c_float),
        ("mExpansion", ctypes.c_ubyte * 48),
    ]


SCORING_HEADER = 12  # VersionBegin, VersionEnd, BytesUpdatedHint


def _s(b: bytes) -> str:
    return b.decode("utf-8", errors="ignore").strip()


class LMUReader:
    name = "LMU"

    def __init__(self):
        self.tel = SharedMemory("$rFactor2SMMP_Telemetry$")
        self.scr = SharedMemory("$rFactor2SMMP_Scoring$")
        self.stride = None
        self.player = None    # VehicleScoring des Spielers
        self.scoring = None   # ScoringInfo
        self.vehicles = []    # alle Autos (Scoring, ~5 Hz)
        self.last_error = ""

    def player_class(self) -> str | None:
        """Fahrzeugklasse des Spielers, wie LMU sie meldet („Hyper“, „LMP2“, „LMGT3“ …)."""
        return _s(self.player.mVehicleClass) or None if self.player else None

    def race_info(self) -> dict | None:
        """Platz, Abstände nach vorne/hinten, Sprit – für Sprachbefehle."""
        p = self.player
        if not p or not self.vehicles:
            return None
        behind = next((v for v in self.vehicles if v.mPlace == p.mPlace + 1), None)
        tel = getattr(self, "_last_tel", None)
        return {
            "place": p.mPlace, "cars": len(self.vehicles),
            "ahead_s": p.mTimeBehindNext if p.mPlace > 1 and p.mLapsBehindNext == 0 else None,
            "behind_s": behind.mTimeBehindNext if behind and behind.mLapsBehindNext == 0 else None,
            "fuel": tel._misc1[9] if tel else None,     # mFuel in Litern
        }

    def sectors(self) -> dict | None:
        """Sektorzeiten des Spielers (Sekunden): aktuelle Runde + letzte vollständige Runde."""
        p = self.player
        if not p:
            return None
        cur = [p.mCurSector1 if p.mCurSector1 > 0 else None,
               (p.mCurSector2 - p.mCurSector1) if p.mCurSector2 > 0 and p.mCurSector1 > 0 else None, None]
        last = None
        if p.mLastLapTime > 0 and p.mLastSector1 > 0 and p.mLastSector2 > 0:
            last = [p.mLastSector1, p.mLastSector2 - p.mLastSector1, p.mLastLapTime - p.mLastSector2]
        # mSector: 1 = in Sektor 1, 2 = in Sektor 2, 0 = in Sektor 3
        return {"cur": cur, "last": last, "in": {1: 0, 2: 1, 0: 2}.get(p.mSector, 0)}

    def traffic(self, horizon_s: float = 30.0) -> list[dict]:
        """Verkehr: Autos vor mir, auf die ich auflaufe (bzw. hinter mir, die auf mich auflaufen).
        Aus Streckenposition + Geschwindigkeit aller Autos (Scoring, ~5x/s). Sortiert nach Zeit bis zum Treffen."""
        p, info = self.player, self.scoring
        if not p or not info or info.mLapDist <= 0 or not self.vehicles:
            return []
        L = info.mLapDist
        speed = lambda v: math.sqrt(v.mLocalVel.x ** 2 + v.mLocalVel.y ** 2 + v.mLocalVel.z ** 2)
        my_v, out = speed(p), []
        if p.mInPits or my_v < 14:              # in der Box / steht: sonst wäre jedes Auto „Verkehr von hinten“
            return []
        for o in self.vehicles:
            if o.mID == p.mID or o.mInPits or o.mFinishStatus in (2, 3):     # Box / ausgefallen / disqualifiziert
                continue
            ov = speed(o)
            ahead = (o.mLapDist - p.mLapDist) % L
            behind = (p.mLapDist - o.mLapDist) % L
            num = re.search(r"#(\d+)", _s(o.mVehicleName))
            base = {"id": o.mID, "cls": _s(o.mVehicleClass), "number": num.group(1) if num else "",
                    "same_class": _s(o.mVehicleClass) == _s(p.mVehicleClass), "place": o.mPlace}
            if ahead < 2000 and my_v - ov > 2:            # ich bin schneller -> laufe auf
                t = ahead / (my_v - ov)
                if t <= horizon_s:
                    out.append({**base, "dir": "ahead", "dist": round(ahead), "t": round(t, 1)})
            elif behind < 2000 and ov - my_v > 2:         # der andere ist schneller -> kommt von hinten
                t = behind / (ov - my_v)
                if t <= horizon_s:
                    out.append({**base, "dir": "behind", "dist": round(behind), "t": round(t, 1)})
        return sorted(out, key=lambda x: x["t"])

    def drivers(self) -> list[dict]:
        """Alle Fahrer der Session (nur live, wird nicht gespeichert): Name, Startnummer, Platz."""
        out = []
        for v in self.vehicles or []:
            num = re.search(r"#(\d+)", _s(v.mVehicleName))
            out.append({"id": v.mID, "name": _s(v.mDriverName), "number": num.group(1) if num else "",
                        "place": v.mPlace, "player": v.mIsPlayer == 1, "car": _s(v.mVehicleName).split(" #")[0]})
        return out

    def session_info(self) -> dict | None:
        """Restzeit/Runden, Wetter, Flaggen – für Sprachbefehle und automatische Ansagen."""
        info, p = self.scoring, self.player
        if not info or not p:
            return None
        leader = next((v for v in self.vehicles or [] if v.mPlace == 1), p)
        return {
            "race": info.mSession >= 10, "session": info.mSession, "phase": info.mGamePhase,
            "time_left": info.mEndET - info.mCurrentET if info.mEndET > 0 else None,
            "max_laps": info.mMaxLaps if 0 < info.mMaxLaps < 10000 else None,
            "laps_done": p.mTotalLaps, "leader_laps": leader.mTotalLaps,
            "raining": info.mRaining, "wet": max(info.mAvgPathWetness, 0.0), "cloud": info.mDarkCloud,
            "air": info.mAmbientTemp, "track": info.mTrackTemp,
            "yellow": info.mYellowFlagState, "sector_flags": list(info.mSectorFlag), "my_sector": p.mSector,
            "blue": p.mFlag == 6, "in_pits": bool(p.mInPits), "est_lap": p.mEstimatedLapTime,
        }

    def find_driver(self, name: str):
        """Fahrer per Name suchen: genau, sonst Vorname/Namensteil (für „mein Kumpel“)."""
        n = (name or "").strip().lower()
        if not n or not self.vehicles:
            return None
        vs = [v for v in self.vehicles if not v.mIsPlayer]
        exact = next((v for v in vs if _s(v.mDriverName).lower() == n), None)
        return exact or next((v for v in vs if n in _s(v.mDriverName).lower().split()
                              or _s(v.mDriverName).lower().startswith(n)), None)

    def driver_info(self, name: str) -> dict | None:
        """Live-Daten eines anderen Fahrers (Kumpel): Platz, Zeiten, Box, Abstand."""
        o, p = self.find_driver(name), self.player
        if o is None or p is None:
            return None
        num = re.search(r"#(\d+)", _s(o.mVehicleName))
        d = {"name": _s(o.mDriverName), "place": o.mPlace, "my_place": p.mPlace, "number": num.group(1) if num else "",
             "cls": _s(o.mVehicleClass), "same_class": _s(o.mVehicleClass) == _s(p.mVehicleClass),
             "best": o.mBestLapTime if o.mBestLapTime > 0 else None, "last": o.mLastLapTime if o.mLastLapTime > 0 else None,
             "my_best": p.mBestLapTime if p.mBestLapTime > 0 else None, "laps": o.mTotalLaps,
             "in_pits": bool(o.mInPits), "pitstops": o.mNumPitstops, "race": self.scoring.mSession >= 10}
        if d["race"]:
            laps = o.mLapsBehindLeader - p.mLapsBehindLeader
            d["laps_diff"] = laps
            d["gap_s"] = o.mTimeBehindLeader - p.mTimeBehindLeader if not laps else None
        # Abstand auf der Strecke (Meter, + = Kumpel vor mir) – auch im Training sinnvoll
        L = self.scoring.mLapDist
        if L > 0:
            ahead = (o.mLapDist - p.mLapDist) % L
            d["track_m"] = round(ahead if ahead < L / 2 else ahead - L)
        return d

    def lap_snapshot(self) -> dict:
        """{Auto-ID: (gefahrene Runden, letzte Rundenzeit s)} – die Engine baut daraus pro Auto eine Rundenzeit-Historie."""
        return {v.mID: (v.mTotalLaps, v.mLastLapTime, bool(v.mInPits)) for v in self.vehicles or []}

    def rivals_table(self) -> list[dict]:
        """Stand aller Autos für den KI-Engineer (nach Platz)."""
        p = self.player
        out = []
        for v in sorted(self.vehicles or [], key=lambda v: v.mPlace):
            out.append({"id": v.mID, "place": v.mPlace, "cls": _s(v.mVehicleClass), "name": _s(v.mDriverName),
                        "me": p is not None and v.mID == p.mID, "gap": v.mTimeBehindLeader, "laps": v.mLapsBehindLeader,
                        "last": v.mLastLapTime if v.mLastLapTime > 0 else None,
                        "best": v.mBestLapTime if v.mBestLapTime > 0 else None,
                        "pits": bool(v.mInPits), "stops": v.mNumPitstops})
        return out

    def rival(self, kind: str, value: str = "") -> dict | None:
        """Gegner für „Kann ich ihn einholen?“: kind ahead/behind = nächstes Auto DEINER Klasse davor/dahinter
        (Multiclass: ein Hypercar vor dir ist kein Gegner), place/number/name wie gap_to.
        gap_s: + = er liegt hinter mir, - = vor mir (Rennzeit). laps_diff: + = er ist Runden zurück."""
        p = self.player
        if not p or not self.vehicles or not self.scoring:
            return None
        if kind in ("ahead", "behind"):
            same = [v for v in self.vehicles if v.mID != p.mID and _s(v.mVehicleClass) == _s(p.mVehicleClass)
                    and v.mFinishStatus not in (2, 3)]
            if kind == "ahead":
                cand = [v for v in same if v.mPlace < p.mPlace]
                o = max(cand, key=lambda v: v.mPlace) if cand else None
            else:
                cand = [v for v in same if v.mPlace > p.mPlace]
                o = min(cand, key=lambda v: v.mPlace) if cand else None
        else:
            g = self.gap_to(kind, value)
            o = next((v for v in self.vehicles if g and _s(v.mDriverName) == g["name"] and v.mPlace == g["place"]), None)
        if o is None or o.mID == p.mID:
            return None
        num = re.search(r"#(\d+)", _s(o.mVehicleName))
        laps = o.mLapsBehindLeader - p.mLapsBehindLeader
        return {"id": o.mID, "my_id": p.mID, "name": _s(o.mDriverName), "place": o.mPlace, "number": num.group(1) if num else "",
                "race": self.scoring.mSession >= 10, "laps_diff": laps,
                "gap_s": o.mTimeBehindLeader - p.mTimeBehindLeader, "in_pits": bool(o.mInPits),
                "best": o.mBestLapTime if o.mBestLapTime > 0 else None,
                "my_best": p.mBestLapTime if p.mBestLapTime > 0 else None}

    def gap_to(self, kind: str, value: str = "") -> dict | None:
        """Abstand zu einem anderen Auto. kind: place | number | name | ahead | behind | leader.
        Rennen: Zeitabstand auf der Strecke. Training/Quali: Vergleich der Bestzeiten."""
        p = self.player
        if not p or not self.vehicles:
            return None
        vs = self.vehicles
        if kind == "leader":
            o = next((v for v in vs if v.mPlace == 1), None)
        elif kind == "ahead":
            o = next((v for v in vs if v.mPlace == p.mPlace - 1), None)
        elif kind == "behind":
            o = next((v for v in vs if v.mPlace == p.mPlace + 1), None)
        elif kind == "place":
            o = next((v for v in vs if str(v.mPlace) == value), None)
        elif kind == "number":
            o = next((v for v in vs if re.search(rf"#0*{int(value)}\b", _s(v.mVehicleName))), None) if value.isdigit() else None
        else:
            o = self.find_driver(value)
        if o is None or o.mID == p.mID:
            return None
        num = re.search(r"#(\d+)", _s(o.mVehicleName))
        res = {"place": o.mPlace, "number": num.group(1) if num else "", "name": _s(o.mDriverName),
               "race": self.scoring.mSession >= 10}
        if res["race"]:
            laps = o.mLapsBehindLeader - p.mLapsBehindLeader
            if laps:
                res["laps"] = laps                 # >0: andere Auto liegt Runden zurück
            elif kind == "ahead" and p.mLapsBehindNext == 0:
                res["gap_s"] = -p.mTimeBehindNext       # offizieller Abstand zum Vordermann (genauer als über die Spitze)
            elif kind == "behind" and o.mLapsBehindNext == 0:
                res["gap_s"] = o.mTimeBehindNext
            else:
                res["gap_s"] = o.mTimeBehindLeader - p.mTimeBehindLeader   # >0: anderes Auto hinter mir
        else:
            res["their_best"] = o.mBestLapTime if o.mBestLapTime > 0 else None
            res["my_best"] = p.mBestLapTime if p.mBestLapTime > 0 else None
        return res

    def cars(self) -> tuple[float, list[dict]] | None:
        """Positionen aller Autos für die 3D-Ansicht (ohne Fahrernamen)."""
        if not self.scoring or not self.vehicles:
            return None
        out = []
        for v in self.vehicles:
            vel = v.mLocalVel
            out.append({
                "id": v.mID, "player": int(v.mIsPlayer == 1), "car": _s(v.mVehicleName), "cls": _s(v.mVehicleClass),
                "place": v.mPlace, "lap": v.mTotalLaps, "lap_dist": round(v.mLapDist, 1),
                "x": round(v.mPos.x, 2), "y": round(v.mPos.y, 2), "z": round(v.mPos.z, 2),
                "speed_kmh": round(math.sqrt(vel.x ** 2 + vel.y ** 2 + vel.z ** 2) * 3.6, 1),
                "in_pits": int(v.mInPits),
            })
        return self.scoring.mCurrentET, out

    # ---------- Scoring ----------
    def _read_scoring(self):
        """Scoring (alle Autos, ~5x/s von LMU aktualisiert). Nur vollständig geschriebene Stände übernehmen –
        halb geschriebene ließen Platz, Abstände und Sektoren im Overlay springen."""
        base = SCORING_HEADER + ctypes.sizeof(ScoringInfo)
        vs = ctypes.sizeof(VehicleScoring)
        head = self.scr.read_consistent(base)
        if not head:
            return
        info = ScoringInfo.from_buffer_copy(head, SCORING_HEADER)
        if self.scoring is not None and info.mCurrentET == self.scoring.mCurrentET and self.vehicles:
            return                                   # nichts Neues seit dem letzten Lesen
        n = info.mNumVehicles
        if not 0 < n <= 128:
            return
        raw = self.scr.read_consistent(base + n * vs)
        if not raw or len(raw) < base + n * vs:
            return
        info = ScoringInfo.from_buffer_copy(raw, SCORING_HEADER)
        if info.mNumVehicles != n:
            return
        vehicles = [VehicleScoring.from_buffer_copy(raw, base + i * vs) for i in range(n)]
        players = [v for v in vehicles if v.mIsPlayer == 1]
        if len(players) != 1:  # Fallback: über den Fahrernamen
            players = [v for v in vehicles if v.mDriverName == info.mPlayerName] or players
        if players:
            self.scoring, self.player = info, players[0]
            self.vehicles = vehicles

    # ---------- Telemetrie ----------
    def _find_stride(self, raw: bytes, n: int):
        """Größe eines Telemetrie-Fahrzeugeintrags ermitteln: alle Einträge müssen
        plausible IDs und fast dieselbe Spielzeit haben."""
        et0 = struct.unpack_from("<d", raw, HEADER + 12)[0]
        est = (len(raw) - HEADER) // 128
        start = max(400, est - 256) // 4 * 4   # Structs sind 4-Byte-ausgerichtet
        for stride in sorted(range(start, est + 8, 4), key=lambda s: abs(s - est)):
            ok = True
            for k in range(1, n):
                off = HEADER + k * stride
                if off + 24 > len(raw):
                    ok = False
                    break
                vid, dt, et = struct.unpack_from("<idd", raw, off)
                if not (0 <= vid < 10000 and 0 <= dt < 0.5 and abs(et - et0) < 2):
                    ok = False
                    break
            if ok:
                return stride
        return None

    def _player_telemetry(self):
        """Telemetrie des eigenen Autos. Normalfall: nur Kopf + eigener Eintrag (~2 KB statt 240 KB) –
        mit Konsistenz-Prüfung, damit nie ein halb geschriebener Stand gelesen wird."""
        size = ctypes.sizeof(VehicleTelemetryHead)
        for _ in range(4):
            h1 = self.tel.read_at(0, HEADER)
            if not h1:
                return None
            begin, end, _, n = struct.unpack_from("<IIii", h1, 0)
            if begin != end:
                continue                                    # LMU schreibt gerade
            if not 0 < n <= 128:
                return None
            if n == 1:
                off = HEADER
            elif self.player is None:
                return None          # erst wissen, welches Auto „ich“ bin – sonst zeigt Otto ein fremdes Auto
            else:
                if self.stride is None:
                    raw = self.tel.read_consistent(self.tel.size)
                    self.stride = self._find_stride(raw, n) if raw else None
                    if self.stride is None:
                        self.last_error = "Telemetrie-Layout nicht erkannt"
                        return None
                    self._slot = None
                off = self._player_offset(n)
                if off is None:
                    return None
            blob = self.tel.read_at(off, size)
            if blob and self.tel.read_at(0, HEADER)[:8] == h1[:8]:   # während des Kopierens nichts geschrieben
                self._tel_off, self._tel_n = off, n
                return VehicleTelemetryHead.from_buffer_copy(blob)
        return None

    def _player_offset(self, n: int) -> int | None:
        """Wo steht das eigene Auto im Telemetrie-Feld? (gemerkt, nur bei Änderung neu suchen)"""
        pid = self.player.mID
        slot = getattr(self, "_slot", None)
        if slot is not None and slot < n:
            off = HEADER + slot * self.stride
            if struct.unpack("<i", self.tel.read_at(off, 4))[0] == pid:
                return off
        for k in range(n):
            off = HEADER + k * self.stride
            if struct.unpack("<i", self.tel.read_at(off, 4))[0] == pid:
                self._slot = k
                return off
        self.stride = None      # Feld hat sich geändert (Autos weg/neu) -> Layout neu ermitteln
        return None

    # ---------- Spotter & Reifen ----------
    def _slot_offset(self, vid: int, n: int) -> int | None:
        """Telemetrie-Platz eines Autos (Telemetrie und Scoring sind unterschiedlich sortiert -> per mID)."""
        slots = getattr(self, "_slots", None)
        if slots is None or (vid not in slots and time.time() - getattr(self, "_slots_t", 0) > 1.0):
            slots = {}
            for k in range(n):
                b = self.tel.read_at(HEADER + k * self.stride, 4)
                if b:
                    slots[struct.unpack("<i", b)[0]] = k
            self._slots, self._slots_t = slots, time.time()
        k = slots.get(vid)
        return HEADER + k * self.stride if k is not None and k < n else None

    def nearby(self, radius: float = 60.0):
        """Für den Spotter: eigene Position + Weltpositionen der Autos in der Nähe (aus der Telemetrie,
        viel aktueller als das Scoring mit 5 Updates/s). None, wenn gerade nicht verfügbar."""
        p, tel, n = self.player, getattr(self, "_last_tel", None), getattr(self, "_tel_n", 0)
        if not p or not tel or not self.vehicles or n < 2 or not self.stride:
            return None
        if self.scoring and (not self.scoring.mInRealtime or self.scoring.mGamePhase in (3, 7, 8, 9)):
            return None                      # Menü/Replay, Einführungsrunde, Stopp, Ende, Pause
        if p.mInPits:
            return None
        out = []
        for v in self.vehicles:
            if v.mID == p.mID or v.mInPits or v.mLapDist < 0 or v.mFinishStatus in (2, 3):
                continue
            if (v.mPos.x - p.mPos.x) ** 2 + (v.mPos.z - p.mPos.z) ** 2 > radius ** 2:
                continue
            off = self._slot_offset(v.mID, n)
            b = self.tel.read_at(off, 184) if off is not None else None
            if not b or struct.unpack_from("<i", b, 0)[0] != v.mID:
                self._slots = None           # Belegung hat sich geändert -> beim nächsten Mal neu suchen
                continue
            x, y, z = struct.unpack_from("<ddd", b, 160)
            out.append((v.mID, x, y, z))
        return (tel.mPos.x, tel.mPos.y, tel.mPos.z), out

    def tyres(self) -> dict | None:
        """Eigene Reifen (rF2Wheel ab Byte 848 im Telemetrie-Eintrag, 4 × 260 Byte: VL, VR, HL, HR):
        Temperatur (Mittel aus links/mitte/rechts, °C), Druck (kPa), Verschleiß (%), Bremsentemperatur (°C; LMU liefert Kelvin)."""
        off = getattr(self, "_tel_off", None)
        if off is None:
            return None
        b = self.tel.read_at(off + 848, 4 * 260)
        if not b or len(b) < 4 * 260:
            return None
        out = []
        for w in range(4):
            o = w * 260
            brake, = struct.unpack_from("<d", b, o + 24)
            press, = struct.unpack_from("<d", b, o + 120)
            temps = struct.unpack_from("<ddd", b, o + 128)
            wear, = struct.unpack_from("<d", b, o + 152)
            out.append({"temp": sum(temps) / 3 - 273.15, "press": press, "wear": max(0.0, (1 - wear) * 100),
                        "brake": brake - 273.15})   # LMU liefert Kelvin
        if not all(-30 < x["temp"] < 250 for x in out):
            return None                      # Layout passt nicht (andere Plugin-Version) -> lieber nichts sagen
        tel = getattr(self, "_last_tel", None)
        compound = _s(tel.mFrontTireCompoundName) if tel else ""
        return {"wheels": out, "compound": compound}

    # ---------- öffentlich ----------
    def info(self) -> str:
        if self.player and self.scoring:
            return f"{_s(self.player.mVehicleName)} @ {_s(self.scoring.mTrackName)}"
        return "?"

    def read(self) -> Sample | None:
        self._read_scoring()
        v = self._player_telemetry()
        if v is None:
            return None
        self._last_tel = v
        vel = v.mLocalVel
        speed = math.sqrt(vel.x ** 2 + vel.y ** 2 + vel.z ** 2) * 3.6
        lap_pos = -1.0
        if self.player and self.scoring and self.scoring.mLapDist > 0:
            # Scoring kommt nur ~5x pro Sekunde -> zwischen zwei Updates mit der
            # Geschwindigkeit hochrechnen, sonst springt alles, was davon abhängt (Delta).
            L = self.scoring.mLapDist
            since = max(0.0, min(0.5, v.mElapsedTime - self.scoring.mCurrentET))
            target = self.player.mLapDist + speed / 3.6 * since
            # Direkt nach Start/Ziel hängt Scoring noch bei ~100 % der alten Runde
            lap_t = v.mElapsedTime - v.mLapStartET
            if lap_t < 3 and target > 0.9 * L:
                target = speed / 3.6 * lap_t
            # Eigener „Kilometerzähler“: gefahrene Meter aus Geschwindigkeit × Zeit (30x/s, glatt),
            # sanft an LMU angeglichen. Ohne das springt die Position mit den 5 Scoring-Updates/s
            # um bis zu 15 m – und Zeitverluste pro Kurve werden um Zehntel falsch.
            dt = v.mElapsedTime - getattr(self, "_odo_et", -1.0)
            if getattr(self, "_odo_lap", None) != v.mLapNumber or not 0 <= dt <= 0.5 or abs(target - self._odo) > 40:
                self._odo = target
            else:
                self._odo += speed / 3.6 * dt
                self._odo += 0.06 * (target - self._odo)
            self._odo_et, self._odo_lap = v.mElapsedTime, v.mLapNumber
            lap_pos = max(0.0, min(1.0, self._odo / L))
        return Sample(
            game=self.name, speed_kmh=speed,
            throttle=v.mUnfilteredThrottle, brake=v.mUnfilteredBrake,
            steering=v.mUnfilteredSteering, gear=v.mGear, rpm=v.mEngineRPM,
            lap=v.mLapNumber, lap_time_ms=max(0, int((v.mElapsedTime - v.mLapStartET) * 1000)),
            lap_pos=lap_pos, x=v.mPos.x, y=v.mPos.y, z=v.mPos.z,
            steer_range=v.mVisualSteeringWheelRange,
            yaw=math.atan2(v.mOri[2].x, v.mOri[2].z),
            path_lateral=self.player.mPathLateral if self.player else 0.0,
            track_edge=self.player.mTrackEdge if self.player else 0.0,
        )
