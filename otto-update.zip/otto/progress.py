"""Fortschritt über alle Sessions: Bestzeiten pro Strecke/Auto, Konstanz, Verbesserung.
Zusammenfassungen werden in sessions/.index.json zwischengespeichert (pro Datei + Änderungszeit)."""
import json
import statistics
from .recorder import SESSIONS
from . import trackdb
from .sessions import list_sessions, load_laps, class_of

INDEX = SESSIONS / ".index.json"
VERSION = 3


def _summary(file: str) -> dict:
    laps = load_laps(file)
    full = sorted(l["time_ms"] for l in laps if l["valid"])   # ohne Runden mit Ausritt
    # "saubere" Runden: max. 7 % langsamer als die beste (Dreher/Box rausfiltern)
    clean = [t for t in full if t <= full[0] * 1.07] if full else []
    return {
        "laps_total": len(laps),
        "laps_full": len(full),
        "best_ms": full[0] if full else None,
        "median_ms": round(statistics.median(clean)) if clean else None,
        "spread_ms": round(statistics.pstdev(clean)) if len(clean) >= 3 else None,
        "lap_times": [l["time_ms"] for l in laps if l["valid"]],
        "cls": class_of(file),            # Fahrzeugklasse (Multiclass: GT3 nie mit Hypercar vergleichen)
    }


def _load_index() -> dict:
    try:
        data = json.loads(INDEX.read_text(encoding="utf-8"))
        return data if data.get("v") == VERSION else {"v": VERSION, "files": {}}
    except (OSError, ValueError):
        return {"v": VERSION, "files": {}}


def overview() -> dict:
    idx = _load_index()
    changed = False
    tracks: dict[str, dict] = {}
    for s in list_sessions():
        if s["game"] == "Simulator":
            continue
        p = SESSIONS / s["file"]
        key = f'{p.stat().st_mtime:.0f}'
        cached = idx["files"].get(s["file"])
        if not cached or cached["mtime"] != key:
            cached = {"mtime": key, **_summary(s["file"])}
            idx["files"][s["file"]] = cached
            changed = True
        if not cached["laps_full"]:
            continue
        car, _, track = s["info"].partition(" @ ")
        t = tracks.setdefault(track or "?", {"track": track or "?", "sessions": []})
        t["sessions"].append({**s, "car": car, **{k: v for k, v in cached.items() if k != "mtime"}})
    if changed:
        try:
            INDEX.write_text(json.dumps(idx), encoding="utf-8")
        except OSError:
            pass

    out = []
    for t in tracks.values():
        ss = sorted(t["sessions"], key=lambda s: s["date"])
        best = min(ss, key=lambda s: s["best_ms"])
        out.append({
            "track": t["track"], "game": ss[-1]["game"],
            "sessions": ss, "best_ms": best["best_ms"], "best_car": best["car"],
            "first_best_ms": ss[0]["best_ms"], "last_date": ss[-1]["date"],
            "laps": sum(s["laps_full"] for s in ss),
            "cars": sorted({s["car"] for s in ss}),
            "classes": sorted({s["cls"] for s in ss if s.get("cls")}),
            "ref_times": trackdb.ref_times(t["track"]),       # echte WEC-Zeiten zum Vergleich (falls bekannt)
        })
    out.sort(key=lambda t: t["last_date"], reverse=True)
    return {"tracks": out}
